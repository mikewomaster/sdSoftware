﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.ModBus;
using HslCommunication.BasicFramework;

namespace HslCommunication_Net45.Test.Modbus
{
    [TestClass]
    public class ModbusInfoTest
    {
        [TestMethod]
        public void Test( )
        {
            OperateResult<byte[]> modbus = ModbusInfo.BuildReadModbusCommand( "1", 5, 1, true, 1 );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x01, 0x01, 0x00, 0x01, 0x00, 0x05 } ) );

            modbus = ModbusInfo.BuildReadModbusCommand( "100", 1, 2, false, 1 );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, 0x01, 0x00, 0x63, 0x00, 0x01 } ) );

            modbus = ModbusInfo.BuildReadModbusCommand( "x=3;100", 1, 2, false, 1 );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, 0x03, 0x00, 0x63, 0x00, 0x01 } ) );

            modbus = ModbusInfo.BuildReadModbusCommand( "s=5;x=4;100", 10, 2, true, 1 );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x05, 0x04, 0x00, 0x64, 0x00, 0x0A } ) );

            modbus = ModbusInfo.BuildReadModbusCommand( "s=5;1000", 10, 2, true, 1 );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x05, 0x01, 0x03, 0xE8, 0x00, 0x0A } ) );

            modbus = ModbusInfo.BuildWriteWordModbusCommand( "x=3;100", 1, 2, true, ModbusInfo.WriteOneRegister );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, ModbusInfo.WriteOneRegister, 0x00, 0x64, 0x00, 0x01 } ) );

            modbus = ModbusInfo.BuildWriteWordModbusCommand( "x=3;100", new byte[4] { 0x11, 0x22, 0x33, 0x44 }, 2, true, ModbusInfo.WriteRegister );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, ModbusInfo.WriteRegister, 0x00, 0x64, 0x00, 0x02, 0x04, 0x11, 0x22, 0x33, 0x44 } ) );

            modbus = ModbusInfo.BuildWriteWordModbusCommand( "x=54;100", 1, 2, true, ModbusInfo.WriteOneRegister );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, 0x36, 0x00, 0x64, 0x00, 0x01 } ) );

            modbus = ModbusInfo.BuildWriteWordModbusCommand( "x=64;100", new byte[4] { 0x11, 0x22, 0x33, 0x44 }, 2, true, ModbusInfo.WriteRegister );
            Assert.IsTrue( modbus.IsSuccess );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus.Content, new byte[] { 0x02, 0x40, 0x00, 0x64, 0x00, 0x02, 0x04, 0x11, 0x22, 0x33, 0x44 } ) );

            byte[] modbus_rtu = ModbusInfo.BuildWriteBoolModbusCommand( "1280", true, 1, true, ModbusInfo.WriteOneCoil ).Content;
            byte[] modbus_ascii = ModbusInfo.TransModbusCoreToAsciiPackCommand( modbus_rtu);
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( modbus_rtu, ModbusInfo.TransAsciiPackCommandToCore( modbus_ascii ).Content ) );
            //Console.WriteLine( modbus_ascii.ToHexString( ' ' ) );

            //modbus = ModbusInfo.TransAsciiPackCommandToRtu( "3A30313035303530304646303046360D0A".ToHexBytes( ) );
           // Console.WriteLine( modbus.Content.ToHexString( ' ' ) );

        }
    }
}
