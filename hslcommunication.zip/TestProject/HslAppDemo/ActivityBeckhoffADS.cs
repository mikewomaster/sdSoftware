﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using HslCommunication;
using HslCommunication.Profinet.Beckhoff;

namespace HslAppDemo
{
    [Activity( Label = "Beckhoff ADS" )]
    public class ActivityBeckhoffADS : AppCompatActivity
    {
        protected override void OnCreate( Bundle savedInstanceState )
        {
            base.OnCreate( savedInstanceState );

            SetContentView( Resource.Layout.layout_beckhoff_ads );

            ipAddressText   = FindViewById<EditText>( Resource.Id.editText_ip_address );
            portText        = FindViewById<EditText>( Resource.Id.editText_ip_port );
            targetNetIdText = FindViewById<EditText>( Resource.Id.editText_target_netid );
            senderNetIdText = FindViewById<EditText>( Resource.Id.editText_sender_netid );
            tagCacheBox     = FindViewById<CheckBox>( Resource.Id.checkBox_tagcache );
            btnConnect      = FindViewById<Button>( Resource.Id.button_connect );
            btnDisconnect   = FindViewById<Button>( Resource.Id.button_disconnect );

            ipAddressText.Text   = AppDemoUtils.GetAppConfigue( "backhoff_ads_ip", "192.168.0.100" );
            portText.Text        = AppDemoUtils.GetAppConfigue( "backhoff_ads_port", "48898" );
            targetNetIdText.Text = AppDemoUtils.GetAppConfigue( "backhoff_ads_target", "" );
            senderNetIdText.Text = AppDemoUtils.GetAppConfigue( "backhoff_ads_sender", "" );
            tagCacheBox.Checked  = bool.Parse( AppDemoUtils.GetAppConfigue( "backhoff_ads_tagcache", "True" ) );
            ConnectInitialization( );
        }


        public override void OnBackPressed( )
        {
            base.OnBackPressed( );
            beckhoff?.ConnectClose( );
            beckhoff = null;
        }

        #region Connect DisConnect

        private void ConnectInitialization( )
        {
            btnConnect.Click    += Activity_Click_connect;
            btnDisconnect.Click += Activity_Click_disconnect;
            btnDisconnect.Enabled = false;
        }

        private void Activity_Click_connect( object sender, EventArgs e )
        {
            if(!IPAddress.TryParse( ipAddressText.Text, out IPAddress ip ))
            {
                AppDemoUtils.ToastMessage( this, "IpAddress Input Failed!" );
                return;
            }

            if(!int.TryParse( portText.Text, out int port ))
            {
                AppDemoUtils.ToastMessage( this, "Port Input Failed!" );
                return;
            }

            beckhoff?.ConnectClose( );
            beckhoff = new BeckhoffAdsNet( ipAddressText.Text, port );
            beckhoff.ConnectTimeOut = 2000;
            beckhoff.SetTargetAMSNetId( targetNetIdText.Text );
            beckhoff.SetSenderAMSNetId( senderNetIdText.Text );
            beckhoff.UseTagCache = tagCacheBox.Checked;

            OperateResult connect = beckhoff.ConnectServer( );
            if (connect.IsSuccess)
            {
                AppDemoUtils.ToastMessage( this, "Connect Success" );
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;

                AppDemoUtils.SetAppConfigue( "backhoff_ads_ip", ipAddressText.Text );
                AppDemoUtils.SetAppConfigue( "backhoff_ads_port", portText.Text );
                AppDemoUtils.SetAppConfigue( "backhoff_ads_target", targetNetIdText.Text );
                AppDemoUtils.SetAppConfigue( "backhoff_ads_sender", senderNetIdText.Text );
                AppDemoUtils.SetAppConfigue( "backhoff_ads_tagcache", tagCacheBox.Checked.ToString( ) );

                FindViewById<IReadWriteControl>( Resource.Id.iReadWriteControl1 ).SetReadWriteNet( beckhoff, "M100", true );
            }
            else
            {
                beckhoff = null;
                AppDemoUtils.ToastMessage( this, "Connect Failed" + connect.ToMessageShowString( ) );
            }
        }

        private void Activity_Click_disconnect( object sender, EventArgs e )
        {
            beckhoff?.ConnectClose( );
            beckhoff = null;
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            AppDemoUtils.ToastMessage( this, "Connect Close" );
            FindViewById<IReadWriteControl>( Resource.Id.iReadWriteControl1 ).SetReadWriteNet( null, "" );
        }

        #endregion

        private Button btnConnect = null;
        private Button btnDisconnect = null;
        private EditText ipAddressText = null;
        private EditText portText = null;
        private EditText targetNetIdText = null;
        private EditText senderNetIdText = null;
        private CheckBox tagCacheBox = null;
        private BeckhoffAdsNet beckhoff = null;
    }
}