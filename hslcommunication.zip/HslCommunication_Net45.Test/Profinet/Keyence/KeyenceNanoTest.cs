﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.Profinet.Keyence;
using HslCommunication.ModBus;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Core;

namespace HslCommunication_Net45.Test.Profinet.Keyence
{
	[TestClass]
	public class KeyenceNanoTest
	{
		[TestMethod]
		public void BuildReadCommandTest( )
		{
			OperateResult<byte[]> build = KeyenceNanoSerialOverTcp.BuildReadCommand( "DM0", 1 );
			Assert.IsTrue( build.IsSuccess, build.Message );
			Assert.AreEqual( "RDS DM0 1\r", Encoding.ASCII.GetString( build.Content ) );

			build = KeyenceNanoSerialOverTcp.BuildReadCommand( "MR1", 5 );
			Assert.IsTrue( build.IsSuccess, build.Message );
			Assert.AreEqual( "RDS MR1 5\r", Encoding.ASCII.GetString( build.Content ) );

			build = KeyenceNanoSerialOverTcp.BuildReadCommand( "C1", 2 );
			Assert.IsTrue( build.IsSuccess, build.Message );
			Assert.AreEqual( "RDS C1 1\r", Encoding.ASCII.GetString( build.Content ) );

		}

		[TestMethod]
		public void BuildWriteCommandTest( )
		{
			OperateResult<byte[]> build = KeyenceNanoSerialOverTcp.BuildWriteCommand( "DM0", BitConverter.GetBytes((ushort)5) );
			Assert.IsTrue( build.IsSuccess, build.Message );

			Assert.AreEqual( "WRS DM0 1 5\r", Encoding.ASCII.GetString( build.Content ) );

			RegularByteTransform byteTransform = new RegularByteTransform( );
			build = KeyenceNanoSerialOverTcp.BuildWriteCommand( "DM100",
				byteTransform.TransByte( new ushort[] { 1, 2, 100, 20000 } ) );
			Assert.IsTrue( build.IsSuccess, build.Message );

			Assert.AreEqual( "WRS DM100 4 1 2 100 20000\r", Encoding.ASCII.GetString( build.Content ) );

			// bool write
			build = KeyenceNanoSerialOverTcp.BuildWriteCommand( "MR0", true );
			Assert.IsTrue( build.IsSuccess, build.Message );

			Assert.AreEqual( "ST MR0\r", Encoding.ASCII.GetString( build.Content ) );

			build = KeyenceNanoSerialOverTcp.BuildWriteCommand( "MR0", false );
			Assert.IsTrue( build.IsSuccess, build.Message );

			Assert.AreEqual( "RS MR0\r", Encoding.ASCII.GetString( build.Content ) );
		}

		[TestMethod]
		public void ExtractActualBoolDataTest( )
		{
			OperateResult<bool[]> result = KeyenceNanoSerialOverTcp.ExtractActualBoolData( "MR", "30 20 31 20 30 20 30 20 30 20 30 20 30 20 30 0D 0A".ToHexBytes( ) );
			Assert.IsTrue( result.IsSuccess, result.Message );

			Assert.AreEqual( 8, result.Content.Length );
			Assert.AreEqual( false, result.Content[0] );
			Assert.AreEqual( true, result.Content[1] );
			Assert.AreEqual( false, result.Content[2] );
			Assert.AreEqual( false, result.Content[3] );
			Assert.AreEqual( false, result.Content[4] );
			Assert.AreEqual( false, result.Content[5] );
			Assert.AreEqual( false, result.Content[6] );
			Assert.AreEqual( false, result.Content[7] );
		}


		[TestMethod]
		public void ExtractActualDataTest( )
		{
			OperateResult<byte[]> result = KeyenceNanoSerialOverTcp.ExtractActualData( "DM", "30 30 30 30 35 20 30 30 30 30 30 20 30 39 39 33 37 20 30 30 30 30 30 20 30 39 39 33 37 20 30 30 30 30 30 20 30 30 31 30 37 20 30 30 30 30 30 0D 0A".ToHexBytes( ) );
			Assert.IsTrue( result.IsSuccess, result.Message );

			RegularByteTransform byteTransform = new RegularByteTransform( );
			ushort[] values = byteTransform.TransUInt16( result.Content, 0, 8 );

			Assert.AreEqual( 8, values.Length );
			Assert.AreEqual( 5, values[0] );
			Assert.AreEqual( 0,  values[1] );
			Assert.AreEqual( 9937, values[2] );
			Assert.AreEqual( 0, values[3] );
			Assert.AreEqual( 9937, values[4] );
			Assert.AreEqual( 0, values[5] );
			Assert.AreEqual( 107, values[6] );
			Assert.AreEqual( 0, values[7] );
		}

		[TestMethod]
		public void KvAnalysisAddressTest( )
		{
			OperateResult<string, int> analysis = KeyenceNanoSerialOverTcp.KvAnalysisAddress( "MR100" );
			Assert.IsTrue( analysis.IsSuccess, analysis.Message );

			Assert.AreEqual( "MR", analysis.Content1 );
			Assert.AreEqual( 100, analysis.Content2 );

			analysis = KeyenceNanoSerialOverTcp.KvAnalysisAddress( "R50" );
			Assert.IsTrue( analysis.IsSuccess, analysis.Message );

			Assert.AreEqual( "", analysis.Content1 );
			Assert.AreEqual( 50, analysis.Content2 );
		}
	}
}
