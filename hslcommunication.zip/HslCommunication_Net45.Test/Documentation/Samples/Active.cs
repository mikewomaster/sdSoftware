﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HslCommunication_Net45.Test.Documentation.Samples
{
	class Active
	{
		public void Sample1( )
		{
			#region Sample1

			// 授权示例 Authorization example
			if (!HslCommunication.Authorization.SetAuthorizationCode( "Your Code" ))
			{
				Console.WriteLine( "Authorization failed! The current program can only be used for 8 hours!" );
				return;   // 激活失败应该退出系统
			}

			#endregion
		}
	}

}
