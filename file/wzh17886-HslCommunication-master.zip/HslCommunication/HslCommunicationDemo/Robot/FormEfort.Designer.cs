﻿namespace HslCommunicationDemo.Robot
{
    partial class FormEfort
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label74 = new System.Windows.Forms.Label();
            this.label71 = new System.Windows.Forms.Label();
            this.textBox61 = new System.Windows.Forms.TextBox();
            this.textBox62 = new System.Windows.Forms.TextBox();
            this.textBox63 = new System.Windows.Forms.TextBox();
            this.textBox64 = new System.Windows.Forms.TextBox();
            this.textBox65 = new System.Windows.Forms.TextBox();
            this.textBox66 = new System.Windows.Forms.TextBox();
            this.textBox67 = new System.Windows.Forms.TextBox();
            this.label70 = new System.Windows.Forms.Label();
            this.textBox54 = new System.Windows.Forms.TextBox();
            this.textBox55 = new System.Windows.Forms.TextBox();
            this.textBox56 = new System.Windows.Forms.TextBox();
            this.textBox57 = new System.Windows.Forms.TextBox();
            this.textBox58 = new System.Windows.Forms.TextBox();
            this.textBox59 = new System.Windows.Forms.TextBox();
            this.textBox60 = new System.Windows.Forms.TextBox();
            this.label69 = new System.Windows.Forms.Label();
            this.textBox47 = new System.Windows.Forms.TextBox();
            this.textBox48 = new System.Windows.Forms.TextBox();
            this.textBox49 = new System.Windows.Forms.TextBox();
            this.textBox50 = new System.Windows.Forms.TextBox();
            this.textBox51 = new System.Windows.Forms.TextBox();
            this.textBox52 = new System.Windows.Forms.TextBox();
            this.textBox53 = new System.Windows.Forms.TextBox();
            this.label68 = new System.Windows.Forms.Label();
            this.textBox37 = new System.Windows.Forms.TextBox();
            this.textBox41 = new System.Windows.Forms.TextBox();
            this.textBox42 = new System.Windows.Forms.TextBox();
            this.textBox43 = new System.Windows.Forms.TextBox();
            this.textBox44 = new System.Windows.Forms.TextBox();
            this.textBox45 = new System.Windows.Forms.TextBox();
            this.textBox46 = new System.Windows.Forms.TextBox();
            this.label67 = new System.Windows.Forms.Label();
            this.label66 = new System.Windows.Forms.Label();
            this.label65 = new System.Windows.Forms.Label();
            this.label63 = new System.Windows.Forms.Label();
            this.textBox38 = new System.Windows.Forms.TextBox();
            this.textBox39 = new System.Windows.Forms.TextBox();
            this.textBox40 = new System.Windows.Forms.TextBox();
            this.label64 = new System.Windows.Forms.Label();
            this.textBox33 = new System.Windows.Forms.TextBox();
            this.textBox34 = new System.Windows.Forms.TextBox();
            this.textBox35 = new System.Windows.Forms.TextBox();
            this.textBox36 = new System.Windows.Forms.TextBox();
            this.label62 = new System.Windows.Forms.Label();
            this.textBox29 = new System.Windows.Forms.TextBox();
            this.textBox30 = new System.Windows.Forms.TextBox();
            this.textBox31 = new System.Windows.Forms.TextBox();
            this.textBox32 = new System.Windows.Forms.TextBox();
            this.label60 = new System.Windows.Forms.Label();
            this.textBox25 = new System.Windows.Forms.TextBox();
            this.textBox26 = new System.Windows.Forms.TextBox();
            this.textBox27 = new System.Windows.Forms.TextBox();
            this.textBox28 = new System.Windows.Forms.TextBox();
            this.label58 = new System.Windows.Forms.Label();
            this.textBox21 = new System.Windows.Forms.TextBox();
            this.textBox22 = new System.Windows.Forms.TextBox();
            this.textBox23 = new System.Windows.Forms.TextBox();
            this.textBox24 = new System.Windows.Forms.TextBox();
            this.label56 = new System.Windows.Forms.Label();
            this.textBox17 = new System.Windows.Forms.TextBox();
            this.textBox18 = new System.Windows.Forms.TextBox();
            this.textBox19 = new System.Windows.Forms.TextBox();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label54 = new System.Windows.Forms.Label();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label51 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label50 = new System.Windows.Forms.Label();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label45 = new System.Windows.Forms.Label();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label44 = new System.Windows.Forms.Label();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label43 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label72 = new System.Windows.Forms.Label();
            this.label73 = new System.Windows.Forms.Label();
            this.label48 = new System.Windows.Forms.Label();
            this.label49 = new System.Windows.Forms.Label();
            this.label46 = new System.Windows.Forms.Label();
            this.label47 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label39 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.label38 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.button_read_short = new System.Windows.Forms.Button();
            this.label61 = new System.Windows.Forms.Label();
            this.label59 = new System.Windows.Forms.Label();
            this.label57 = new System.Windows.Forms.Label();
            this.label55 = new System.Windows.Forms.Label();
            this.label53 = new System.Windows.Forms.Label();
            this.label52 = new System.Windows.Forms.Label();
            this.userControlHead1 = new HslCommunicationDemo.DemoControl.UserControlHead();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(12, 41);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(978, 43);
            this.panel1.TabIndex = 12;
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(875, 6);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 28);
            this.button2.TabIndex = 5;
            this.button2.Text = "断开连接";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(772, 6);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 28);
            this.button1.TabIndex = 4;
            this.button1.Text = "连接";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(250, 9);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(76, 23);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "8008";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(196, 12);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "端口号：";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(62, 9);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(128, 23);
            this.textBox1.TabIndex = 1;
            this.textBox1.Text = "192.168.0.100";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 0;
            this.label1.Text = "Ip地址：";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label74);
            this.panel2.Controls.Add(this.label71);
            this.panel2.Controls.Add(this.textBox61);
            this.panel2.Controls.Add(this.textBox62);
            this.panel2.Controls.Add(this.textBox63);
            this.panel2.Controls.Add(this.textBox64);
            this.panel2.Controls.Add(this.textBox65);
            this.panel2.Controls.Add(this.textBox66);
            this.panel2.Controls.Add(this.textBox67);
            this.panel2.Controls.Add(this.label70);
            this.panel2.Controls.Add(this.textBox54);
            this.panel2.Controls.Add(this.textBox55);
            this.panel2.Controls.Add(this.textBox56);
            this.panel2.Controls.Add(this.textBox57);
            this.panel2.Controls.Add(this.textBox58);
            this.panel2.Controls.Add(this.textBox59);
            this.panel2.Controls.Add(this.textBox60);
            this.panel2.Controls.Add(this.label69);
            this.panel2.Controls.Add(this.textBox47);
            this.panel2.Controls.Add(this.textBox48);
            this.panel2.Controls.Add(this.textBox49);
            this.panel2.Controls.Add(this.textBox50);
            this.panel2.Controls.Add(this.textBox51);
            this.panel2.Controls.Add(this.textBox52);
            this.panel2.Controls.Add(this.textBox53);
            this.panel2.Controls.Add(this.label68);
            this.panel2.Controls.Add(this.textBox37);
            this.panel2.Controls.Add(this.textBox41);
            this.panel2.Controls.Add(this.textBox42);
            this.panel2.Controls.Add(this.textBox43);
            this.panel2.Controls.Add(this.textBox44);
            this.panel2.Controls.Add(this.textBox45);
            this.panel2.Controls.Add(this.textBox46);
            this.panel2.Controls.Add(this.label67);
            this.panel2.Controls.Add(this.label66);
            this.panel2.Controls.Add(this.label65);
            this.panel2.Controls.Add(this.label63);
            this.panel2.Controls.Add(this.textBox38);
            this.panel2.Controls.Add(this.textBox39);
            this.panel2.Controls.Add(this.textBox40);
            this.panel2.Controls.Add(this.label64);
            this.panel2.Controls.Add(this.textBox33);
            this.panel2.Controls.Add(this.textBox34);
            this.panel2.Controls.Add(this.textBox35);
            this.panel2.Controls.Add(this.textBox36);
            this.panel2.Controls.Add(this.label62);
            this.panel2.Controls.Add(this.textBox29);
            this.panel2.Controls.Add(this.textBox30);
            this.panel2.Controls.Add(this.textBox31);
            this.panel2.Controls.Add(this.textBox32);
            this.panel2.Controls.Add(this.label60);
            this.panel2.Controls.Add(this.textBox25);
            this.panel2.Controls.Add(this.textBox26);
            this.panel2.Controls.Add(this.textBox27);
            this.panel2.Controls.Add(this.textBox28);
            this.panel2.Controls.Add(this.label58);
            this.panel2.Controls.Add(this.textBox21);
            this.panel2.Controls.Add(this.textBox22);
            this.panel2.Controls.Add(this.textBox23);
            this.panel2.Controls.Add(this.textBox24);
            this.panel2.Controls.Add(this.label56);
            this.panel2.Controls.Add(this.textBox17);
            this.panel2.Controls.Add(this.textBox18);
            this.panel2.Controls.Add(this.textBox19);
            this.panel2.Controls.Add(this.textBox20);
            this.panel2.Controls.Add(this.label54);
            this.panel2.Controls.Add(this.textBox16);
            this.panel2.Controls.Add(this.textBox15);
            this.panel2.Controls.Add(this.textBox14);
            this.panel2.Controls.Add(this.textBox13);
            this.panel2.Controls.Add(this.label51);
            this.panel2.Controls.Add(this.textBox12);
            this.panel2.Controls.Add(this.label50);
            this.panel2.Controls.Add(this.textBox11);
            this.panel2.Controls.Add(this.label45);
            this.panel2.Controls.Add(this.textBox10);
            this.panel2.Controls.Add(this.label44);
            this.panel2.Controls.Add(this.textBox9);
            this.panel2.Controls.Add(this.label43);
            this.panel2.Controls.Add(this.textBox8);
            this.panel2.Controls.Add(this.label42);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Controls.Add(this.textBox7);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.textBox6);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.textBox5);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Controls.Add(this.textBox4);
            this.panel2.Controls.Add(this.label7);
            this.panel2.Controls.Add(this.button3);
            this.panel2.Controls.Add(this.textBox3);
            this.panel2.Controls.Add(this.label6);
            this.panel2.Controls.Add(this.button_read_short);
            this.panel2.Controls.Add(this.label61);
            this.panel2.Controls.Add(this.label59);
            this.panel2.Controls.Add(this.label57);
            this.panel2.Controls.Add(this.label55);
            this.panel2.Controls.Add(this.label53);
            this.panel2.Controls.Add(this.label52);
            this.panel2.Location = new System.Drawing.Point(12, 91);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(978, 546);
            this.panel2.TabIndex = 13;
            // 
            // label74
            // 
            this.label74.ForeColor = System.Drawing.Color.Red;
            this.label74.Location = new System.Drawing.Point(510, 0);
            this.label74.Name = "label74";
            this.label74.Size = new System.Drawing.Size(463, 37);
            this.label74.TabIndex = 108;
            this.label74.Text = "异常信息：";
            // 
            // label71
            // 
            this.label71.AutoSize = true;
            this.label71.Location = new System.Drawing.Point(782, 330);
            this.label71.Name = "label71";
            this.label71.Size = new System.Drawing.Size(80, 17);
            this.label71.TabIndex = 107;
            this.label71.Text = "七轴工作时长";
            // 
            // textBox61
            // 
            this.textBox61.Location = new System.Drawing.Point(791, 513);
            this.textBox61.Name = "textBox61";
            this.textBox61.Size = new System.Drawing.Size(68, 23);
            this.textBox61.TabIndex = 106;
            // 
            // textBox62
            // 
            this.textBox62.Location = new System.Drawing.Point(791, 486);
            this.textBox62.Name = "textBox62";
            this.textBox62.Size = new System.Drawing.Size(68, 23);
            this.textBox62.TabIndex = 105;
            // 
            // textBox63
            // 
            this.textBox63.Location = new System.Drawing.Point(791, 459);
            this.textBox63.Name = "textBox63";
            this.textBox63.Size = new System.Drawing.Size(68, 23);
            this.textBox63.TabIndex = 104;
            // 
            // textBox64
            // 
            this.textBox64.Location = new System.Drawing.Point(791, 432);
            this.textBox64.Name = "textBox64";
            this.textBox64.Size = new System.Drawing.Size(68, 23);
            this.textBox64.TabIndex = 103;
            // 
            // textBox65
            // 
            this.textBox65.Location = new System.Drawing.Point(791, 405);
            this.textBox65.Name = "textBox65";
            this.textBox65.Size = new System.Drawing.Size(68, 23);
            this.textBox65.TabIndex = 102;
            // 
            // textBox66
            // 
            this.textBox66.Location = new System.Drawing.Point(791, 377);
            this.textBox66.Name = "textBox66";
            this.textBox66.Size = new System.Drawing.Size(68, 23);
            this.textBox66.TabIndex = 101;
            // 
            // textBox67
            // 
            this.textBox67.Location = new System.Drawing.Point(791, 350);
            this.textBox67.Name = "textBox67";
            this.textBox67.Size = new System.Drawing.Size(68, 23);
            this.textBox67.TabIndex = 100;
            // 
            // label70
            // 
            this.label70.AutoSize = true;
            this.label70.Location = new System.Drawing.Point(706, 330);
            this.label70.Name = "label70";
            this.label70.Size = new System.Drawing.Size(80, 17);
            this.label70.TabIndex = 99;
            this.label70.Text = "七轴反向计数";
            // 
            // textBox54
            // 
            this.textBox54.Location = new System.Drawing.Point(715, 513);
            this.textBox54.Name = "textBox54";
            this.textBox54.Size = new System.Drawing.Size(68, 23);
            this.textBox54.TabIndex = 98;
            // 
            // textBox55
            // 
            this.textBox55.Location = new System.Drawing.Point(715, 486);
            this.textBox55.Name = "textBox55";
            this.textBox55.Size = new System.Drawing.Size(68, 23);
            this.textBox55.TabIndex = 97;
            // 
            // textBox56
            // 
            this.textBox56.Location = new System.Drawing.Point(715, 459);
            this.textBox56.Name = "textBox56";
            this.textBox56.Size = new System.Drawing.Size(68, 23);
            this.textBox56.TabIndex = 96;
            // 
            // textBox57
            // 
            this.textBox57.Location = new System.Drawing.Point(715, 432);
            this.textBox57.Name = "textBox57";
            this.textBox57.Size = new System.Drawing.Size(68, 23);
            this.textBox57.TabIndex = 95;
            // 
            // textBox58
            // 
            this.textBox58.Location = new System.Drawing.Point(715, 405);
            this.textBox58.Name = "textBox58";
            this.textBox58.Size = new System.Drawing.Size(68, 23);
            this.textBox58.TabIndex = 94;
            // 
            // textBox59
            // 
            this.textBox59.Location = new System.Drawing.Point(715, 377);
            this.textBox59.Name = "textBox59";
            this.textBox59.Size = new System.Drawing.Size(68, 23);
            this.textBox59.TabIndex = 93;
            // 
            // textBox60
            // 
            this.textBox60.Location = new System.Drawing.Point(715, 350);
            this.textBox60.Name = "textBox60";
            this.textBox60.Size = new System.Drawing.Size(68, 23);
            this.textBox60.TabIndex = 92;
            // 
            // label69
            // 
            this.label69.AutoSize = true;
            this.label69.Location = new System.Drawing.Point(562, 330);
            this.label69.Name = "label69";
            this.label69.Size = new System.Drawing.Size(80, 17);
            this.label69.TabIndex = 91;
            this.label69.Text = "七轴加加速度";
            // 
            // textBox47
            // 
            this.textBox47.Location = new System.Drawing.Point(569, 513);
            this.textBox47.Name = "textBox47";
            this.textBox47.Size = new System.Drawing.Size(68, 23);
            this.textBox47.TabIndex = 90;
            // 
            // textBox48
            // 
            this.textBox48.Location = new System.Drawing.Point(569, 486);
            this.textBox48.Name = "textBox48";
            this.textBox48.Size = new System.Drawing.Size(68, 23);
            this.textBox48.TabIndex = 89;
            // 
            // textBox49
            // 
            this.textBox49.Location = new System.Drawing.Point(569, 459);
            this.textBox49.Name = "textBox49";
            this.textBox49.Size = new System.Drawing.Size(68, 23);
            this.textBox49.TabIndex = 88;
            // 
            // textBox50
            // 
            this.textBox50.Location = new System.Drawing.Point(569, 432);
            this.textBox50.Name = "textBox50";
            this.textBox50.Size = new System.Drawing.Size(68, 23);
            this.textBox50.TabIndex = 87;
            // 
            // textBox51
            // 
            this.textBox51.Location = new System.Drawing.Point(569, 405);
            this.textBox51.Name = "textBox51";
            this.textBox51.Size = new System.Drawing.Size(68, 23);
            this.textBox51.TabIndex = 86;
            // 
            // textBox52
            // 
            this.textBox52.Location = new System.Drawing.Point(569, 377);
            this.textBox52.Name = "textBox52";
            this.textBox52.Size = new System.Drawing.Size(68, 23);
            this.textBox52.TabIndex = 85;
            // 
            // textBox53
            // 
            this.textBox53.Location = new System.Drawing.Point(569, 350);
            this.textBox53.Name = "textBox53";
            this.textBox53.Size = new System.Drawing.Size(68, 23);
            this.textBox53.TabIndex = 84;
            // 
            // label68
            // 
            this.label68.AutoSize = true;
            this.label68.Location = new System.Drawing.Point(495, 330);
            this.label68.Name = "label68";
            this.label68.Size = new System.Drawing.Size(68, 17);
            this.label68.TabIndex = 83;
            this.label68.Text = "七轴加速度";
            // 
            // textBox37
            // 
            this.textBox37.Location = new System.Drawing.Point(495, 513);
            this.textBox37.Name = "textBox37";
            this.textBox37.Size = new System.Drawing.Size(68, 23);
            this.textBox37.TabIndex = 82;
            // 
            // textBox41
            // 
            this.textBox41.Location = new System.Drawing.Point(495, 486);
            this.textBox41.Name = "textBox41";
            this.textBox41.Size = new System.Drawing.Size(68, 23);
            this.textBox41.TabIndex = 81;
            // 
            // textBox42
            // 
            this.textBox42.Location = new System.Drawing.Point(495, 459);
            this.textBox42.Name = "textBox42";
            this.textBox42.Size = new System.Drawing.Size(68, 23);
            this.textBox42.TabIndex = 80;
            // 
            // textBox43
            // 
            this.textBox43.Location = new System.Drawing.Point(495, 432);
            this.textBox43.Name = "textBox43";
            this.textBox43.Size = new System.Drawing.Size(68, 23);
            this.textBox43.TabIndex = 79;
            // 
            // textBox44
            // 
            this.textBox44.Location = new System.Drawing.Point(495, 405);
            this.textBox44.Name = "textBox44";
            this.textBox44.Size = new System.Drawing.Size(68, 23);
            this.textBox44.TabIndex = 78;
            // 
            // textBox45
            // 
            this.textBox45.Location = new System.Drawing.Point(495, 377);
            this.textBox45.Name = "textBox45";
            this.textBox45.Size = new System.Drawing.Size(68, 23);
            this.textBox45.TabIndex = 77;
            // 
            // textBox46
            // 
            this.textBox46.Location = new System.Drawing.Point(495, 350);
            this.textBox46.Name = "textBox46";
            this.textBox46.Size = new System.Drawing.Size(68, 23);
            this.textBox46.TabIndex = 76;
            // 
            // label67
            // 
            this.label67.AutoSize = true;
            this.label67.Location = new System.Drawing.Point(906, 330);
            this.label67.Name = "label67";
            this.label67.Size = new System.Drawing.Size(32, 17);
            this.label67.TabIndex = 75;
            this.label67.Text = "方向";
            // 
            // label66
            // 
            this.label66.AutoSize = true;
            this.label66.Location = new System.Drawing.Point(648, 330);
            this.label66.Name = "label66";
            this.label66.Size = new System.Drawing.Size(56, 17);
            this.label66.TabIndex = 74;
            this.label66.Text = "七轴力矩";
            // 
            // label65
            // 
            this.label65.AutoSize = true;
            this.label65.Location = new System.Drawing.Point(425, 330);
            this.label65.Name = "label65";
            this.label65.Size = new System.Drawing.Size(56, 17);
            this.label65.TabIndex = 73;
            this.label65.Text = "七轴速度";
            // 
            // label63
            // 
            this.label63.AutoSize = true;
            this.label63.Location = new System.Drawing.Point(353, 330);
            this.label63.Name = "label63";
            this.label63.Size = new System.Drawing.Size(56, 17);
            this.label63.TabIndex = 72;
            this.label63.Text = "七轴角度";
            // 
            // textBox38
            // 
            this.textBox38.Location = new System.Drawing.Point(642, 513);
            this.textBox38.Name = "textBox38";
            this.textBox38.Size = new System.Drawing.Size(68, 23);
            this.textBox38.TabIndex = 71;
            // 
            // textBox39
            // 
            this.textBox39.Location = new System.Drawing.Point(421, 513);
            this.textBox39.Name = "textBox39";
            this.textBox39.Size = new System.Drawing.Size(68, 23);
            this.textBox39.TabIndex = 70;
            // 
            // textBox40
            // 
            this.textBox40.Location = new System.Drawing.Point(347, 513);
            this.textBox40.Name = "textBox40";
            this.textBox40.Size = new System.Drawing.Size(68, 23);
            this.textBox40.TabIndex = 69;
            // 
            // label64
            // 
            this.label64.AutoSize = true;
            this.label64.Location = new System.Drawing.Point(271, 516);
            this.label64.Name = "label64";
            this.label64.Size = new System.Drawing.Size(68, 17);
            this.label64.TabIndex = 68;
            this.label64.Text = "七轴数据：";
            // 
            // textBox33
            // 
            this.textBox33.Location = new System.Drawing.Point(886, 486);
            this.textBox33.Name = "textBox33";
            this.textBox33.Size = new System.Drawing.Size(68, 23);
            this.textBox33.TabIndex = 66;
            // 
            // textBox34
            // 
            this.textBox34.Location = new System.Drawing.Point(642, 486);
            this.textBox34.Name = "textBox34";
            this.textBox34.Size = new System.Drawing.Size(68, 23);
            this.textBox34.TabIndex = 65;
            // 
            // textBox35
            // 
            this.textBox35.Location = new System.Drawing.Point(421, 486);
            this.textBox35.Name = "textBox35";
            this.textBox35.Size = new System.Drawing.Size(68, 23);
            this.textBox35.TabIndex = 64;
            // 
            // textBox36
            // 
            this.textBox36.Location = new System.Drawing.Point(347, 486);
            this.textBox36.Name = "textBox36";
            this.textBox36.Size = new System.Drawing.Size(68, 23);
            this.textBox36.TabIndex = 63;
            // 
            // label62
            // 
            this.label62.AutoSize = true;
            this.label62.Location = new System.Drawing.Point(271, 489);
            this.label62.Name = "label62";
            this.label62.Size = new System.Drawing.Size(68, 17);
            this.label62.TabIndex = 62;
            this.label62.Text = "六轴数据：";
            // 
            // textBox29
            // 
            this.textBox29.Location = new System.Drawing.Point(886, 459);
            this.textBox29.Name = "textBox29";
            this.textBox29.Size = new System.Drawing.Size(68, 23);
            this.textBox29.TabIndex = 60;
            // 
            // textBox30
            // 
            this.textBox30.Location = new System.Drawing.Point(642, 459);
            this.textBox30.Name = "textBox30";
            this.textBox30.Size = new System.Drawing.Size(68, 23);
            this.textBox30.TabIndex = 59;
            // 
            // textBox31
            // 
            this.textBox31.Location = new System.Drawing.Point(421, 459);
            this.textBox31.Name = "textBox31";
            this.textBox31.Size = new System.Drawing.Size(68, 23);
            this.textBox31.TabIndex = 58;
            // 
            // textBox32
            // 
            this.textBox32.Location = new System.Drawing.Point(347, 459);
            this.textBox32.Name = "textBox32";
            this.textBox32.Size = new System.Drawing.Size(68, 23);
            this.textBox32.TabIndex = 57;
            // 
            // label60
            // 
            this.label60.AutoSize = true;
            this.label60.Location = new System.Drawing.Point(271, 462);
            this.label60.Name = "label60";
            this.label60.Size = new System.Drawing.Size(68, 17);
            this.label60.TabIndex = 56;
            this.label60.Text = "五轴数据：";
            // 
            // textBox25
            // 
            this.textBox25.Location = new System.Drawing.Point(886, 432);
            this.textBox25.Name = "textBox25";
            this.textBox25.Size = new System.Drawing.Size(68, 23);
            this.textBox25.TabIndex = 54;
            // 
            // textBox26
            // 
            this.textBox26.Location = new System.Drawing.Point(642, 432);
            this.textBox26.Name = "textBox26";
            this.textBox26.Size = new System.Drawing.Size(68, 23);
            this.textBox26.TabIndex = 53;
            // 
            // textBox27
            // 
            this.textBox27.Location = new System.Drawing.Point(421, 432);
            this.textBox27.Name = "textBox27";
            this.textBox27.Size = new System.Drawing.Size(68, 23);
            this.textBox27.TabIndex = 52;
            // 
            // textBox28
            // 
            this.textBox28.Location = new System.Drawing.Point(347, 432);
            this.textBox28.Name = "textBox28";
            this.textBox28.Size = new System.Drawing.Size(68, 23);
            this.textBox28.TabIndex = 51;
            // 
            // label58
            // 
            this.label58.AutoSize = true;
            this.label58.Location = new System.Drawing.Point(271, 435);
            this.label58.Name = "label58";
            this.label58.Size = new System.Drawing.Size(68, 17);
            this.label58.TabIndex = 50;
            this.label58.Text = "四轴数据：";
            // 
            // textBox21
            // 
            this.textBox21.Location = new System.Drawing.Point(886, 405);
            this.textBox21.Name = "textBox21";
            this.textBox21.Size = new System.Drawing.Size(68, 23);
            this.textBox21.TabIndex = 48;
            // 
            // textBox22
            // 
            this.textBox22.Location = new System.Drawing.Point(642, 405);
            this.textBox22.Name = "textBox22";
            this.textBox22.Size = new System.Drawing.Size(68, 23);
            this.textBox22.TabIndex = 47;
            // 
            // textBox23
            // 
            this.textBox23.Location = new System.Drawing.Point(421, 405);
            this.textBox23.Name = "textBox23";
            this.textBox23.Size = new System.Drawing.Size(68, 23);
            this.textBox23.TabIndex = 46;
            // 
            // textBox24
            // 
            this.textBox24.Location = new System.Drawing.Point(347, 405);
            this.textBox24.Name = "textBox24";
            this.textBox24.Size = new System.Drawing.Size(68, 23);
            this.textBox24.TabIndex = 45;
            // 
            // label56
            // 
            this.label56.AutoSize = true;
            this.label56.Location = new System.Drawing.Point(271, 408);
            this.label56.Name = "label56";
            this.label56.Size = new System.Drawing.Size(68, 17);
            this.label56.TabIndex = 44;
            this.label56.Text = "三轴数据：";
            // 
            // textBox17
            // 
            this.textBox17.Location = new System.Drawing.Point(886, 377);
            this.textBox17.Name = "textBox17";
            this.textBox17.Size = new System.Drawing.Size(68, 23);
            this.textBox17.TabIndex = 42;
            // 
            // textBox18
            // 
            this.textBox18.Location = new System.Drawing.Point(642, 377);
            this.textBox18.Name = "textBox18";
            this.textBox18.Size = new System.Drawing.Size(68, 23);
            this.textBox18.TabIndex = 41;
            // 
            // textBox19
            // 
            this.textBox19.Location = new System.Drawing.Point(421, 377);
            this.textBox19.Name = "textBox19";
            this.textBox19.Size = new System.Drawing.Size(68, 23);
            this.textBox19.TabIndex = 40;
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(347, 377);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(68, 23);
            this.textBox20.TabIndex = 39;
            // 
            // label54
            // 
            this.label54.AutoSize = true;
            this.label54.Location = new System.Drawing.Point(271, 380);
            this.label54.Name = "label54";
            this.label54.Size = new System.Drawing.Size(68, 17);
            this.label54.TabIndex = 38;
            this.label54.Text = "二轴数据：";
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(886, 350);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(68, 23);
            this.textBox16.TabIndex = 36;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(642, 350);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(68, 23);
            this.textBox15.TabIndex = 35;
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(421, 350);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(68, 23);
            this.textBox14.TabIndex = 34;
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(347, 350);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(68, 23);
            this.textBox13.TabIndex = 33;
            // 
            // label51
            // 
            this.label51.AutoSize = true;
            this.label51.Location = new System.Drawing.Point(271, 353);
            this.label51.Name = "label51";
            this.label51.Size = new System.Drawing.Size(68, 17);
            this.label51.TabIndex = 32;
            this.label51.Text = "一轴数据：";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(347, 281);
            this.textBox12.Multiline = true;
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(604, 42);
            this.textBox12.TabIndex = 31;
            // 
            // label50
            // 
            this.label50.AutoSize = true;
            this.label50.Location = new System.Drawing.Point(271, 284);
            this.label50.Name = "label50";
            this.label50.Size = new System.Drawing.Size(68, 17);
            this.label50.TabIndex = 30;
            this.label50.Text = "错误信息：";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(347, 227);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.Size = new System.Drawing.Size(604, 42);
            this.textBox11.TabIndex = 29;
            // 
            // label45
            // 
            this.label45.AutoSize = true;
            this.label45.Location = new System.Drawing.Point(271, 230);
            this.label45.Name = "label45";
            this.label45.Size = new System.Drawing.Size(47, 17);
            this.label45.TabIndex = 28;
            this.label45.Text = "IoIIn：";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(347, 172);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.Size = new System.Drawing.Size(604, 42);
            this.textBox10.TabIndex = 27;
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Location = new System.Drawing.Point(271, 175);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(57, 17);
            this.label44.TabIndex = 26;
            this.label44.Text = "IoIOut：";
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(347, 119);
            this.textBox9.Multiline = true;
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(604, 42);
            this.textBox9.TabIndex = 25;
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.Location = new System.Drawing.Point(271, 122);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(52, 17);
            this.label43.TabIndex = 24;
            this.label43.Text = "IoDIn：";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(347, 69);
            this.textBox8.Multiline = true;
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(604, 42);
            this.textBox8.TabIndex = 23;
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(271, 72);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(62, 17);
            this.label42.TabIndex = 22;
            this.label42.Text = "IoDOut：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.label72);
            this.groupBox1.Controls.Add(this.label73);
            this.groupBox1.Controls.Add(this.label48);
            this.groupBox1.Controls.Add(this.label49);
            this.groupBox1.Controls.Add(this.label46);
            this.groupBox1.Controls.Add(this.label47);
            this.groupBox1.Controls.Add(this.label40);
            this.groupBox1.Controls.Add(this.label41);
            this.groupBox1.Controls.Add(this.label39);
            this.groupBox1.Controls.Add(this.label36);
            this.groupBox1.Controls.Add(this.label37);
            this.groupBox1.Controls.Add(this.label38);
            this.groupBox1.Controls.Add(this.label33);
            this.groupBox1.Controls.Add(this.label34);
            this.groupBox1.Controls.Add(this.label35);
            this.groupBox1.Controls.Add(this.label30);
            this.groupBox1.Controls.Add(this.label31);
            this.groupBox1.Controls.Add(this.label32);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.label29);
            this.groupBox1.Controls.Add(this.label24);
            this.groupBox1.Controls.Add(this.label25);
            this.groupBox1.Controls.Add(this.label26);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label22);
            this.groupBox1.Controls.Add(this.label23);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label18);
            this.groupBox1.Controls.Add(this.label19);
            this.groupBox1.Controls.Add(this.label14);
            this.groupBox1.Controls.Add(this.label15);
            this.groupBox1.Controls.Add(this.label16);
            this.groupBox1.Controls.Add(this.label13);
            this.groupBox1.Controls.Add(this.label12);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Location = new System.Drawing.Point(11, 66);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(243, 471);
            this.groupBox1.TabIndex = 21;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "状态";
            // 
            // label72
            // 
            this.label72.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label72.Location = new System.Drawing.Point(101, 398);
            this.label72.Name = "label72";
            this.label72.Size = new System.Drawing.Size(120, 19);
            this.label72.TabIndex = 35;
            this.label72.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label73
            // 
            this.label73.AutoSize = true;
            this.label73.Location = new System.Drawing.Point(9, 399);
            this.label73.Name = "label73";
            this.label73.Size = new System.Drawing.Size(92, 17);
            this.label73.TabIndex = 34;
            this.label73.Text = "设备开机总长：";
            // 
            // label48
            // 
            this.label48.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label48.Location = new System.Drawing.Point(101, 370);
            this.label48.Name = "label48";
            this.label48.Size = new System.Drawing.Size(120, 19);
            this.label48.TabIndex = 33;
            this.label48.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label49
            // 
            this.label49.AutoSize = true;
            this.label49.Location = new System.Drawing.Point(9, 371);
            this.label49.Name = "label49";
            this.label49.Size = new System.Drawing.Size(80, 17);
            this.label49.TabIndex = 32;
            this.label49.Text = "加载程序名：";
            // 
            // label46
            // 
            this.label46.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label46.Location = new System.Drawing.Point(101, 341);
            this.label46.Name = "label46";
            this.label46.Size = new System.Drawing.Size(120, 19);
            this.label46.TabIndex = 31;
            this.label46.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label47
            // 
            this.label47.AutoSize = true;
            this.label47.Location = new System.Drawing.Point(9, 342);
            this.label47.Name = "label47";
            this.label47.Size = new System.Drawing.Size(80, 17);
            this.label47.TabIndex = 30;
            this.label47.Text = "加载工程名：";
            // 
            // label40
            // 
            this.label40.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label40.Location = new System.Drawing.Point(101, 313);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(120, 19);
            this.label40.TabIndex = 29;
            this.label40.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(9, 314);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(68, 17);
            this.label41.TabIndex = 28;
            this.label41.Text = "速度状态：";
            // 
            // label39
            // 
            this.label39.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label39.Location = new System.Drawing.Point(12, 283);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(59, 19);
            this.label39.TabIndex = 27;
            this.label39.Text = "手动";
            this.label39.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label36
            // 
            this.label36.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label36.Location = new System.Drawing.Point(162, 283);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(59, 19);
            this.label36.TabIndex = 26;
            this.label36.Text = "远程";
            this.label36.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label37
            // 
            this.label37.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label37.Location = new System.Drawing.Point(87, 283);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(59, 19);
            this.label37.TabIndex = 25;
            this.label37.Text = "自动";
            this.label37.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(9, 257);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(44, 17);
            this.label38.TabIndex = 24;
            this.label38.Text = "模式：";
            // 
            // label33
            // 
            this.label33.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label33.Location = new System.Drawing.Point(166, 212);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(59, 19);
            this.label33.TabIndex = 23;
            this.label33.Text = "无暂停";
            this.label33.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label34
            // 
            this.label34.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label34.Location = new System.Drawing.Point(101, 212);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(59, 19);
            this.label34.TabIndex = 22;
            this.label34.Text = "暂停中";
            this.label34.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(9, 213);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(92, 17);
            this.label35.TabIndex = 21;
            this.label35.Text = "程序暂停状态：";
            // 
            // label30
            // 
            this.label30.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label30.Location = new System.Drawing.Point(166, 185);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(59, 19);
            this.label30.TabIndex = 20;
            this.label30.Text = "未加载";
            this.label30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label31
            // 
            this.label31.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label31.Location = new System.Drawing.Point(101, 185);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(59, 19);
            this.label31.TabIndex = 19;
            this.label31.Text = "有加载";
            this.label31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(9, 186);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(92, 17);
            this.label32.TabIndex = 18;
            this.label32.Text = "程序加载状态：";
            // 
            // label27
            // 
            this.label27.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label27.Location = new System.Drawing.Point(166, 158);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(59, 19);
            this.label27.TabIndex = 17;
            this.label27.Text = "未运行";
            this.label27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label28
            // 
            this.label28.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label28.Location = new System.Drawing.Point(101, 158);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(59, 19);
            this.label28.TabIndex = 16;
            this.label28.Text = "有运行";
            this.label28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(9, 159);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(92, 17);
            this.label29.TabIndex = 15;
            this.label29.Text = "程序运行状态：";
            // 
            // label24
            // 
            this.label24.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label24.Location = new System.Drawing.Point(166, 131);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(59, 19);
            this.label24.TabIndex = 14;
            this.label24.Text = "未运动";
            this.label24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label25
            // 
            this.label25.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label25.Location = new System.Drawing.Point(101, 131);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(59, 19);
            this.label25.TabIndex = 13;
            this.label25.Text = "有运动";
            this.label25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(9, 132);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(80, 17);
            this.label26.TabIndex = 12;
            this.label26.Text = "轴运动状态：";
            // 
            // label21
            // 
            this.label21.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label21.Location = new System.Drawing.Point(166, 103);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(59, 19);
            this.label21.TabIndex = 11;
            this.label21.Text = "未使能";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label22
            // 
            this.label22.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label22.Location = new System.Drawing.Point(101, 103);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(59, 19);
            this.label22.TabIndex = 10;
            this.label22.Text = "有使能";
            this.label22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(9, 104);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(68, 17);
            this.label23.TabIndex = 9;
            this.label23.Text = "伺服状态：";
            // 
            // label17
            // 
            this.label17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label17.Location = new System.Drawing.Point(166, 76);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(59, 19);
            this.label17.TabIndex = 8;
            this.label17.Text = "无权限";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label18
            // 
            this.label18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label18.Location = new System.Drawing.Point(101, 76);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(59, 19);
            this.label18.TabIndex = 7;
            this.label18.Text = "有权限";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(9, 77);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(68, 17);
            this.label19.TabIndex = 6;
            this.label19.Text = "权限状态：";
            // 
            // label14
            // 
            this.label14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label14.Location = new System.Drawing.Point(166, 48);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 19);
            this.label14.TabIndex = 5;
            this.label14.Text = "有急停";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label15
            // 
            this.label15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label15.Location = new System.Drawing.Point(101, 48);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(59, 19);
            this.label15.TabIndex = 4;
            this.label15.Text = "无急停";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 49);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(68, 17);
            this.label16.TabIndex = 3;
            this.label16.Text = "急停状态：";
            // 
            // label13
            // 
            this.label13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label13.Location = new System.Drawing.Point(166, 21);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(59, 19);
            this.label13.TabIndex = 2;
            this.label13.Text = "报警中";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label12
            // 
            this.label12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.label12.Location = new System.Drawing.Point(101, 21);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 19);
            this.label12.TabIndex = 1;
            this.label12.Text = "无报警";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 22);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 17);
            this.label11.TabIndex = 0;
            this.label11.Text = "报警状态：";
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(570, 40);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(89, 23);
            this.textBox7.TabIndex = 20;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(494, 43);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(68, 17);
            this.label10.TabIndex = 19;
            this.label10.Text = "数据心跳：";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(386, 40);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(89, 23);
            this.textBox6.TabIndex = 18;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(310, 43);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(68, 17);
            this.label9.TabIndex = 17;
            this.label9.Text = "数据命令：";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(741, 40);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(197, 23);
            this.textBox5.TabIndex = 16;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(665, 43);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(68, 17);
            this.label8.TabIndex = 15;
            this.label8.Text = "报文结束：";
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(84, 40);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(197, 23);
            this.textBox4.TabIndex = 14;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(8, 43);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(68, 17);
            this.label7.TabIndex = 13;
            this.label7.Text = "报文开始：";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(395, 8);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(109, 28);
            this.button3.TabIndex = 12;
            this.button3.Text = "开始";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(289, 11);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(89, 23);
            this.textBox3.TabIndex = 11;
            this.textBox3.Text = "1000";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(213, 14);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(68, 17);
            this.label6.TabIndex = 10;
            this.label6.Text = "定时刷新：";
            // 
            // button_read_short
            // 
            this.button_read_short.Location = new System.Drawing.Point(11, 8);
            this.button_read_short.Name = "button_read_short";
            this.button_read_short.Size = new System.Drawing.Size(109, 28);
            this.button_read_short.TabIndex = 9;
            this.button_read_short.Text = "刷新数据";
            this.button_read_short.UseVisualStyleBackColor = true;
            this.button_read_short.Click += new System.EventHandler(this.button_read_short_Click);
            // 
            // label61
            // 
            this.label61.AutoSize = true;
            this.label61.Location = new System.Drawing.Point(863, 489);
            this.label61.Name = "label61";
            this.label61.Size = new System.Drawing.Size(28, 17);
            this.label61.TabIndex = 67;
            this.label61.Text = "C：";
            // 
            // label59
            // 
            this.label59.AutoSize = true;
            this.label59.Location = new System.Drawing.Point(863, 462);
            this.label59.Name = "label59";
            this.label59.Size = new System.Drawing.Size(28, 17);
            this.label59.TabIndex = 61;
            this.label59.Text = "B：";
            // 
            // label57
            // 
            this.label57.AutoSize = true;
            this.label57.Location = new System.Drawing.Point(863, 435);
            this.label57.Name = "label57";
            this.label57.Size = new System.Drawing.Size(28, 17);
            this.label57.TabIndex = 55;
            this.label57.Text = "A：";
            // 
            // label55
            // 
            this.label55.AutoSize = true;
            this.label55.Location = new System.Drawing.Point(863, 408);
            this.label55.Name = "label55";
            this.label55.Size = new System.Drawing.Size(27, 17);
            this.label55.TabIndex = 49;
            this.label55.Text = "Z：";
            // 
            // label53
            // 
            this.label53.AutoSize = true;
            this.label53.Location = new System.Drawing.Point(863, 380);
            this.label53.Name = "label53";
            this.label53.Size = new System.Drawing.Size(27, 17);
            this.label53.TabIndex = 43;
            this.label53.Text = "Y：";
            // 
            // label52
            // 
            this.label52.AutoSize = true;
            this.label52.Location = new System.Drawing.Point(863, 353);
            this.label52.Name = "label52";
            this.label52.Size = new System.Drawing.Size(28, 17);
            this.label52.TabIndex = 37;
            this.label52.Text = "X：";
            // 
            // userControlHead1
            // 
            this.userControlHead1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.userControlHead1.Dock = System.Windows.Forms.DockStyle.Top;
            this.userControlHead1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userControlHead1.Location = new System.Drawing.Point(0, 0);
            this.userControlHead1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userControlHead1.MinimumSize = new System.Drawing.Size(800, 32);
            this.userControlHead1.Name = "userControlHead1";
            this.userControlHead1.ProtocolInfo = "new";
            this.userControlHead1.Size = new System.Drawing.Size(1004, 32);
            this.userControlHead1.TabIndex = 14;
            this.userControlHead1.SaveConnectEvent += new System.EventHandler<System.EventArgs>(this.userControlHead1_SaveConnectEvent_1);
            // 
            // FormEfort
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1004, 645);
            this.Controls.Add(this.userControlHead1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormEfort";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "埃夫特机器人(新版，报文对齐)";
            this.Load += new System.EventHandler(this.FormEfort_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button button_read_short;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox38;
        private System.Windows.Forms.TextBox textBox39;
        private System.Windows.Forms.TextBox textBox40;
        private System.Windows.Forms.Label label64;
        private System.Windows.Forms.Label label61;
        private System.Windows.Forms.TextBox textBox33;
        private System.Windows.Forms.TextBox textBox34;
        private System.Windows.Forms.TextBox textBox35;
        private System.Windows.Forms.TextBox textBox36;
        private System.Windows.Forms.Label label62;
        private System.Windows.Forms.Label label59;
        private System.Windows.Forms.TextBox textBox29;
        private System.Windows.Forms.TextBox textBox30;
        private System.Windows.Forms.TextBox textBox31;
        private System.Windows.Forms.TextBox textBox32;
        private System.Windows.Forms.Label label60;
        private System.Windows.Forms.Label label57;
        private System.Windows.Forms.TextBox textBox25;
        private System.Windows.Forms.TextBox textBox26;
        private System.Windows.Forms.TextBox textBox27;
        private System.Windows.Forms.TextBox textBox28;
        private System.Windows.Forms.Label label58;
        private System.Windows.Forms.Label label55;
        private System.Windows.Forms.TextBox textBox21;
        private System.Windows.Forms.TextBox textBox22;
        private System.Windows.Forms.TextBox textBox23;
        private System.Windows.Forms.TextBox textBox24;
        private System.Windows.Forms.Label label56;
        private System.Windows.Forms.Label label53;
        private System.Windows.Forms.TextBox textBox17;
        private System.Windows.Forms.TextBox textBox18;
        private System.Windows.Forms.TextBox textBox19;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label54;
        private System.Windows.Forms.Label label52;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label51;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label50;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label45;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label44;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label48;
        private System.Windows.Forms.Label label49;
        private System.Windows.Forms.Label label46;
        private System.Windows.Forms.Label label47;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label63;
        private System.Windows.Forms.Label label65;
        private System.Windows.Forms.Label label67;
        private System.Windows.Forms.Label label66;
        private System.Windows.Forms.Label label71;
        private System.Windows.Forms.TextBox textBox61;
        private System.Windows.Forms.TextBox textBox62;
        private System.Windows.Forms.TextBox textBox63;
        private System.Windows.Forms.TextBox textBox64;
        private System.Windows.Forms.TextBox textBox65;
        private System.Windows.Forms.TextBox textBox66;
        private System.Windows.Forms.TextBox textBox67;
        private System.Windows.Forms.Label label70;
        private System.Windows.Forms.TextBox textBox54;
        private System.Windows.Forms.TextBox textBox55;
        private System.Windows.Forms.TextBox textBox56;
        private System.Windows.Forms.TextBox textBox57;
        private System.Windows.Forms.TextBox textBox58;
        private System.Windows.Forms.TextBox textBox59;
        private System.Windows.Forms.TextBox textBox60;
        private System.Windows.Forms.Label label69;
        private System.Windows.Forms.TextBox textBox47;
        private System.Windows.Forms.TextBox textBox48;
        private System.Windows.Forms.TextBox textBox49;
        private System.Windows.Forms.TextBox textBox50;
        private System.Windows.Forms.TextBox textBox51;
        private System.Windows.Forms.TextBox textBox52;
        private System.Windows.Forms.TextBox textBox53;
        private System.Windows.Forms.Label label68;
        private System.Windows.Forms.TextBox textBox37;
        private System.Windows.Forms.TextBox textBox41;
        private System.Windows.Forms.TextBox textBox42;
        private System.Windows.Forms.TextBox textBox43;
        private System.Windows.Forms.TextBox textBox44;
        private System.Windows.Forms.TextBox textBox45;
        private System.Windows.Forms.TextBox textBox46;
        private System.Windows.Forms.Label label72;
        private System.Windows.Forms.Label label73;
        private System.Windows.Forms.Label label74;
        private DemoControl.UserControlHead userControlHead1;
    }
}