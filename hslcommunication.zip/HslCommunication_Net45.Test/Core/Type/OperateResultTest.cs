﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HslCommunication_Net45.Test.Core
{
    [TestClass]
    public class OperateResultTest
    {
        [TestMethod]
        public void OperateResultUnitTest( )
        {
            OperateResult<bool> boolResult = OperateResult.CreateSuccessResult( true );
            Assert.IsTrue( boolResult.Check( m => m == true ).IsSuccess );
            Assert.IsFalse( boolResult.Check( m => m == false ).IsSuccess );
            boolResult = OperateResult.CreateSuccessResult( false );
            Assert.IsFalse( boolResult.Check( m => m == true ).IsSuccess );
            Assert.IsTrue( boolResult.Check( m => m == false ).IsSuccess );
        }
    }
}
