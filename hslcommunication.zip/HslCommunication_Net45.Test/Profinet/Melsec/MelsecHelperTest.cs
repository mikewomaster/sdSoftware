﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication;
using HslCommunication.Profinet.Melsec;

namespace HslCommunication_Net45.Test.Profinet.Melsec
{
    [TestClass]
    public class MelsecHelperTest
    {
        [TestMethod]
        public void Test1( )
        {
            byte[] mc = MelsecHelper.BuildReadTag( new string[] { "Lbl[2]" }, new ushort[] { 5 } );
            byte[] corrent = new byte[] { 0x1A, 0x04, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00, 0x06, 0x00, 0x4C, 0x00, 0x62, 0x00, 0x6C, 0x00, 0x5B, 0x00, 0x32, 0x00, 0x5D, 0x00, 0x01, 0x00, 0x0A, 0x00 };

            if(!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( mc, corrent ))
            {
                Console.WriteLine( HslCommunication.BasicFramework.SoftBasic.ByteToHexString( mc, ' ' ) );
                Console.WriteLine( HslCommunication.BasicFramework.SoftBasic.ByteToHexString( corrent, ' ' ) );
            }
            Assert.IsTrue( HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( mc, corrent ) );
        }

    }
}
