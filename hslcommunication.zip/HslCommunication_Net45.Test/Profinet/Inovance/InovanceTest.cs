﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.Profinet.Inovance;
using HslCommunication.ModBus;

namespace HslCommunication_Net45.Test.Profinet.Inovance
{
	[TestClass]
	public class InovanceTest
	{
		[TestMethod]
		public void Test1( )
		{
			OperateResult<string> add = InovanceHelper.PraseInovanceAMAddress( "QX1.1", ModbusInfo.ReadCoil );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "9" );

			add = InovanceHelper.PraseInovanceAMAddress( "IX1.1", ModbusInfo.ReadCoil );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=2;9" );

			add = InovanceHelper.PraseInovanceAMAddress( "MW20", ModbusInfo.ReadRegister );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "20" );

			add = InovanceHelper.PraseInovanceAMAddress( "SMX1.1", ModbusInfo.ReadCoil );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=49;9" );

			add = InovanceHelper.PraseInovanceAMAddress( "SMX1.1", ModbusInfo.WriteOneCoil );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=53;9" );

			add = InovanceHelper.PraseInovanceAMAddress( "SMX1.1", ModbusInfo.WriteCoil );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=63;9" );

			add = InovanceHelper.PraseInovanceAMAddress( "SDW10", ModbusInfo.ReadRegister );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=51;10" );

			add = InovanceHelper.PraseInovanceAMAddress( "SDW10", ModbusInfo.WriteOneRegister );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=54;10" );

			add = InovanceHelper.PraseInovanceAMAddress( "SDW10", ModbusInfo.WriteRegister );
			Assert.IsTrue( add.IsSuccess );
			Assert.IsTrue( add.Content == "x=64;10" );

		}


	}
}
