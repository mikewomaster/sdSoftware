﻿using HslCommunication.BasicFramework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HslCommunication_Net45.Test.Documentation.Samples.BasicFramework
{
	public class SoftIncrementCountSample
	{
		public void Sample1( )
		{
			#region Sample1

			// 举例一个从0-65535的例子
			SoftIncrementCount softIncrement = new SoftIncrementCount( ushort.MaxValue );

			long call1 = softIncrement.GetCurrentValue( );     // 获得0，下次调用为1
			long call2 = softIncrement.GetCurrentValue( );     // 获得1，下次调用为2
			long call3 = softIncrement.GetCurrentValue( );     // 获得2，下次调用为3
															   // .....
			long call65536 = softIncrement.GetCurrentValue( ); // 获得65535，下次调用为0
			long call65537 = softIncrement.GetCurrentValue( ); // 获得0，下次调用为1
															   // 如此循环

			// 如果需要反向计数的话
			softIncrement = new SoftIncrementCount( ushort.MaxValue, 0, -1 );
			softIncrement.ResetCurrentValue( ushort.MaxValue );
			// 在获取的话就是  65535，65534，65533，......3,2,1,0

			#endregion
		}
		public void Sample2( )
		{
			#region Sample2

			// 举例一个从1000-2000的例子
			SoftIncrementCount softIncrement = new SoftIncrementCount( 2000, 1000 );

			long call1 = softIncrement.GetCurrentValue( );     // 获得1000，下次调用为1001
			long call2 = softIncrement.GetCurrentValue( );     // 获得1001，下次调用为1002
			long call3 = softIncrement.GetCurrentValue( );     // 获得1002，下次调用为1003
															   // .....
			long call2000 = softIncrement.GetCurrentValue( );  // 获得1999，下次调用为2000
			long call2001 = softIncrement.GetCurrentValue( );  // 获得2000，下次调用为1000
			long call2002 = softIncrement.GetCurrentValue( );  // 获得1000，下次调用为1000
															   // 如此循环

			// 如果需要反向计数的话
			softIncrement = new SoftIncrementCount( 2000, 1000, -1 );
			softIncrement.ResetCurrentValue( 2000 );
			// 在获取的话就是  2000，1999，1998，......3,2,1,0

			#endregion
		}

		public void Sample3( )
		{
			#region Sample3

			// 其他的例子说明
			SoftIncrementCount softIncrement = new SoftIncrementCount( 2000, 1000 );
			// 如果我们需要一直保持消息号在0，不需要增长的计数
			softIncrement.IncreaseTick = 0;

			// 同理，我们需要消息号保持在1000
			softIncrement.ResetCurrentValue( 1000 );
			softIncrement.IncreaseTick = 0;

			// 如果消息号需要为1,3,5,7,9,......999
			softIncrement.ResetStartValue( 1 );
			softIncrement.ResetMaxValue( 999 );
			softIncrement.IncreaseTick = 2;

			// 同理的操作，从999,997,995.....3,1
			softIncrement = new SoftIncrementCount( 999, 1 );
			softIncrement.ResetCurrentValue( 999 );
			softIncrement.IncreaseTick = -2;

			#endregion
		}
	}
}
