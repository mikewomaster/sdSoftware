﻿using HslCommunication.BasicFramework;
using HslCommunication.Core;
using HslCommunication.Serial;
using HslCommunication.Reflection;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.Profinet.LSIS
{
	/// <summary>
	/// XGB Cnet I/F module supports Serial Port.
	/// </summary>
	/// <remarks>
	/// <inheritdoc cref="XGBCnetOverTcp" path="remarks"/>
	/// </remarks>
	public class XGBCnet : SerialDeviceBase
	{
		#region Constructor

		/// <summary>
		/// Instantiate a Default object
		/// </summary>
		public XGBCnet()
		{
			ByteTransform = new RegularByteTransform( );
			WordLength    = 2;
		}

		#endregion

		#region Public Member

		/// <inheritdoc cref="XGBCnetOverTcp.Station"/>
		public byte Station { get; set; } = 0x05;

		#endregion

		#region Read Write Byte

		/// <inheritdoc cref="XGBCnetOverTcp.ReadByte(string)"/>
		[HslMqttApi( "ReadByte", "" )]
		public OperateResult<byte> ReadByte( string address ) => ByteTransformHelper.GetResultFromArray( Read( address, 2 ) );

		/// <inheritdoc cref="XGBCnetOverTcp.Write(string, byte)"/>
		[HslMqttApi( "WriteByte", "" )]
		public OperateResult Write(string address, byte value) => Write(address, new byte[] { value });

		#endregion

		#region Read Write Bool

		/// <inheritdoc/>
		[HslMqttApi( "ReadBoolArray", "" )]
		public override OperateResult<bool[]> ReadBool( string address, ushort length )
		{
			OperateResult<byte[]> command = XGBCnetOverTcp.BuildReadOneCommand( Station, address, length );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( command );

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( read );

			return OperateResult.CreateSuccessResult( SoftBasic.ByteToBoolArray( XGBCnetOverTcp.ExtractActualData( read.Content, true ).Content, length ) );
		}

		/// <inheritdoc cref="XGBCnetOverTcp.ReadCoil(string)"/>
		public OperateResult<bool> ReadCoil( string address ) => ReadBool( address );

		/// <inheritdoc cref="XGBCnetOverTcp.ReadCoil(string, ushort)"/>
		public OperateResult<bool[]> ReadCoil( string address, ushort length ) => ReadBool( address, length );

		/// <inheritdoc cref="WriteCoil(string, bool)"/>
		public OperateResult WriteCoil( string address, bool value ) => Write( address, value );

		/// <inheritdoc/>
		[HslMqttApi( "WriteBool", "" )]
		public override OperateResult Write( string address, bool value ) => Write( address, new byte[] { (byte)(value ? 0x01 : 0x00) } );

		#endregion

		#region Async Read Write Bool
#if !NET35 && !NET20
		/// <inheritdoc/>
		public override async Task<OperateResult> WriteAsync( string address, bool value ) => await WriteAsync( address, new byte[] { (byte)(value ? 0x01 : 0x00) } );
#endif
		#endregion

		#region Read Write Support

		/// <inheritdoc/>
		[HslMqttApi( "ReadByteArray", "" )]
		public override OperateResult<byte[]> Read(string address, ushort length)
		{
			OperateResult<byte[]> command = XGBCnetOverTcp.BuildReadCommand( Station, address, length );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase(command.Content);
			if (!read.IsSuccess) return read;

			return XGBCnetOverTcp.ExtractActualData(read.Content, true);
		}

		/// <inheritdoc/>
		[HslMqttApi( "WriteByteArray", "" )]
		public override OperateResult Write(string address, byte[] value)
		{
			OperateResult<byte[]> command = XGBCnetOverTcp.BuildWriteCommand( Station, address, value );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase(command.Content);
			if (!read.IsSuccess) return read;

			return XGBCnetOverTcp.ExtractActualData(read.Content, false);
		}

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString() => $"XGBCnet[{PortName}:{BaudRate}]";

		#endregion
	}
}
