﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace FileNetServer
{
	static class Program
	{
		/// <summary>
		/// 应用程序的主入口点。
		/// </summary>
		[STAThread]
		static void Main( )
		{
			System.Threading.ThreadPool.SetMaxThreads( 2000, 1000 );
			// 授权示例
			if (!HslCommunication.Authorization.SetAuthorizationCode( "你的激活码" ))
			{
				// MessageBox.Show( "授权失败！当前程序只能使用8小时！" );
				// return;
			}

			Application.EnableVisualStyles( );
			Application.SetCompatibleTextRenderingDefault( false );
			Application.Run( new FormFileServer( ) );
		}
	}
}
