﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication;
using HslCommunication.Robot.KUKA;

namespace HslCommunication_Net45.Test.Robot
{
    [TestClass]
    public class KukaTcpNetTest
    {
        [TestMethod]
        public void BuildReadCommandsTest( )
        {
            string build = KukaTcpNet.BuildReadCommands( new string[] { "$MODE_OP", "$IN_HOME" } );
            Assert.AreEqual( "00$MODE_OP,$IN_HOME", build );

            build = KukaTcpNet.BuildReadCommands( new string[] { "$MODE_OP" } );
            Assert.AreEqual( "00$MODE_OP", build );
        }

        [TestMethod]
        public void BuildWriteCommandsTest( )
        {
            string build = KukaTcpNet.BuildWriteCommands( new string[] { "$OUT[1]", "R1" }, new string[] { "TRUE", "123" } );
            Assert.AreEqual( "01$OUT[1]=TRUE,R1=123", build );

            build = KukaTcpNet.BuildWriteCommands( new string[] { "$OUT[1]" }, new string[] { "TRUE" } );
            Assert.AreEqual( "01$OUT[1]=TRUE", build );
        }
    }
}
