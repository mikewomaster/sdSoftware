﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Profinet.AllenBradley;
using HslCommunication;
using System.Text.RegularExpressions;

namespace HslCommunication_Net45.Test.Profinet.AllenBradley
{
    [TestClass]
    public class AllenBradleyHelperTest
    {

        [TestMethod]
        public void PackRequsetReadTest( )
        {
            byte[] corrent = new byte[] { 0x4c, 0x05, 0x91, 0x08, 0x53, 0x74, 0x61, 0x72, 0x74, 0x5f, 0x69, 0x6e, 0x01, 0x00 };

            byte[] buffer = AllenBradleyHelper.PackRequsetRead( "Start_in" , 1 );
            if (!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( buffer, corrent ))
            {
                Assert.Fail( "指令失败：" + HslCommunication.BasicFramework.SoftBasic.ByteToHexString( buffer ) );
            }
        }

        [TestMethod]
        public void PackRequestWriteTest( )
        {
            byte[] corrent = new byte[] { 0x4d, 0x02, 0x91, 0x02, 0x41, 0x31, 0xc4, 0x00, 0x01, 0x00, 0xd2, 0x04, 0x00, 0x00 };


            byte[] buffer = AllenBradleyHelper.PackRequestWrite( "A1", 0xc4, BitConverter.GetBytes(1234) );
            if (!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( buffer, corrent ))
            {
                Assert.Fail( "指令失败：" + HslCommunication.BasicFramework.SoftBasic.ByteToHexString( buffer ) );
            }
        }

        [TestMethod]
        public void AnalysisArrayIndexTest1( )
        {
            string a = AllenBradleyHelper.AnalysisArrayIndex( "A[1]", out int arrayIndex );
            Assert.AreEqual( "A", a );
            Assert.AreEqual( 1, arrayIndex );

            string pattern = @"\[[0-9]+\]$";
            Assert.IsTrue( Regex.IsMatch( "A[0]", pattern ) );
            Assert.IsTrue( Regex.IsMatch( "rrr[10]", pattern ) );
            Assert.IsFalse( Regex.IsMatch( "A", pattern ) );
            Assert.IsFalse( Regex.IsMatch( "A[", pattern ) );
            Assert.IsFalse( Regex.IsMatch( "A]", pattern ) );
        }

        [TestMethod]
        public void AnalysisArrayIndexTest2( )
        {
            string a = AllenBradleyHelper.AnalysisArrayIndex( "rrr[10]", out int arrayIndex );
            Assert.AreEqual( "rrr", a );
            Assert.AreEqual( 10, arrayIndex );
        }

        [TestMethod]
        public void AnalysisArrayIndexTest3( )
        {
            string a = AllenBradleyHelper.AnalysisArrayIndex( "rrr", out int arrayIndex );
            Assert.AreEqual( "rrr", a );
            Assert.AreEqual( 0, arrayIndex );
        }

        [TestMethod]
        public void PackRequestWriteBoolTest( )
        {
            byte[] corrent = new byte[] { 0x4e, 0x04, 0x91, 0x03, 0x72, 0x72, 0x72, 0x00, 0x28, 0x01, 
                0x04, 0x00, 0x01, 0x00, 0x00, 0x00, 0xff, 0xff, 0xff, 0xff };


            byte[] buffer = AllenBradleyHelper.PackRequestWrite( "rrr[32]", true );
            if (!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( buffer, corrent ))
            {
                Assert.Fail( "值不一样\r\n期望:" + corrent.ToHexString( ' ' ) + "\r\n实际:" + buffer.ToHexString( ' ' ) );
            }

            corrent = new byte[] { 0x4e, 0x04, 0x91, 0x03, 0x72, 0x72, 0x72, 0x00, 0x28, 0x01,
                0x04, 0x00, 0x00, 0x00, 0x04, 0x00, 0xff, 0xff, 0xff, 0xff };


            buffer = AllenBradleyHelper.PackRequestWrite( "rrr[50]", true );
            if (!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( buffer, corrent ))
            {
                Assert.Fail( "值不一样\r\n期望:" + corrent.ToHexString( ' ' ) + "\r\n实际:" + buffer.ToHexString( ' ' ) );
            }


            corrent = new byte[] { 0x4e, 0x04, 0x91, 0x03, 0x72, 0x72, 0x72, 0x00, 0x28, 0x01,
                0x04, 0x00, 0x00, 0x00, 0x00, 0x00, 0xff, 0xff, 0xfb, 0xff };


            buffer = AllenBradleyHelper.PackRequestWrite( "rrr[50]", false );
            if (!HslCommunication.BasicFramework.SoftBasic.IsTwoBytesEquel( buffer, corrent ))
            {
                Assert.Fail( "值不一样\r\n期望:" + corrent.ToHexString( ' ' ) + "\r\n实际:" + buffer.ToHexString( ' ' ) );
            }
        }

    }
}
