﻿namespace HslCommunicationDemo
{
    partial class FormModbusAlien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.checkBox1 = new System.Windows.Forms.CheckBox();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.button27 = new System.Windows.Forms.Button();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.textBox12 = new System.Windows.Forms.TextBox();
            this.label15 = new System.Windows.Forms.Label();
            this.userCurve1 = new HslCommunication.Controls.UserCurve();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.textBox11 = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.button26 = new System.Windows.Forms.Button();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.textBox10 = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.button25 = new System.Windows.Forms.Button();
            this.textBox9 = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.button3 = new System.Windows.Forms.Button();
            this.label19 = new System.Windows.Forms.Label();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.button_read_string = new System.Windows.Forms.Button();
            this.button_read_double = new System.Windows.Forms.Button();
            this.button_read_float = new System.Windows.Forms.Button();
            this.button_read_ulong = new System.Windows.Forms.Button();
            this.button_read_long = new System.Windows.Forms.Button();
            this.button_read_uint = new System.Windows.Forms.Button();
            this.button_read_int = new System.Windows.Forms.Button();
            this.button_read_ushort = new System.Windows.Forms.Button();
            this.button_read_short = new System.Windows.Forms.Button();
            this.button_read_bool = new System.Windows.Forms.Button();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.userControlHead1 = new HslCommunicationDemo.DemoControl.UserControlHead();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.textBox1);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.checkBox1);
            this.panel1.Controls.Add(this.textBox15);
            this.panel1.Controls.Add(this.label21);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.textBox2);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label22);
            this.panel1.Location = new System.Drawing.Point(14, 44);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(978, 42);
            this.panel1.TabIndex = 0;
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(460, 7);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(171, 23);
            this.textBox1.TabIndex = 11;
            this.textBox1.Text = "12345678901";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(399, 10);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 17);
            this.label1.TabIndex = 10;
            this.label1.Text = "DTU ID：";
            // 
            // checkBox1
            // 
            this.checkBox1.AutoSize = true;
            this.checkBox1.Checked = true;
            this.checkBox1.CheckState = System.Windows.Forms.CheckState.Checked;
            this.checkBox1.Location = new System.Drawing.Point(287, 9);
            this.checkBox1.Name = "checkBox1";
            this.checkBox1.Size = new System.Drawing.Size(106, 21);
            this.checkBox1.TabIndex = 9;
            this.checkBox1.Text = "首地址从0开始";
            this.checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(219, 7);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(58, 23);
            this.textBox15.TabIndex = 7;
            this.textBox15.Text = "1";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(165, 10);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(44, 17);
            this.label21.TabIndex = 6;
            this.label21.Text = "站号：";
            // 
            // button2
            // 
            this.button2.Enabled = false;
            this.button2.Location = new System.Drawing.Point(875, 4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(91, 28);
            this.button2.TabIndex = 5;
            this.button2.Text = "断开连接";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(772, 4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(91, 28);
            this.button1.TabIndex = 4;
            this.button1.Text = "创建";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(74, 7);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(76, 23);
            this.textBox2.TabIndex = 3;
            this.textBox2.Text = "10000";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(20, 10);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 2;
            this.label3.Text = "端口号：";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(639, 10);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(97, 17);
            this.label22.TabIndex = 12;
            this.label22.Text = "(11位ASCII字符)";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.groupBox5);
            this.panel2.Controls.Add(this.groupBox4);
            this.panel2.Controls.Add(this.groupBox3);
            this.panel2.Controls.Add(this.groupBox2);
            this.panel2.Controls.Add(this.groupBox1);
            this.panel2.Location = new System.Drawing.Point(14, 95);
            this.panel2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(978, 537);
            this.panel2.TabIndex = 1;
            // 
            // groupBox5
            // 
            this.groupBox5.Controls.Add(this.button27);
            this.groupBox5.Controls.Add(this.textBox14);
            this.groupBox5.Controls.Add(this.label18);
            this.groupBox5.Controls.Add(this.label17);
            this.groupBox5.Controls.Add(this.textBox12);
            this.groupBox5.Controls.Add(this.label15);
            this.groupBox5.Controls.Add(this.userCurve1);
            this.groupBox5.Location = new System.Drawing.Point(546, 243);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(419, 278);
            this.groupBox5.TabIndex = 4;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "定时读取，曲线显示";
            // 
            // button27
            // 
            this.button27.Location = new System.Drawing.Point(343, 25);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(70, 28);
            this.button27.TabIndex = 9;
            this.button27.Text = "启动";
            this.button27.UseVisualStyleBackColor = true;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(255, 28);
            this.textBox14.Name = "textBox14";
            this.textBox14.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox14.Size = new System.Drawing.Size(82, 23);
            this.textBox14.TabIndex = 8;
            this.textBox14.Text = "300";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(212, 30);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(44, 17);
            this.label18.TabIndex = 7;
            this.label18.Text = "间隔：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.label17.Location = new System.Drawing.Point(60, 53);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(218, 17);
            this.label17.TabIndex = 6;
            this.label17.Text = "此处假设确定了数据的类型，为short：";
            // 
            // textBox12
            // 
            this.textBox12.Location = new System.Drawing.Point(64, 27);
            this.textBox12.Name = "textBox12";
            this.textBox12.Size = new System.Drawing.Size(132, 23);
            this.textBox12.TabIndex = 5;
            this.textBox12.Text = "100";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(10, 30);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(44, 17);
            this.label15.TabIndex = 4;
            this.label15.Text = "地址：";
            // 
            // userCurve1
            // 
            this.userCurve1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(32)))), ((int)(((byte)(32)))), ((int)(((byte)(32)))));
            this.userCurve1.Location = new System.Drawing.Point(13, 82);
            this.userCurve1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userCurve1.Name = "userCurve1";
            this.userCurve1.Size = new System.Drawing.Size(400, 189);
            this.userCurve1.TabIndex = 0;
            this.userCurve1.ValueMaxLeft = 200F;
            this.userCurve1.ValueMaxRight = 200F;
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.textBox11);
            this.groupBox4.Controls.Add(this.label14);
            this.groupBox4.Controls.Add(this.button26);
            this.groupBox4.Controls.Add(this.textBox13);
            this.groupBox4.Controls.Add(this.label16);
            this.groupBox4.Location = new System.Drawing.Point(11, 403);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(518, 118);
            this.groupBox4.TabIndex = 3;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "报文读取测试，此处需要填入完整的16进制报文字符串";
            // 
            // textBox11
            // 
            this.textBox11.Location = new System.Drawing.Point(63, 60);
            this.textBox11.Multiline = true;
            this.textBox11.Name = "textBox11";
            this.textBox11.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox11.Size = new System.Drawing.Size(445, 52);
            this.textBox11.TabIndex = 10;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(9, 62);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(44, 17);
            this.label14.TabIndex = 9;
            this.label14.Text = "结果：";
            // 
            // button26
            // 
            this.button26.Location = new System.Drawing.Point(426, 24);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(82, 28);
            this.button26.TabIndex = 8;
            this.button26.Text = "报文读取";
            this.button26.UseVisualStyleBackColor = true;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(63, 27);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(357, 23);
            this.textBox13.TabIndex = 5;
            this.textBox13.Text = "00 00 00 00 00 06 FF 03 00 00 00 05";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(9, 30);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(44, 17);
            this.label16.TabIndex = 4;
            this.label16.Text = "报文：";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.textBox10);
            this.groupBox3.Controls.Add(this.label13);
            this.groupBox3.Controls.Add(this.button25);
            this.groupBox3.Controls.Add(this.textBox9);
            this.groupBox3.Controls.Add(this.label12);
            this.groupBox3.Controls.Add(this.textBox6);
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Location = new System.Drawing.Point(11, 243);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(518, 154);
            this.groupBox3.TabIndex = 2;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "批量读取测试";
            // 
            // textBox10
            // 
            this.textBox10.Location = new System.Drawing.Point(63, 60);
            this.textBox10.Multiline = true;
            this.textBox10.Name = "textBox10";
            this.textBox10.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox10.Size = new System.Drawing.Size(445, 78);
            this.textBox10.TabIndex = 10;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(9, 62);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(44, 17);
            this.label13.TabIndex = 9;
            this.label13.Text = "结果：";
            // 
            // button25
            // 
            this.button25.Location = new System.Drawing.Point(426, 24);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(82, 28);
            this.button25.TabIndex = 8;
            this.button25.Text = "批量读取";
            this.button25.UseVisualStyleBackColor = true;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // textBox9
            // 
            this.textBox9.Location = new System.Drawing.Point(239, 27);
            this.textBox9.Name = "textBox9";
            this.textBox9.Size = new System.Drawing.Size(102, 23);
            this.textBox9.TabIndex = 7;
            this.textBox9.Text = "10";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(185, 30);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(44, 17);
            this.label12.TabIndex = 6;
            this.label12.Text = "长度：";
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(63, 27);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(102, 23);
            this.textBox6.TabIndex = 5;
            this.textBox6.Text = "100";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(9, 30);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(44, 17);
            this.label11.TabIndex = 4;
            this.label11.Text = "地址：";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.button3);
            this.groupBox2.Controls.Add(this.label19);
            this.groupBox2.Controls.Add(this.button14);
            this.groupBox2.Controls.Add(this.button15);
            this.groupBox2.Controls.Add(this.button16);
            this.groupBox2.Controls.Add(this.button17);
            this.groupBox2.Controls.Add(this.button18);
            this.groupBox2.Controls.Add(this.button19);
            this.groupBox2.Controls.Add(this.button20);
            this.groupBox2.Controls.Add(this.button21);
            this.groupBox2.Controls.Add(this.button22);
            this.groupBox2.Controls.Add(this.button24);
            this.groupBox2.Controls.Add(this.textBox7);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.textBox8);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Location = new System.Drawing.Point(546, 3);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(419, 234);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "单数据写入测试";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(24, 187);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(184, 28);
            this.button3.TabIndex = 23;
            this.button3.Text = "压力测试，快速读写3000次";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button4_Click);
            // 
            // label19
            // 
            this.label19.ForeColor = System.Drawing.Color.Red;
            this.label19.Location = new System.Drawing.Point(61, 82);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(147, 41);
            this.label19.TabIndex = 17;
            this.label19.Text = "注意：值的字符串需要能转化成对应的数据类型";
            // 
            // button14
            // 
            this.button14.Location = new System.Drawing.Point(326, 197);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(82, 28);
            this.button14.TabIndex = 16;
            this.button14.Text = "字符串写入";
            this.button14.UseVisualStyleBackColor = true;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.Location = new System.Drawing.Point(326, 163);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(82, 28);
            this.button15.TabIndex = 15;
            this.button15.Text = "double写入";
            this.button15.UseVisualStyleBackColor = true;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.Location = new System.Drawing.Point(226, 163);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(82, 28);
            this.button16.TabIndex = 14;
            this.button16.Text = "float写入";
            this.button16.UseVisualStyleBackColor = true;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.Location = new System.Drawing.Point(326, 129);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(82, 28);
            this.button17.TabIndex = 13;
            this.button17.Text = "ulong写入";
            this.button17.UseVisualStyleBackColor = true;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.Location = new System.Drawing.Point(226, 129);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(82, 28);
            this.button18.TabIndex = 12;
            this.button18.Text = "long写入";
            this.button18.UseVisualStyleBackColor = true;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.Location = new System.Drawing.Point(326, 95);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(82, 28);
            this.button19.TabIndex = 11;
            this.button19.Text = "uint写入";
            this.button19.UseVisualStyleBackColor = true;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.Location = new System.Drawing.Point(226, 95);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(82, 28);
            this.button20.TabIndex = 10;
            this.button20.Text = "int写入";
            this.button20.UseVisualStyleBackColor = true;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.Location = new System.Drawing.Point(326, 61);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(82, 28);
            this.button21.TabIndex = 9;
            this.button21.Text = "ushort写入";
            this.button21.UseVisualStyleBackColor = true;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.Location = new System.Drawing.Point(226, 61);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(82, 28);
            this.button22.TabIndex = 8;
            this.button22.Text = "short写入";
            this.button22.UseVisualStyleBackColor = true;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button24
            // 
            this.button24.Location = new System.Drawing.Point(226, 24);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(82, 28);
            this.button24.TabIndex = 6;
            this.button24.Text = "线圈写入";
            this.button24.UseVisualStyleBackColor = true;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(63, 56);
            this.textBox7.Name = "textBox7";
            this.textBox7.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox7.Size = new System.Drawing.Size(132, 23);
            this.textBox7.TabIndex = 5;
            this.textBox7.Text = "False";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(9, 58);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(32, 17);
            this.label9.TabIndex = 4;
            this.label9.Text = "值：";
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(63, 27);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(132, 23);
            this.textBox8.TabIndex = 3;
            this.textBox8.Text = "100";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(9, 30);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(44, 17);
            this.label10.TabIndex = 2;
            this.label10.Text = "地址：";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.textBox16);
            this.groupBox1.Controls.Add(this.textBox5);
            this.groupBox1.Controls.Add(this.button_read_string);
            this.groupBox1.Controls.Add(this.button_read_double);
            this.groupBox1.Controls.Add(this.button_read_float);
            this.groupBox1.Controls.Add(this.button_read_ulong);
            this.groupBox1.Controls.Add(this.button_read_long);
            this.groupBox1.Controls.Add(this.button_read_uint);
            this.groupBox1.Controls.Add(this.button_read_int);
            this.groupBox1.Controls.Add(this.button_read_ushort);
            this.groupBox1.Controls.Add(this.button_read_short);
            this.groupBox1.Controls.Add(this.button_read_bool);
            this.groupBox1.Controls.Add(this.textBox4);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.textBox3);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Location = new System.Drawing.Point(11, 3);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(518, 234);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "单数据读取测试";
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(358, 195);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(41, 23);
            this.textBox5.TabIndex = 17;
            this.textBox5.Text = "10";
            // 
            // button_read_string
            // 
            this.button_read_string.Location = new System.Drawing.Point(415, 192);
            this.button_read_string.Name = "button_read_string";
            this.button_read_string.Size = new System.Drawing.Size(82, 28);
            this.button_read_string.TabIndex = 16;
            this.button_read_string.Text = "字符串读取";
            this.button_read_string.UseVisualStyleBackColor = true;
            this.button_read_string.Click += new System.EventHandler(this.button_read_string_Click);
            // 
            // button_read_double
            // 
            this.button_read_double.Location = new System.Drawing.Point(415, 158);
            this.button_read_double.Name = "button_read_double";
            this.button_read_double.Size = new System.Drawing.Size(82, 28);
            this.button_read_double.TabIndex = 15;
            this.button_read_double.Text = "double读取";
            this.button_read_double.UseVisualStyleBackColor = true;
            this.button_read_double.Click += new System.EventHandler(this.button_read_double_Click);
            // 
            // button_read_float
            // 
            this.button_read_float.Location = new System.Drawing.Point(315, 158);
            this.button_read_float.Name = "button_read_float";
            this.button_read_float.Size = new System.Drawing.Size(82, 28);
            this.button_read_float.TabIndex = 14;
            this.button_read_float.Text = "float读取";
            this.button_read_float.UseVisualStyleBackColor = true;
            this.button_read_float.Click += new System.EventHandler(this.button_read_float_Click);
            // 
            // button_read_ulong
            // 
            this.button_read_ulong.Location = new System.Drawing.Point(415, 124);
            this.button_read_ulong.Name = "button_read_ulong";
            this.button_read_ulong.Size = new System.Drawing.Size(82, 28);
            this.button_read_ulong.TabIndex = 13;
            this.button_read_ulong.Text = "ulong读取";
            this.button_read_ulong.UseVisualStyleBackColor = true;
            this.button_read_ulong.Click += new System.EventHandler(this.button_read_ulong_Click);
            // 
            // button_read_long
            // 
            this.button_read_long.Location = new System.Drawing.Point(315, 124);
            this.button_read_long.Name = "button_read_long";
            this.button_read_long.Size = new System.Drawing.Size(82, 28);
            this.button_read_long.TabIndex = 12;
            this.button_read_long.Text = "long读取";
            this.button_read_long.UseVisualStyleBackColor = true;
            this.button_read_long.Click += new System.EventHandler(this.button_read_long_Click);
            // 
            // button_read_uint
            // 
            this.button_read_uint.Location = new System.Drawing.Point(415, 90);
            this.button_read_uint.Name = "button_read_uint";
            this.button_read_uint.Size = new System.Drawing.Size(82, 28);
            this.button_read_uint.TabIndex = 11;
            this.button_read_uint.Text = "uint读取";
            this.button_read_uint.UseVisualStyleBackColor = true;
            this.button_read_uint.Click += new System.EventHandler(this.button_read_uint_Click);
            // 
            // button_read_int
            // 
            this.button_read_int.Location = new System.Drawing.Point(315, 90);
            this.button_read_int.Name = "button_read_int";
            this.button_read_int.Size = new System.Drawing.Size(82, 28);
            this.button_read_int.TabIndex = 10;
            this.button_read_int.Text = "int读取";
            this.button_read_int.UseVisualStyleBackColor = true;
            this.button_read_int.Click += new System.EventHandler(this.button_read_int_Click);
            // 
            // button_read_ushort
            // 
            this.button_read_ushort.Location = new System.Drawing.Point(415, 56);
            this.button_read_ushort.Name = "button_read_ushort";
            this.button_read_ushort.Size = new System.Drawing.Size(82, 28);
            this.button_read_ushort.TabIndex = 9;
            this.button_read_ushort.Text = "ushort读取";
            this.button_read_ushort.UseVisualStyleBackColor = true;
            this.button_read_ushort.Click += new System.EventHandler(this.button_read_ushort_Click);
            // 
            // button_read_short
            // 
            this.button_read_short.Location = new System.Drawing.Point(315, 56);
            this.button_read_short.Name = "button_read_short";
            this.button_read_short.Size = new System.Drawing.Size(82, 28);
            this.button_read_short.TabIndex = 8;
            this.button_read_short.Text = "short读取";
            this.button_read_short.UseVisualStyleBackColor = true;
            this.button_read_short.Click += new System.EventHandler(this.button_read_short_Click);
            // 
            // button_read_bool
            // 
            this.button_read_bool.Location = new System.Drawing.Point(315, 19);
            this.button_read_bool.Name = "button_read_bool";
            this.button_read_bool.Size = new System.Drawing.Size(82, 28);
            this.button_read_bool.TabIndex = 6;
            this.button_read_bool.Text = "线圈读取";
            this.button_read_bool.UseVisualStyleBackColor = true;
            this.button_read_bool.Click += new System.EventHandler(this.button_read_bool_Click);
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(63, 56);
            this.textBox4.Multiline = true;
            this.textBox4.Name = "textBox4";
            this.textBox4.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.textBox4.Size = new System.Drawing.Size(233, 164);
            this.textBox4.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(9, 58);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 17);
            this.label7.TabIndex = 4;
            this.label7.Text = "结果：";
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(63, 27);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(178, 23);
            this.textBox3.TabIndex = 3;
            this.textBox3.Text = "100";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(9, 30);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(44, 17);
            this.label6.TabIndex = 2;
            this.label6.Text = "地址：";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(315, 198);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 17);
            this.label8.TabIndex = 18;
            this.label8.Text = "长度：";
            // 
            // userControlHead1
            // 
            this.userControlHead1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.userControlHead1.Dock = System.Windows.Forms.DockStyle.Top;
            this.userControlHead1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userControlHead1.HelpLink = "http://www.cnblogs.com/dathlin/p/7885368.html";
            this.userControlHead1.Location = new System.Drawing.Point(0, 0);
            this.userControlHead1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userControlHead1.MinimumSize = new System.Drawing.Size(800, 32);
            this.userControlHead1.Name = "userControlHead1";
            this.userControlHead1.ProtocolInfo = "Modbus Tcp - dtu";
            this.userControlHead1.Size = new System.Drawing.Size(1004, 32);
            this.userControlHead1.TabIndex = 2;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(247, 27);
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(49, 23);
            this.textBox16.TabIndex = 21;
            this.textBox16.Text = "1";
            // 
            // FormModbusAlien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1004, 645);
            this.Controls.Add(this.userControlHead1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormModbusAlien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Modbus Tcp 异形客户端测试";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormSiemens_FormClosing);
            this.Load += new System.EventHandler(this.FormSiemens_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.TextBox textBox12;
        private System.Windows.Forms.Label label15;
        private HslCommunication.Controls.UserCurve userCurve1;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.TextBox textBox11;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TextBox textBox10;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.TextBox textBox9;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.Button button_read_string;
        private System.Windows.Forms.Button button_read_double;
        private System.Windows.Forms.Button button_read_float;
        private System.Windows.Forms.Button button_read_ulong;
        private System.Windows.Forms.Button button_read_long;
        private System.Windows.Forms.Button button_read_uint;
        private System.Windows.Forms.Button button_read_int;
        private System.Windows.Forms.Button button_read_ushort;
        private System.Windows.Forms.Button button_read_short;
        private System.Windows.Forms.Button button_read_bool;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.CheckBox checkBox1;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private DemoControl.UserControlHead userControlHead1;
        private System.Windows.Forms.TextBox textBox16;
    }
}