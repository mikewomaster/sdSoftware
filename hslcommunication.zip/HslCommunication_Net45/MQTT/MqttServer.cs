﻿using HslCommunication.BasicFramework;
using HslCommunication.Core.Net;
using HslCommunication.Reflection;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.MQTT
{
	/// <summary>
	/// 一个Mqtt的服务器类对象，本服务器支持发布订阅操作，支持服务器从强制推送数据，指定客户端推送，支持同步网络访问的操作。从而定制化出自己的服务器，详细的使用说明可以参见代码api文档示例<br />
	/// An Mqtt server class object, this server supports publish and subscribe operations, supports the server to push data from the forced, specified client push, 
	/// and supports the operation of synchronous network access. In order to customize your own server, detailed instructions can be found in the code api documentation example
	/// </summary>
	/// <remarks>
	/// 本MQTT服务器功能丰富，可以同时实现，用户名密码验证，在线客户端的管理，数据订阅推送，单纯的数据收发，心跳检测，同步数据访问，详细参照下面的示例说明
	/// </remarks>
	/// <example>
	/// 最简单的使用，就是实例化，启动服务即可
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample1" title="简单的实例化" />
	/// 当然了，我们可以稍微的复杂一点，加一个功能，验证连接的客户端操作
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample2" title="增加验证" />
	/// 我们可以对ClientID，用户名，密码进行验证，那么我们可以动态修改client id么？比如用户名密码验证成功后，client ID我想设置为权限等级。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample2_1" title="动态修改Client ID" />
	/// 如果我想强制该客户端不能主动发布主题，可以这么操作。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample2_2" title="禁止发布主题" />
	/// 你也可以对clientid进行过滤验证，只要结果返回不是0，就可以了。接下来我们实现一个功能，所有客户端的发布的消息在控制台打印出来,
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample3" title="打印所有发布" />
	/// 捕获客户端刚刚上线的时候，方便我们进行一些额外的操作信息。下面的意思就是返回一个数据，将数据发送到指定的会话内容上去
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample4" title="客户端上线信息" />
	/// 下面演示如何从服务器端发布数据信息，包括多种发布的方法，消息是否驻留，详细看说明即可
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample5" title="服务器发布" />
	/// 下面演示如何支持同步网络访问，当客户端是同步网络访问时，协议内容会变成HUSL，即被视为同步客户端，进行相关的操作，主要进行远程调用RPC，以及查询MQTT的主题列表。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample6" title="同步访问支持" />
	/// 如果需要查看在线信息，可以随时获取<see cref="OnlineCount"/>属性，如果需要查看报文信息，可以实例化日志，参考日志的说明即可。<br /><br />
	/// 针对上面同步网络访问，虽然比较灵活，但是什么都要自己控制，无疑增加了代码的复杂度，举个例子，当你的topic分类很多的时候，已经客户端协议多个参数的时候，需要大量的手动解析的代码，
	/// 影响代码美观，而且让代码更加的杂乱，除此之外，还有个巨大的麻烦，服务器提供了很多的topic处理程序（可以换个称呼，暴露的API接口），
	/// 客户端没法清晰的浏览到，需要查找服务器代码才能知晓，而且服务器更新了接口，客户端有需要同步查看服务器的代码才行，以及做权限控制也很麻烦。<br />
	/// 所以在Hsl里面的MQTT服务器，提供了注册API接口的功能，只需要一行注册代码，你的类的方法自动就会变为API解析，所有的参数都是同步解析的，如果你返回的是
	/// OperateResult&lt;T&gt;类型对象，还支持是否成功的结果报告，否则一律视为json字符串，返回给调用方。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttServerSample.cs" region="Sample7" title="基于MQTT的RPC接口实现" />
	/// 如果需要查看在线信息，可以随时获取<see cref="OnlineCount"/>属性，如果需要查看报文信息，可以实例化日志，参考日志的说明即可。
	/// </example>
	public class MqttServer : NetworkServerBase
	{
		#region Constructor

		/// <summary>
		/// 实例化一个MQTT协议的服务器<br />
		/// Instantiate a MQTT protocol server
		/// </summary>
		public MqttServer( )
		{
			retainKeys = new Dictionary<string, MqttClientApplicationMessage>( );
			apiTopicServiceDict = new Dictionary<string, MqttRpcApiInfo>( );
			keysLock = new object( );
			rpcApiLock = new object( );
			timerHeart = new System.Threading.Timer( ThreadTimerHeartCheck, null, 2000, 10000 );
		}

		#endregion

		#region NetServer Override
#if NET35 || NET20
		/// <inheritdoc/>
		protected override void ThreadPoolLogin( Socket socket, IPEndPoint endPoint )
		{
			OperateResult<byte, byte[]> readMqtt = ReceiveMqttMessage( socket, 10_000 );
			if (!readMqtt.IsSuccess) return;

			OperateResult<int, MqttSession> check = CheckMqttConnection( readMqtt.Content1, readMqtt.Content2, socket, endPoint );
			if (!check.IsSuccess)
			{
				LogNet?.WriteInfo( ToString( ), check.Message );
				socket?.Close( );
				return;
			}

			if(check.Content1 != 0)
			{
				Send( socket, MqttHelper.BuildMqttCommand( MqttControlMessage.CONNACK, 0x00, null, new byte[] { 0x00, (byte)check.Content1 }  ).Content );
				socket?.Close( );
				return;
			}
			else
			{
				Send( socket, MqttHelper.BuildMqttCommand( MqttControlMessage.CONNACK, 0x00, null, new byte[] { 0x00, 0x00 } ).Content );
			}

			try
			{
				socket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketReceiveCallback ), check.Content2 );
				AddMqttSession( check.Content2 );
			}
			catch (Exception ex)
			{
				LogNet?.WriteDebug( ToString( ), $"Client Online Exception : " + ex.Message );
				return;
			}
			
			if (check.Content2.Protocol == "MQTT") OnClientConnected?.Invoke( check.Content2 );
		}

		private void SocketReceiveCallback( IAsyncResult ar )
		{
			if (ar.AsyncState is MqttSession mqttSession)
			{
				try
				{
					mqttSession.MqttSocket.EndReceive( ar );
				}
				catch(Exception ex)
				{
					LogNet?.WriteDebug( ToString( ), "ReceiveCallback Failed:" + ex.Message );
					RemoveAndCloseSession( mqttSession ); 
					return;
				}

				OperateResult<byte, byte[]> readMqtt = null;
				if (mqttSession.Protocol == "MQTT")
					readMqtt = ReceiveMqttMessage( mqttSession.MqttSocket, 30_000 );
				else
					readMqtt = ReceiveMqttMessage( mqttSession.MqttSocket, 30_000, new Action<long, long>( ( already, total ) =>
					{
						string topic = total > 0 ? (already * 100 / total).ToString( ) : "100";
						byte[] payload = new byte[16];
						BitConverter.GetBytes( already ).CopyTo( payload, 0 );
						BitConverter.GetBytes( total ).CopyTo( payload, 8 );

						Send( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.REPORTPROGRESS, 0x00, MqttHelper.BuildSegCommandByString( topic ), payload ).Content );
					} ) );

				if (!readMqtt.IsSuccess)
				{
					RemoveAndCloseSession( mqttSession );
					return;
				}

				byte code = readMqtt.Content1;
				byte[] data = readMqtt.Content2;

				try
				{
					if (code >> 4 != MqttControlMessage.DISCONNECT)
						mqttSession.MqttSocket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketReceiveCallback ), mqttSession );
					else
					{
						RemoveAndCloseSession( mqttSession ); return;
					}
				}
				catch
				{
					RemoveAndCloseSession( mqttSession ); return;
				}

				// 处理数据
				if (code >> 4 == MqttControlMessage.PUBLISH)
				{
					// 发布消息
					mqttSession.ActiveTime = DateTime.Now;
					DealWithPublish( mqttSession, code, data );
				}
				else if (code >> 4 == MqttControlMessage.PUBACK)
				{
					if (mqttSession.Protocol != "MQTT")
					{
						// 当为RPC同步网络访问的时候，就是请求当前驻留的消息列表
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if (code >> 4 == MqttControlMessage.PUBREC)
				{
					if (mqttSession.Protocol != "MQTT")
					{
						// 当为RPC同步网络访问的时候，就是请求当前驻留的消息内容
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if(code >> 4 == MqttControlMessage.PUBREL)
				{
					// 回发消息完成
					Send( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PUBCOMP, 0x00, null, data ).Content );
				}
				else if (code >> 4 == MqttControlMessage.SUBSCRIBE)
				{
					if (mqttSession.Protocol == "MQTT")
					{
						// 订阅消息
						mqttSession.ActiveTime = DateTime.Now;
						DealWithSubscribe( mqttSession, code, data );
					}
					else
					{
						// 当为RPC同步网络访问的时候，就是请求API接口列表内容
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if (code >> 4 == MqttControlMessage.UNSUBSCRIBE)
				{
					// 取消订阅消息
					mqttSession.ActiveTime = DateTime.Now;
					DealWithUnSubscribe( mqttSession, code, data );
				}
				else if(code >> 4 == MqttControlMessage.PINGREQ)
				{
					// 心跳请求
					mqttSession.ActiveTime = DateTime.Now;
					Send( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PINGRESP, 0x00, null, null ).Content );
				}
			}
		}
#else
		/// <inheritdoc/>
		protected async override void ThreadPoolLogin( Socket socket, IPEndPoint endPoint )
		{
			OperateResult<byte, byte[]> readMqtt = await ReceiveMqttMessageAsync( socket, 10_000 );
			if (!readMqtt.IsSuccess) return;

			OperateResult<int, MqttSession> check = CheckMqttConnection( readMqtt.Content1, readMqtt.Content2, socket, endPoint );
			if (!check.IsSuccess)
			{
				LogNet?.WriteInfo( ToString( ), check.Message );
				socket?.Close( );
				return;
			}

			if (check.Content1 != 0)
			{
				await SendAsync( socket, MqttHelper.BuildMqttCommand( MqttControlMessage.CONNACK, 0x00, null, new byte[] { 0x00, (byte)check.Content1 } ).Content );
				socket?.Close( );
				return;
			}
			else
			{
				await SendAsync( socket, MqttHelper.BuildMqttCommand( MqttControlMessage.CONNACK, 0x00, null, new byte[] { 0x00, 0x00 } ).Content );
			}

			try
			{
				socket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketReceiveCallback ), check.Content2 );
				AddMqttSession( check.Content2 );
			}
			catch (Exception ex)
			{
				LogNet?.WriteDebug( ToString( ), $"Client Online Exception : " + ex.Message );
				return;
			}

			if (check.Content2.Protocol == "MQTT") OnClientConnected?.Invoke( check.Content2 );
		}

		private async void SocketReceiveCallback( IAsyncResult ar )
		{
			if (ar.AsyncState is MqttSession mqttSession)
			{
				try
				{
					mqttSession.MqttSocket.EndReceive( ar );
				}
				catch (Exception ex)
				{
					LogNet?.WriteDebug( ToString( ), "ReceiveCallback Failed:" + ex.Message );
					RemoveAndCloseSession( mqttSession );
					return;
				}

				OperateResult<byte, byte[]> readMqtt = null;
				if (mqttSession.Protocol == "MQTT")
					readMqtt = await ReceiveMqttMessageAsync( mqttSession.MqttSocket, 60_000 );
				else
					readMqtt = await ReceiveMqttMessageAsync( mqttSession.MqttSocket, 60_000, new Action<long, long>( ( already, total ) =>
					{
						string topic = total > 0 ? (already * 100 / total).ToString( ) : "100";
						byte[] payload = new byte[16];
						BitConverter.GetBytes( already ).CopyTo( payload, 0 );
						BitConverter.GetBytes( total ).  CopyTo( payload, 8 );

						Send( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.REPORTPROGRESS, 0x00, MqttHelper.BuildSegCommandByString( topic ), payload ).Content );
					} ) );

				if (!readMqtt.IsSuccess)
				{
					RemoveAndCloseSession( mqttSession );
					return;
				}

				byte code = readMqtt.Content1;
				byte[] data = readMqtt.Content2;

				try
				{
					if (code >> 4 != MqttControlMessage.DISCONNECT)
						mqttSession.MqttSocket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketReceiveCallback ), mqttSession );
					else
					{
						RemoveAndCloseSession( mqttSession ); return;
					}
				}
				catch
				{
					RemoveAndCloseSession( mqttSession ); return;
				}

				// 处理数据
				if (code >> 4 == MqttControlMessage.PUBLISH)
				{
					// 发布消息
					mqttSession.ActiveTime = DateTime.Now;
					DealWithPublish( mqttSession, code, data );
				}
				else if(code >> 4 == MqttControlMessage.PUBACK)
				{
					if (mqttSession.Protocol != "MQTT")
					{
						// 当为RPC同步网络访问的时候，就是请求当前驻留的消息列表
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if (code >> 4 == MqttControlMessage.PUBREC)
				{
					if (mqttSession.Protocol != "MQTT")
					{
						// 当为RPC同步网络访问的时候，就是请求当前驻留的消息内容
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if (code >> 4 == MqttControlMessage.PUBREL)
				{
					// 回发消息完成
					await SendAsync( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PUBCOMP, 0x00, null, data ).Content );
				}
				else if (code >> 4 == MqttControlMessage.SUBSCRIBE)
				{
					if (mqttSession.Protocol == "MQTT")
					{
						// 订阅消息
						mqttSession.ActiveTime = DateTime.Now;
						DealWithSubscribe( mqttSession, code, data );
					}
					else
					{
						// 当为RPC同步网络访问的时候，就是请求API接口列表内容
						DealWithPublish( mqttSession, code, data );
					}
				}
				else if (code >> 4 == MqttControlMessage.UNSUBSCRIBE)
				{
					// 取消订阅消息
					mqttSession.ActiveTime = DateTime.Now;
					DealWithUnSubscribe( mqttSession, code, data );
				}
				else if (code >> 4 == MqttControlMessage.PINGREQ)
				{
					// 心跳请求
					mqttSession.ActiveTime = DateTime.Now;
					await SendAsync( mqttSession.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PINGRESP, 0x00, null, null ).Content );
				}
			}
		}
#endif
		private OperateResult<int, MqttSession> CheckMqttConnection(byte mqttCode, byte[] content, Socket socket, IPEndPoint endPoint )
		{
			if (mqttCode >> 4 != MqttControlMessage.CONNECT) return new OperateResult<int, MqttSession>( "Client Send Faied, And Close!" );
			if (content.Length < 10) return new OperateResult<int, MqttSession>( $"Receive Data Too Short:{SoftBasic.ByteToHexString( content, ' ' )}" );

			string protocol = Encoding.ASCII.GetString( content, 2, 4 );
			if (protocol != "MQTT" && protocol != "HUSL") return new OperateResult<int, MqttSession>( $"Not Mqtt Client Connection" );

			try
			{
				int index = 10;
				string clientId     = MqttHelper.ExtraMsgFromBytes( content, ref index );
				string willTopic    = ((content[7] & 0x04) == 0x04) ? MqttHelper.ExtraMsgFromBytes( content, ref index ) : string.Empty;
				string willMessage  = ((content[7] & 0x04) == 0x04) ? MqttHelper.ExtraMsgFromBytes( content, ref index ) : string.Empty;
				string userName     = ((content[7] & 0x80) == 0x80) ? MqttHelper.ExtraMsgFromBytes( content, ref index ) : string.Empty;
				string password     = ((content[7] & 0x40) == 0x40) ? MqttHelper.ExtraMsgFromBytes( content, ref index ) : string.Empty;
				int keepAlive       = content[8] * 256 + content[9];

				MqttSession mqttSession = new MqttSession( endPoint, protocol )
				{
					MqttSocket = socket,
					ClientId = clientId,
					UserName = userName,
				};
				int returnCode = ClientVerification != null ? ClientVerification( mqttSession, clientId, userName, password ) : 0;

				if (keepAlive > 0) mqttSession.ActiveTimeSpan = TimeSpan.FromSeconds( keepAlive );
				return OperateResult.CreateSuccessResult( returnCode, mqttSession );
			}
			catch (Exception ex)
			{
				return new OperateResult<int, MqttSession>( $"Client Online Exception : " + ex.Message );
			}
		}


		/// <inheritdoc/>
		protected override void StartInitialization( )
		{

		}

		/// <inheritdoc/>
		protected override void CloseAction( )
		{
			base.CloseAction( );

			lock (sessionsLock)
			{
				for (int i = 0; i < mqttSessions.Count; i++)
				{
					mqttSessions[i].MqttSocket?.Close( );
				}
				mqttSessions.Clear( );
			}
		}

		private void ThreadTimerHeartCheck( object obj )
		{
			MqttSession[] snapshoot = null;
			lock (sessionsLock)
				snapshoot = mqttSessions.ToArray( );
			if (snapshoot != null && snapshoot.Length > 0)
			{
				for (int i = 0; i < snapshoot.Length; i++)
				{
					if (snapshoot[i].Protocol == "MQTT" && ( DateTime.Now - snapshoot[i].ActiveTime) > snapshoot[i].ActiveTimeSpan)
					{
						// 心跳超时
						RemoveAndCloseSession( snapshoot[i] );
					}
				}
			}
		}

		private void DealWithPublish( MqttSession session, byte code, byte[] data )
		{
			bool dup = (code & 0x08) == 0x08;
			int qos = ((code & 0x04) == 0x04 ? 2 : 0) + ((code & 0x02) == 0x02 ? 1 : 0);
			MqttQualityOfServiceLevel mqttQuality = MqttQualityOfServiceLevel.AtMostOnce;
			if (qos == 1) mqttQuality = MqttQualityOfServiceLevel.AtLeastOnce;
			else if (qos == 2) mqttQuality = MqttQualityOfServiceLevel.ExactlyOnce;
			else if (qos == 3) mqttQuality = MqttQualityOfServiceLevel.OnlyTransfer;

			bool retain = (code & 0x01) == 0x01;
			int msgId = 0;
			int index = 0;
			string topic = MqttHelper.ExtraMsgFromBytes( data, ref index );
			if (qos > 0) msgId = MqttHelper.ExtraIntFromBytes( data, ref index );
			byte[] payload = SoftBasic.ArrayRemoveBegin( data, index );

			if (mqttQuality == MqttQualityOfServiceLevel.AtLeastOnce)
				Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PUBACK, 0x00, null, MqttHelper.BuildIntBytes( msgId ) ).Content );
			else if (mqttQuality == MqttQualityOfServiceLevel.ExactlyOnce)
				Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.PUBREC, 0x00, null, MqttHelper.BuildIntBytes( msgId ) ).Content );

			MqttClientApplicationMessage mqttClientApplicationMessage = new MqttClientApplicationMessage( )
			{
				ClientId = session.ClientId,
				QualityOfServiceLevel = mqttQuality,
				Retain = retain,
				Topic = topic,
				UserName = session.UserName,
				Payload = payload,
			};

			if (session.Protocol == "MQTT")
			{
				if (session.ForbidPublishTopic) return;
				OnClientApplicationMessageReceive?.Invoke( session, mqttClientApplicationMessage );

				if (mqttQuality != MqttQualityOfServiceLevel.OnlyTransfer && !mqttClientApplicationMessage.IsCancelPublish)
				{
					PublishTopicPayload( topic, payload, false );
					if (retain) RetainTopicPayload( topic, mqttClientApplicationMessage );
				}
			}
			else
			{
				if (code >> 4 == MqttControlMessage.PUBLISH)
				{
					// 先检查有没有注册的服务
					MqttRpcApiInfo apiInformation = GetMqttRpcApiInfo( mqttClientApplicationMessage.Topic );
					if (apiInformation == null)
					{
						OnClientApplicationMessageReceive?.Invoke( session, mqttClientApplicationMessage );
					}
					else
					{
						// 存在相关的服务，优先调度服务
						DateTime dateTime = DateTime.Now;
						OperateResult<string> result = MqttHelper.HandleObjectMethod( session, mqttClientApplicationMessage, apiInformation );
						apiInformation.CalledCount++;
						double timeSpend = Math.Round((DateTime.Now - dateTime).TotalSeconds, 5);
						apiInformation.SpendTotalTime += timeSpend;

						LogNet?.WriteDebug( ToString( ), $"MqttRpc request:[{mqttClientApplicationMessage.Topic}] spend:[{timeSpend * 1000:F2} ms] return:[{result.IsSuccess}]" );
						ReportOperateResult( session, result );
					}
				}
				else if (code >> 4 == MqttControlMessage.SUBSCRIBE)
				{
					// 当为RPC同步网络访问的时候，就是请求API接口列表内容
					ReportOperateResult( session, OperateResult.CreateSuccessResult( JArray.FromObject( GetAllMqttRpcApiInfo( ) ).ToString( ) ) );
				}
				else if (code >> 4 == MqttControlMessage.PUBACK)
				{
					// 当为RPC同步网络访问的时候，就是获取服务器的发布过的Topic列表
					PublishTopicPayload( session, "", HslProtocol.PackStringArrayToByte( GetAllRetainTopics( ) ) );
				}
				else if (code >> 4 == MqttControlMessage.PUBREC)
				{
					// 当为RPC同步网络访问的时候，读取指定的Topic信息
					lock (keysLock)
					{
						if(retainKeys.ContainsKey( mqttClientApplicationMessage.Topic ))
						{
							PublishTopicPayload( session, mqttClientApplicationMessage.Topic, Encoding.UTF8.GetBytes( retainKeys[mqttClientApplicationMessage.Topic].ToJsonString( ) ) );
						}
						else
						{
							ReportOperateResult( session, StringResources.Language.KeyIsNotExist );
						}
					}
				}
			}
		}

		/// <summary>
		/// 将消息进行驻留到内存词典，方便进行其他的功能操作。
		/// </summary>
		/// <param name="topic">消息的主题</param>
		/// <param name="payload">当前的数据负载</param>
		private void RetainTopicPayload( string topic, byte[] payload )
		{
			MqttClientApplicationMessage mqttClientApplicationMessage = new MqttClientApplicationMessage( )
			{
				ClientId = "MqttServer",
				QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,
				Retain = true,
				Topic = topic,
				UserName = "MqttServer",
				Payload = payload,
			};

			lock (keysLock)
			{
				if (retainKeys.ContainsKey( topic ))
				{
					retainKeys[topic] = mqttClientApplicationMessage;
				}
				else
				{
					retainKeys.Add( topic, mqttClientApplicationMessage );
				}
			}
		}

		/// <summary>
		/// 将消息进行驻留到内存词典，方便进行其他的功能操作。
		/// </summary>
		/// <param name="topic">消息的主题</param>
		/// <param name="message">当前的Mqtt消息</param>
		private void RetainTopicPayload( string topic, MqttClientApplicationMessage message )
		{
			lock (keysLock)
			{
				if (retainKeys.ContainsKey( topic ))
				{
					retainKeys[topic] = message;
				}
				else
				{
					retainKeys.Add( topic, message );
				}
			}
		}

		private void DealWithSubscribe( MqttSession session, byte code, byte[] data )
		{
			int msgId = 0;
			int index = 0;

			msgId = MqttHelper.ExtraIntFromBytes( data, ref index );
			List<string> topics = new List<string>( );
			while (index < data.Length - 1)
			{
				topics.Add( MqttHelper.ExtraSubscribeMsgFromBytes( data, ref index ) );
			}

			// 返回订阅成功
			if (index < data.Length)
			{
				Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.SUBACK, 0x00, MqttHelper.BuildIntBytes( msgId ), new byte[] { data[index] } ).Content );
			}
			else
			{
				Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.SUBACK, 0x00, null, MqttHelper.BuildIntBytes( msgId ) ).Content );
			}
			lock (keysLock)
			{
				for (int i = 0; i < topics.Count; i++)
					if (retainKeys.ContainsKey( topics[i] ))
						Send( session.MqttSocket, MqttHelper.BuildPublishMqttCommand( topics[i], retainKeys[topics[i]].Payload ).Content );
			}
			// 添加订阅信息
			session.AddSubscribe( topics.ToArray( ) );
		}

		private void DealWithUnSubscribe( MqttSession session, byte code, byte[] data )
		{
			int msgId = 0;
			int index = 0;

			msgId = MqttHelper.ExtraIntFromBytes( data, ref index );
			List<string> topics = new List<string>( );
			while (index < data.Length)
			{
				topics.Add( MqttHelper.ExtraMsgFromBytes( data, ref index ) );
				index += 1;
			}

			// 返回取消订阅成功
			Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.UNSUBACK, 0x00, null, MqttHelper.BuildIntBytes( msgId ) ).Content );

			// 添加订阅信息
			session.RemoveSubscribe( topics.ToArray( ) );
		}

		#endregion

		#region Publish Message

		/// <summary>
		/// 向指定的客户端发送主题及负载数据<br />
		/// Sends the topic and payload data to the specified client
		/// </summary>
		/// <param name="session">会话内容</param>
		/// <param name="topic">主题</param>
		/// <param name="payload">消息内容</param>
		public void PublishTopicPayload( MqttSession session, string topic, byte[] payload )
		{
			OperateResult send = Send( session.MqttSocket, MqttHelper.BuildPublishMqttCommand( topic, payload ).Content );
			if (!send.IsSuccess)
				LogNet?.WriteError( ToString( ), $"Send Topic Failed,Client Id:{session.ClientId}" );
		}

		/// <summary>
		/// 从服务器向订阅了指定的主题的客户端发送消息，默认消息不驻留<br />
		/// Sends a message from the server to a client that subscribes to the specified topic; the default message does not retain
		/// </summary>
		/// <param name="topic">主题</param>
		/// <param name="payload">消息内容</param>
		/// <param name="retain">指示消息是否驻留</param>
		public void PublishTopicPayload( string topic, byte[] payload, bool retain = true )
		{
			lock (sessionsLock)
			{
				for (int i = 0; i < mqttSessions.Count; i++)
				{
					// 向订阅消息的客户端进行发送数据
					if (mqttSessions[i].IsClientSubscribe( topic ) && mqttSessions[i].Protocol == "MQTT")
					{
						OperateResult send = Send( mqttSessions[i].MqttSocket, MqttHelper.BuildPublishMqttCommand( topic, payload ).Content );
						if (!send.IsSuccess)
							LogNet?.WriteError( ToString( ), $"Send Topic Failed,Client Id:{mqttSessions[i].ClientId}" );
					}
				}
			}
			if (retain) RetainTopicPayload( topic, payload );
		}

		/// <summary>
		/// 向所有的客户端强制发送主题及负载数据，默认消息不驻留<br />
		/// Send subject and payload data to all clients compulsively, and the default message does not retain
		/// </summary>
		/// <param name="topic">主题</param>
		/// <param name="payload">消息内容</param>
		/// <param name="retain">指示消息是否驻留</param>
		public void PublishAllClientTopicPayload( string topic, byte[] payload, bool retain = false )
		{
			lock (sessionsLock)
			{
				for (int i = 0; i < mqttSessions.Count; i++)
				{
					if (mqttSessions[i].Protocol == "MQTT")
					{
						OperateResult send = Send( mqttSessions[i].MqttSocket, MqttHelper.BuildPublishMqttCommand( topic, payload ).Content );
						if (!send.IsSuccess)
							LogNet?.WriteError( ToString( ), $"Send Topic Failed,Client Id:{mqttSessions[i].ClientId}" );
					}
				}
			}
			if (retain) RetainTopicPayload( topic, payload );
		}

		/// <summary>
		/// 向指定的客户端ID强制发送消息，默认消息不驻留<br />
		/// Forces a message to the specified client ID, and the default message does not retain
		/// </summary>
		/// <param name="clientId">指定的客户端ID信息</param>
		/// <param name="topic">主题</param>
		/// <param name="payload">消息内容</param>
		/// <param name="retain">指示消息是否驻留</param>
		public void PublishTopicPayload( string clientId, string topic, byte[] payload, bool retain = false )
		{
			lock (sessionsLock)
			{
				for (int i = 0; i < mqttSessions.Count; i++)
				{
					if (mqttSessions[i].ClientId == clientId && mqttSessions[i].Protocol == "MQTT")
					{
						OperateResult send = Send( mqttSessions[i].MqttSocket, MqttHelper.BuildPublishMqttCommand( topic, payload ).Content );
						if (!send.IsSuccess)
							LogNet?.WriteError( ToString( ), $"Send Topic Failed,Client Id:{mqttSessions[i].ClientId}" );
					}
				}
			}
			if (retain) RetainTopicPayload( topic, payload );
		}

		#endregion

		#region Report Progress

		/// <summary>
		/// 向客户端发布一个进度报告的信息，仅用于同步网络的时候才支持进度报告，将进度及消息发送给客户端，比如你的服务器需要分成5个部分完成，可以按照百分比提示给客户端当前服务器发生了什么<br />
		/// Publish the information of a progress report to the client. The progress report is only supported when the network is synchronized. 
		/// The progress and the message are sent to the client. For example, your server needs to be divided into 5 parts to complete. 
		/// You can prompt the client according to the percentage. What happened to the server
		/// </summary>
		/// <param name="session">当前的网络会话</param>
		/// <param name="topic">回发客户端的关键数据，可以是百分比字符串，甚至是自定义的任意功能</param>
		/// <param name="payload">数据消息</param>
		public void ReportProgress( MqttSession session, string topic, string payload )
		{
			if (session.Protocol == "HUSL")
			{
				payload = payload ?? string.Empty;
				OperateResult send = Send( session.MqttSocket, MqttHelper.BuildMqttCommand( MqttControlMessage.REPORTPROGRESS, 0x00, MqttHelper.BuildSegCommandByString( topic ), Encoding.UTF8.GetBytes( payload ) ).Content );
				if (!send.IsSuccess)
					LogNet?.WriteError( ToString( ), $"Send Progress Topic Failed,Client Id:{session.ClientId}" );
			}
			else
			{
				throw new Exception( "ReportProgress only support sync communication" );
			}
		}

		/// <summary>
		/// 向客户端发布一个失败的操作信息，仅用于同步网络的时候反馈失败结果，将错误的信息反馈回客户端，客户端就知道服务器发生了什么，为什么反馈失败。<br />
		/// Publish a failed operation information to the client, which is only used to feed back the failure result when synchronizing the network. 
		/// If the error information is fed back to the client, the client will know what happened to the server and why the feedback failed.
		/// </summary>
		/// <param name="session">当前的网络会话</param>
		/// <param name="message">错误的消息文本信息</param>
		public void ReportOperateResult( MqttSession session, string message )
		{
			ReportOperateResult( session, new OperateResult<string>( message ) );
		}

		/// <summary>
		/// 向客户端发布一个操作结果的信息，仅用于同步网络的时候反馈操作结果，该操作可能成功，可能失败，客户端就知道服务器发生了什么，以及结果如何。<br />
		/// Publish an operation result information to the client, which is only used to feed back the operation result when synchronizing the network. 
		/// The operation may succeed or fail, and the client knows what happened to the server and the result.
		/// </summary>
		/// <param name="session">当前的网络会话</param>
		/// <param name="result">结果对象内容</param>
		public void ReportOperateResult( MqttSession session, OperateResult<string> result )
		{
			if (session.Protocol == "HUSL")
			{
				if (result.IsSuccess)
				{
					PublishTopicPayload( session, result.ErrorCode.ToString( ), string.IsNullOrEmpty( result.Content ) ? new byte[0] : Encoding.UTF8.GetBytes( result.Content ) );
				}
				else
				{
					OperateResult send = Send( session.MqttSocket, MqttHelper.BuildMqttCommand(
						MqttControlMessage.FAILED, 0x00, MqttHelper.BuildSegCommandByString( result.ErrorCode.ToString( ) ), string.IsNullOrEmpty( result.Message ) ? new byte[0] : Encoding.UTF8.GetBytes( result.Message ) ).Content );
					if (!send.IsSuccess)
						LogNet?.WriteError( ToString( ), $"Send Failed Message Failed,Client Id:{session.ClientId}" );
				}
			}
			else
			{
				throw new Exception( "Report Result Message only support sync communication, client is MqttSyncClient" );
			}
		}

		/// <summary>
		/// 使用指定的对象来返回网络的API接口，前提是传入的数据为json参数，返回的数据为 <c>OperateResult&lt;string&gt;</c> 数据，详细参照说明<br />
		/// Use the specified object to return the API interface of the network, 
		/// provided that the incoming data is json parameters and the returned data is <c>OperateResult&lt;string&gt;</c> data, 
		/// please refer to the description for details
		/// </summary>
		/// <param name="session">当前的会话内容</param>
		/// <param name="message">客户端发送的消息，其中的payload将会解析为一个json字符串，然后提取参数信息。</param>
		/// <param name="apiObject">当前的对象的内容信息</param>
		public void ReportObjectApiMethod( MqttSession session, MqttClientApplicationMessage message, object apiObject )
		{
			if (session.Protocol == "HUSL")
			{
				ReportOperateResult( session, MqttHelper.HandleObjectMethod( session, message, apiObject ) );
			}
			else
			{
				throw new Exception( "Report Result Message only support sync communication, client is MqttSyncClient" );
			}
		}

		#endregion

		#region Mqtt RPC Support

		private Dictionary<string, MqttRpcApiInfo> apiTopicServiceDict;
		private object rpcApiLock;

		private MqttRpcApiInfo GetMqttRpcApiInfo( string apiTopic )
		{
			MqttRpcApiInfo apiInformation = null;
			lock (rpcApiLock)
			{
				if (apiTopicServiceDict.ContainsKey( apiTopic )) apiInformation = apiTopicServiceDict[apiTopic];
			}
			return apiInformation;
		}

		/// <summary>
		/// 获取当前所有注册的RPC接口信息，将返回一个数据列表。<br />
		/// Get all currently registered RPC interface information, and a data list will be returned.
		/// </summary>
		/// <returns>信息列表</returns>
		public MqttRpcApiInfo[] GetAllMqttRpcApiInfo( )
		{
			MqttRpcApiInfo[] array = null;
			lock (rpcApiLock)
			{
				array = apiTopicServiceDict.Values.ToArray( );
			}
			return array;
		}

		/// <summary>
		/// 注册一个RPC的服务接口，可以指定当前的控制器名称，以及提供RPC服务的原始对象，指定统一的权限控制。<br />
		/// Register an RPC service interface, you can specify the current controller name, 
		/// and the original object that provides the RPC service, Specify unified access control
		/// </summary>
		/// <param name="api">前置的接口信息，可以理解为MVC模式的控制器</param>
		/// <param name="obj">原始对象信息</param>
		/// <param name="permissionAttribute">统一的权限访问配置，将会覆盖单个方法的权限控制。</param>
		public void RegisterMqttRpcApi( string api, object obj, HslMqttPermissionAttribute permissionAttribute )
		{
			lock (rpcApiLock)
			{
				foreach (var item in MqttHelper.GetSyncServicesApiInformationFromObject( api, obj, permissionAttribute ))
				{
					apiTopicServiceDict.Add( item.ApiTopic, item );
				}
			}
		}

		/// <summary>
		/// 注册一个RPC的服务接口，可以指定当前的控制器名称，以及提供RPC服务的原始对象<br />
		/// Register an RPC service interface, you can specify the current controller name, 
		/// and the original object that provides the RPC service
		/// </summary>
		/// <param name="api">前置的接口信息，可以理解为MVC模式的控制器</param>
		/// <param name="obj">原始对象信息</param>
		public void RegisterMqttRpcApi( string api, object obj )
		{
			lock (rpcApiLock)
			{
				foreach (var item in MqttHelper.GetSyncServicesApiInformationFromObject( api, obj ))
				{
					apiTopicServiceDict.Add( item.ApiTopic, item );
				}
			}
		}

		/// <inheritdoc cref="RegisterMqttRpcApi(string, object)"/>
		public void RegisterMqttRpcApi( object obj )
		{
			lock (rpcApiLock)
			{
				foreach (var item in MqttHelper.GetSyncServicesApiInformationFromObject( obj ))
				{
					apiTopicServiceDict.Add( item.ApiTopic, item );
				}
			}
		}

		#endregion

		#region Session Method

		private void AddMqttSession( MqttSession session )
		{
			lock (sessionsLock)
			{
				mqttSessions.Add( session );
			}
			LogNet?.WriteDebug( ToString( ), $"Client[{session.ClientId}] Name:{session.UserName} Online" );
		}

		/// <summary>
		/// 让MQTT客户端正常下线，调用本方法即可自由控制会话客户端强制下线操作。
		/// </summary>
		/// <param name="session">当前的会话信息</param>
		public void RemoveAndCloseSession( MqttSession session )
		{
			lock (sessionsLock)
			{
				mqttSessions.Remove( session );
			}
			session.MqttSocket?.Close( );
			LogNet?.WriteDebug( ToString( ), $"Client[{session.ClientId}] Name:{session.UserName} Offline" );
			if (session.Protocol == "MQTT") OnClientDisConnected?.Invoke( session );
		}

		#endregion

		#region Event Handler

		/// <summary>
		/// Mqtt的消息收到委托
		/// </summary>
		/// <param name="session">当前会话的内容</param>
		/// <param name="message">Mqtt的消息</param>
		public delegate void OnClientApplicationMessageReceiveDelegate( MqttSession session, MqttClientApplicationMessage message );

		/// <summary>
		/// 当收到客户端发来的<see cref="MqttClientApplicationMessage"/>消息时触发<br />
		/// Triggered when a <see cref="MqttClientApplicationMessage"/> message is received from the client
		///</summary>
		public event OnClientApplicationMessageReceiveDelegate OnClientApplicationMessageReceive;

		/// <summary>
		/// 当前mqtt客户端连接上服务器的事件委托
		/// </summary>
		/// <param name="session">当前的会话对象</param>
		public delegate void OnClientConnectedDelegate( MqttSession session );

		/// <summary>
		/// Mqtt的客户端连接上来时触发<br />
		/// Triggered when Mqtt client connects
		/// </summary>
		public event OnClientConnectedDelegate OnClientConnected;

		/// <summary>
		/// Mqtt的客户端下线时触发<br />
		/// Triggered when Mqtt client connects
		/// </summary>
		public event OnClientConnectedDelegate OnClientDisConnected;

		/// <summary>
		/// 验证的委托
		/// </summary>
		/// <param name="mqttSession">当前的MQTT的会话内容</param>
		/// <param name="clientId">客户端的id</param>
		/// <param name="userName">用户名</param>
		/// <param name="passwrod">密码</param>
		/// <returns>0则是通过，否则，就是连接失败</returns>
		public delegate int ClientVerificationDelegate( MqttSession mqttSession, string clientId, string userName, string passwrod );

		/// <summary>
		/// 当客户端连接时，触发的验证事件<br />
		/// Validation event triggered when the client connects
		/// </summary>
		public event ClientVerificationDelegate ClientVerification;                                                   // 验证的委托信息

		#endregion

		#region Public Properties

		/// <summary>
		/// 获取当前的在线的客户端数量<br />
		/// Gets the number of clients currently online
		/// </summary>
		public int OnlineCount => mqttSessions.Count;

		/// <summary>
		/// 获得当前所有的在线的MQTT客户端信息，包括异步的客户端及同步请求的客户端。<br />
		/// Obtain all current online MQTT client information, including asynchronous client and synchronous request client.
		/// </summary>
		public MqttSession[] OnlineSessions 
		{ 
			get
			{
				MqttSession[] snapshoot = null;
				lock (sessionsLock)
					snapshoot = mqttSessions.ToArray( );
				return snapshoot;
			} 
		}

		/// <summary>
		/// 获得当前异步客户端在线的MQTT客户端信息。<br />
		/// Get the MQTT client information of the current asynchronous client online.
		/// </summary>
		public MqttSession[] MqttOnlineSessions
		{
			get
			{
				MqttSession[] snapshoot = null;
				lock (sessionsLock)
					snapshoot = mqttSessions.Where( m => m.Protocol == "MQTT" ).ToArray( );
				return snapshoot;
			}
		}

		/// <summary>
		/// 获得当前同步客户端在线的MQTT客户端信息，如果客户端是短连接，将难以捕获在在线信息。<br />
		/// Obtain the MQTT client information of the current synchronization client online. If the client is a short connection, it will be difficult to capture the online information. <br />
		/// </summary>
		public MqttSession[] SyncOnlineSessions
		{
			get
			{
				MqttSession[] snapshoot = null;
				lock (sessionsLock)
					snapshoot = mqttSessions.Where( m => m.Protocol == "HUSL" ).ToArray( );
				return snapshoot;
			}
		}

		#endregion

		#region Public Method

		/// <summary>
		/// 删除服务器里的指定主题的驻留消息。<br />
		/// Delete the resident message of the specified topic in the server.
		/// </summary>
		/// <param name="topic">等待删除的主题关键字</param>
		public void DeleteRetainTopic( string topic )
		{
			lock (keysLock)
			{
				if (retainKeys.ContainsKey( topic ))
				{
					retainKeys.Remove( topic );
				}
			}
		}

		/// <summary>
		/// 获取所有的驻留的消息的主题，如果消息发布的时候没有使用Retain属性，就无法通过本方法查到<br />
		/// Get the subject of all resident messages. If the Retain attribute is not used when the message is published, it cannot be found by this method
		/// </summary>
		/// <returns>主题的数组</returns>
		public string[] GetAllRetainTopics( )
		{
			string[] keys = null;
			lock (keysLock)
			{
				keys = retainKeys.Select( m => m.Key ).ToArray( );
			}
			return keys;
		}

		#endregion

		#region Private Member

		private readonly Dictionary<string, MqttClientApplicationMessage> retainKeys;
		private readonly object keysLock;                                                                            // 驻留的消息的词典锁

		private readonly List<MqttSession> mqttSessions = new List<MqttSession>( );                                  // MQTT的客户端信息
		private readonly object sessionsLock = new object( );
		private System.Threading.Timer timerHeart;
		// private readonly Dictionary<string, Func<string, byte[], OperateResult<string, byte[]>>> syncServices;       // 同步网络的服务的集合

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString( ) => $"MqttServer[{Port}]";

		#endregion
	}
}
