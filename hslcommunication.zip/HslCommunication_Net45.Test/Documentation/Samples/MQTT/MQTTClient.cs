﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.MQTT;

namespace HslCommunication_Net45.Test.Documentation.Samples.MQTT
{
    public class MQTTClient1
    {
        public void Test1()
        {
            #region Test

            // 简单的实例化例子
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );


            #endregion

        }

        public void Test2( )
        {
            #region Test2

            // 如果有密码的情况
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                                            // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",                                     // 服务器的地址
                Credentials = new MqttCredential( "admin", "123456" )        // 设置了用户名和密码
            } );

            #endregion
        }

        public void Test3( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            #region Test3

            // 连接服务器
            HslCommunication.OperateResult connect =  mqttClient.ConnectServer( );
            if (connect.IsSuccess)
            {
                // 连接成功
            }
            else
            {
                // 连接失败，过会就需要重新连接了
            }

            // 重点说明。如果过会网络不行了，断开了，内部会自动连接服务器的，你只管publish就可以了

            #endregion
        }

        public void Test4( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            #region Test4

            // 发布示例
            HslCommunication.OperateResult connect = mqttClient.PublishMessage( new MqttApplicationMessage( )
            {
                Topic = "A",                                                           // 主题
                QualityOfServiceLevel = MqttQualityOfServiceLevel.AtMostOnce,          // 如果是实时数据，适合用这个
                Payload = Encoding.UTF8.GetBytes("Test data")                          // 发布的数据
            } );
            if (connect.IsSuccess)
            {
                // 发布成功
            }
            else
            {
                // 发布失败
            }

            // 重点说明。如果过会网络不行了，断开了，内部会自动连接服务器的，你只管publish就可以了

            #endregion
        }

        public void Test5( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            #region Test5

            // 订阅示例
            mqttClient.OnMqttMessageReceived += ( string topic, byte[] payload ) =>
            {
                Console.WriteLine( "Time:" + DateTime.Now.ToString( ) );
                Console.WriteLine( "Topic:" + topic );
                Console.WriteLine( "Payload:" + Encoding.UTF8.GetString( payload ) );
            };

            // 然后添加订阅
            HslCommunication.OperateResult sub = mqttClient.SubscribeMessage( "A" );
            if (sub.IsSuccess)
            {
                // 订阅成功
            }
            else
            {
                // 订阅失败
            }

            #endregion
        }

        public void Test6( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            #region Test6

            // 订阅示例
            mqttClient.OnMqttMessageReceived += ( string topic, byte[] payload ) =>
            {
                Console.WriteLine( "Time:" + DateTime.Now.ToString( ) );
                Console.WriteLine( "Topic:" + topic );
                Console.WriteLine( "Payload:" + Encoding.UTF8.GetString( payload ) );
            };

            // 然后添加订阅，此处一口气添加了3个订阅
            HslCommunication.OperateResult sub = mqttClient.SubscribeMessage( new string[] { "A", "B", "C" } );
            if (sub.IsSuccess)
            {
                // 订阅成功
            }
            else
            {
                // 订阅失败
            }

            #endregion
        }


        public void Test7( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            #region Test7

            // 取消订阅示例，假设你已经订阅了A的操作
            HslCommunication.OperateResult sub = mqttClient.UnSubscribeMessage( "A" );
            if (sub.IsSuccess)
            {
                // 取消订阅成功
            }
            else
            {
                // 取消订阅失败
                // 需要注意的是，即使是取消订阅失败了，在网络恢复的时候，当前的取消的主题不会再被重新订阅
            }

            #endregion
        }

        public void Test8( )
        {
            MqttClient mqttClient = new MqttClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );

            #region Test8

            // 网络失败的情况，需要自己来手动控制重连，实例化后进行事件绑定
            mqttClient.OnNetworkError += ( object sender, EventArgs e ) =>
            {
                // 当网络异常的时候触发，可以在此处重连服务器
                if (sender is MqttClient client)
                {
                    // 开始重连服务器，直到连接成功为止
                    client.LogNet?.WriteInfo( "网络异常，准备10秒后重新连接。" );
                    while (true)
                    {
                        // 每隔10秒重连
                        System.Threading.Thread.Sleep( 10_000 );
                        client.LogNet?.WriteInfo( "准备重新连接服务器..." );
                        HslCommunication.OperateResult connect = client.ConnectServer( );
                        if (connect.IsSuccess)
                        {
                            // 连接成功后，可以在下方break之前进行订阅，或是数据初始化操作
                            client.LogNet?.WriteInfo( "连接服务器成功！" );
                            break;
                        }
                        client.LogNet?.WriteInfo( "连接失败，准备10秒后重新连接。" );
                    }
                }
            };

            #endregion
        }

    }
}
