﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using HslCommunication.BasicFramework;

namespace HslCommunication.Core
{
	/// <summary>
	/// HslCommunication的一些静态辅助方法<br />
	/// Some static auxiliary methods of HslCommunication
	/// </summary>
	public class HslHelper
	{
		/// <summary>
		/// 解析地址的附加参数方法，比如你的地址是s=100;D100，可以提取出"s"的值的同时，修改地址本身，如果"s"不存在的话，返回给定的默认值<br />
		/// The method of parsing additional parameters of the address, for example, if your address is s=100;D100, you can extract the value of "s" and modify the address itself. If "s" does not exist, return the given default value
		/// </summary>
		/// <param name="address">复杂的地址格式，比如：s=100;D100</param>
		/// <param name="paraName">等待提取的参数名称</param>
		/// <param name="defaultValue">如果提取的参数信息不存在，返回的默认值信息</param>
		/// <returns>解析后的新的数据值或是默认的给定的数据值</returns>
		public static int ExtractParameter( ref string address, string paraName, int defaultValue )
		{
			OperateResult<int> extra = ExtractParameter( ref address, paraName );
			return extra.IsSuccess ? extra.Content : defaultValue;
		}

		/// <summary>
		/// 解析地址的附加参数方法，比如你的地址是s=100;D100，可以提取出"s"的值的同时，修改地址本身，如果"s"不存在的话，返回错误的消息内容<br />
		/// The method of parsing additional parameters of the address, for example, if your address is s=100;D100, you can extract the value of "s" and modify the address itself. 
		/// If "s" does not exist, return the wrong message content
		/// </summary>
		/// <param name="address">复杂的地址格式，比如：s=100;D100</param>
		/// <param name="paraName">等待提取的参数名称</param>
		/// <returns>解析后的参数结果内容</returns>
		public static OperateResult<int> ExtractParameter( ref string address, string paraName )
		{
			try
			{
				Match match = Regex.Match( address, paraName + "=[0-9A-Fa-fx]+;" );
				if (!match.Success) return new OperateResult<int>( $"Address [{address}] can't find [{paraName}] Parameters. for example : {paraName}=1;100" );

				string number = match.Value.Substring( paraName.Length + 1, match.Value.Length - paraName.Length - 2 );
				int value = number.StartsWith( "0x" ) ? Convert.ToInt32( number.Substring( 2 ), 16 ) : number.StartsWith( "0" ) ? Convert.ToInt32( number, 8 ) : Convert.ToInt32( number );

				address = address.Replace( match.Value, "" );
				return OperateResult.CreateSuccessResult( value );
			}
			catch (Exception ex)
			{
				return new OperateResult<int>( $"Address [{address}] Get [{paraName}] Parameters failed: " + ex.Message );
			}
		}

		/// <summary>
		/// 切割当前的地址数据信息，根据读取的长度来分割成多次不同的读取内容，需要指定地址，总的读取长度，切割读取长度<br />
		/// Cut the current address data information, and divide it into multiple different read contents according to the read length. 
		/// You need to specify the address, the total read length, and the cut read length
		/// </summary>
		/// <param name="address">整数的地址信息</param>
		/// <param name="length">读取长度信息</param>
		/// <param name="segment">切割长度信息</param>
		/// <returns>切割结果</returns>
		public static OperateResult<int[], int[]> SplitReadLength( int address, ushort length, ushort segment )
		{
			int[] segments = SoftBasic.SplitIntegerToArray( length, segment );
			int[] addresses = new int[segments.Length];
			for (int i = 0; i < addresses.Length; i++)
			{
				if (i == 0) addresses[i] = address;
				else addresses[i] = addresses[i - 1] + segments[i - 1];
			}
			return OperateResult.CreateSuccessResult( addresses, segments );
		}

		/// <summary>
		/// 根据指定的长度切割数据数组，返回地址偏移量信息和数据分割信息
		/// </summary>
		/// <typeparam name="T">数组类型</typeparam>
		/// <param name="address">起始的地址</param>
		/// <param name="value">实际的数据信息</param>
		/// <param name="segment">分割的基本长度</param>
		/// <param name="addressLength">一个地址代表的数据长度</param>
		/// <returns>切割结果内容</returns>
		public static OperateResult<int[], List<T[]>> SplitWriteData<T>( int address, T[] value, ushort segment, int addressLength )
		{
			List<T[]> segments = SoftBasic.ArraySplitByLength( value, segment * addressLength );
			int[] addresses = new int[segments.Count];
			for (int i = 0; i < addresses.Length; i++)
			{
				if (i == 0) addresses[i] = address;
				else addresses[i] = addresses[i - 1] + segments[i - 1].Length / addressLength;
			}
			return OperateResult.CreateSuccessResult( addresses, segments );
		}
	}
}
