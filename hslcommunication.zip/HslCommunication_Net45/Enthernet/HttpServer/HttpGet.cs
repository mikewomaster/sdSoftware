﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HslCommunication.Enthernet
{
	/// <summary>
	/// 代表带网络请求的类中是采用GET的方式来请求的
	/// </summary>
	public class HttpGet : Attribute
	{
	}
}
