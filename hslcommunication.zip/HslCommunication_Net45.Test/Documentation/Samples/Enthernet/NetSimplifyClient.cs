﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Enthernet;
using HslCommunication.Enthernet.Redis;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.Enthernet
{
    public class NetSimplifyClientExample
    {
    }
}
