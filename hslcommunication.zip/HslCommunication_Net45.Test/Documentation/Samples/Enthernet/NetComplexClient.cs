﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Enthernet;

namespace HslCommunication_Net45.Test.Documentation.Samples.Enthernet
{
    public class NetComplexClientExample
    {


    }
}
