﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.Core;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HslCommunication_Net45.Test.Core
{
	[TestClass]
	public class HslHelperTest
	{
		[TestMethod]
		public void AnalysisAddressAdditionalParametersTest( )
		{
			string address = "s=10;D100";
			int s = HslHelper.ExtractParameter( ref address, "s", 0 );
			Assert.AreEqual( 10, s );
			Assert.AreEqual( "D100", address );

			address = "M100";
			s = HslHelper.ExtractParameter( ref address, "s", 0 );
			Assert.AreEqual( 0, s );
			Assert.AreEqual( "M100", address );

			address = "s=2;x=4;M100";
			s = HslHelper.ExtractParameter( ref address, "s", 0 );
			Assert.AreEqual( 2, s );
			Assert.AreEqual( "x=4;M100", address );

			address = "s=2;x=4;M100";
			int x = HslHelper.ExtractParameter( ref address, "x", 0 );
			Assert.AreEqual( 4, x );
			Assert.AreEqual( "s=2;M100", address );

			address = "s=2;x=4;M100";
			int c = HslHelper.ExtractParameter( ref address, "c", 0 );
			Assert.AreEqual( 0, c );
			Assert.AreEqual( "s=2;x=4;M100", address );

			address = "cpu=0x10;M100";
			int cpu = HslHelper.ExtractParameter( ref address, "cpu", 0 );
			Assert.AreEqual( 16, cpu );
			Assert.AreEqual( "M100", address );

			address = "cpu=010;M100";
			cpu = HslHelper.ExtractParameter( ref address, "cpu", 0 );
			Assert.AreEqual( 8, cpu );
			Assert.AreEqual( "M100", address );

			address = "cpu=0;M100";
			OperateResult<int> analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 0, analysis.Content );
			Assert.AreEqual( "M100", address );

			address = "s=2;x=4;M100";
			analysis = HslHelper.ExtractParameter( ref address, "c" );
			HslAssert.IsFalse( analysis );
			Assert.AreEqual( "s=2;x=4;M100", address );

			address = "s=123;x=4;DB100.0";
			analysis = HslHelper.ExtractParameter( ref address, "s" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 123, analysis.Content );
			Assert.AreEqual( "x=4;DB100.0", address );

			address = "cpu=0x10;M100";
			analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 16, analysis.Content );
			Assert.AreEqual( "M100", address );

			address = "cpu=0xFF;M100";
			analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 255, analysis.Content );
			Assert.AreEqual( "M100", address );

			address = "cpu=0x0a;M100";
			analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 10, analysis.Content );
			Assert.AreEqual( "M100", address );

			address = "cpu=010;M100";
			analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 8, analysis.Content );
			Assert.AreEqual( "M100", address );

			address = "cpu=0;M100";
			analysis = HslHelper.ExtractParameter( ref address, "cpu" );
			HslAssert.IsTrue( analysis );
			Assert.AreEqual( 0, analysis.Content );
			Assert.AreEqual( "M100", address );
		}

		[TestMethod]
		public void SplitReadLengthTest( )
		{
			OperateResult<int[], int[]> analysis = HslHelper.SplitReadLength( 0, 100, 60 );
			HslAssert.IsTrue( analysis );
			HslAssert.AreArrayEqual( new int[] { 0, 60 }, analysis.Content1 );
			HslAssert.AreArrayEqual( new int[] { 60, 40 }, analysis.Content2 );

			analysis = HslHelper.SplitReadLength( 104, 88, 36 );
			HslAssert.IsTrue( analysis );
			HslAssert.AreArrayEqual( new int[] { 104, 140, 176 }, analysis.Content1 );
			HslAssert.AreArrayEqual( new int[] { 36, 36, 16 }, analysis.Content2 );
		}

		[TestMethod]
		public void SplitWriteDataTest( )
		{
			byte[] buffer = new byte[200];
			for (int i = 0; i < buffer.Length; i++)
			{
				buffer[i] = (byte)i;
			}

			OperateResult<int[], List<byte[]>> analysis = HslHelper.SplitWriteData( 0, buffer, 60, 2 );
			HslAssert.IsTrue( analysis );
			HslAssert.AreArrayEqual( new int[] { 0, 60 }, analysis.Content1 );
			Assert.AreEqual( 2, analysis.Content2.Count );
			HslAssert.AreArrayEqual( buffer.SelectBegin( 120 ), analysis.Content2[0] );
			HslAssert.AreArrayEqual( buffer.SelectLast( 80 ), analysis.Content2[1] );

			analysis = HslHelper.SplitWriteData( 0, buffer, 70, 1 );
			HslAssert.IsTrue( analysis );
			HslAssert.AreArrayEqual( new int[] { 0, 70, 140 }, analysis.Content1 );
			Assert.AreEqual( 3, analysis.Content2.Count );
			HslAssert.AreArrayEqual( buffer.SelectBegin( 70 ), analysis.Content2[0] );
			HslAssert.AreArrayEqual( buffer.SelectMiddle( 70, 70 ), analysis.Content2[1] );
			HslAssert.AreArrayEqual( buffer.SelectLast( 60 ), analysis.Content2[2] );
		}
	}
}
