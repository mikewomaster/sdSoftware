﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication;

namespace HslCommunication_Net45.Test.BasicFramework
{
	[TestClass]
	public class HslExtensionTest
	{
		[TestMethod]
		public void IncreaseByTest1( )
		{
			int[] a = new int[5] { 1, 2, 3, 4, 5 };
			int[] b = a.IncreaseBy( 1 );

			Assert.IsTrue( b[0] == 2 );
			Assert.IsTrue( b[1] == 3 );
			Assert.IsTrue( b[2] == 4 );
			Assert.IsTrue( b[3] == 5 );
			Assert.IsTrue( b[4] == 6 );
		}

		[TestMethod]
		public void IncreaseByTest2( )
		{
			short[] a = new short[5] { 1, 2, 3, 4, 5 };
			short[] b = a.IncreaseBy<short>( 1 );

			Assert.IsTrue( b[0] == 2 );
			Assert.IsTrue( b[1] == 3 );
			Assert.IsTrue( b[2] == 4 );
			Assert.IsTrue( b[3] == 5 );
			Assert.IsTrue( b[4] == 6 );
		}

		//[TestMethod]
		//public void IncreaseByTest3( )
		//{
		//	byte[] a = new byte[5] { 1, 2, 3, 4, 5 };
		//	byte[] b = a.IncreaseBy<byte>( 1 );

		//	Assert.IsTrue( b[0] == 2 );
		//	Assert.IsTrue( b[1] == 3 );
		//	Assert.IsTrue( b[2] == 4 );
		//	Assert.IsTrue( b[3] == 5 );
		//	Assert.IsTrue( b[4] == 6 );
		//}
	}
}
