﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Profinet.AllenBradley;
using HslCommunication;
using HslCommunication.BasicFramework;

namespace HslCommunication_Net45.Test.Profinet.AllenBradley
{
    [TestClass]
    public class AllenBradleySLCNetTest
    {
        [TestMethod]
        public void BuildReadCommandTest( )
        {
            OperateResult<byte[]> build = AllenBradleySLCNet.BuildReadCommand( "A9:0", 2 );
            Assert.IsTrue( build.IsSuccess, build.Message );
            Assert.AreEqual( "00 05 00 00 0F 00 00 01 A2 02 09 8E 00 00", build.Content.ToHexString( ' ' ) );
            
            
            build = AllenBradleySLCNet.BuildReadCommand( "S:24", 2 );
            Assert.IsTrue( build.IsSuccess, build.Message );
            Assert.AreEqual( "00 05 00 00 0F 00 00 01 A2 02 02 84 18 00", build.Content.ToHexString( ' ' ) );


        }

        [TestMethod]
        public void AnalysisBitIndexTest( )
        {
            string address = AllenBradleySLCNet.AnalysisBitIndex( "S:1/15", out int bitIndex );
            Assert.AreEqual( "S:1", address );
            Assert.AreEqual( 15, bitIndex );
        }
    }
}
