﻿using HslCommunication.BasicFramework;
using HslCommunication.Core;
using HslCommunication.Core.Net;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using HslCommunication.Reflection;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.Profinet.LSIS
{
	/// <summary>
	/// XGB Cnet I/F module supports Serial Port. On Tcp/ip implementation
	/// </summary>
	/// <remarks>
	/// Address example likes the follow
	/// <list type="table">
	///   <listheader>
	///     <term>地址名称</term>
	///     <term>地址代号</term>
	///     <term>示例</term>
	///     <term>地址进制</term>
	///     <term>字操作</term>
	///     <term>位操作</term>
	///     <term>备注</term>
	///   </listheader>
	///   <item>
	///     <term>*</term>
	///     <term>P</term>
	///     <term>PX100,PB100,PW100,PD100,PL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>*</term>
	///     <term>M</term>
	///     <term>MX100,MB100,MW100,MD100,ML100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>*</term>
	///     <term>L</term>
	///     <term>LX100,LB100,LW100,LD100,LL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>*</term>
	///     <term>K</term>
	///     <term>KX100,KB100,KW100,KD100,KL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>*</term>
	///     <term>F</term>
	///     <term>FX100,FB100,FW100,FD100,FL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>T</term>
	///     <term>TX100,TB100,TW100,TD100,TL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>C</term>
	///     <term>CX100,CB100,CW100,CD100,CL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>D</term>
	///     <term>DX100,DB100,DW100,DD100,DL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>S</term>
	///     <term>SX100,SB100,SW100,SD100,SL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>Q</term>
	///     <term>QX100,QB100,QW100,QD100,QL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>I</term>
	///     <term>IX100,IB100,IW100,ID100,IL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>N</term>
	///     <term>NX100,NB100,NW100,ND100,NL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>U</term>
	///     <term>UX100,UB100,UW100,UD100,UL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>Z</term>
	///     <term>ZX100,ZB100,ZW100,ZD100,ZL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term></term>
	///     <term>R</term>
	///     <term>RX100,RB100,RW100,RD100,RL100</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	/// </list>
	/// </remarks>
	public class XGBCnetOverTcp : NetworkDeviceSoloBase
	{
		#region Constructor

		/// <summary>
		/// Instantiate a Default object
		/// </summary>
		public XGBCnetOverTcp( )
		{
			WordLength    = 2;
			ByteTransform = new RegularByteTransform( );
		}

		#endregion

		#region Public Member

		/// <summary>
		/// PLC Station No.
		/// </summary>
		public byte Station { get; set; } = 0x05;

		#endregion

		#region Read Write Byte

		/// <summary>
		/// Read single byte value from plc
		/// </summary>
		/// <param name="address">Start address</param>
		/// <returns>result</returns>
		[HslMqttApi( "ReadByte", "" )]
		public OperateResult<byte> ReadByte( string address ) => ByteTransformHelper.GetResultFromArray( Read( address, 2 ) );

		/// <summary>
		/// Write single byte value to plc
		/// </summary>
		/// <param name="address">Start address</param>
		/// <param name="value">value</param>
		/// <returns>Whether to write the successful</returns>
		[HslMqttApi( "WriteByte", "" )]
		public OperateResult Write( string address, byte value ) => Write( address, new byte[] { value } );

		#endregion

		#region Async Read Write Byte
#if !NET35 && !NET20
		/// <summary>
		/// Read single byte value from plc
		/// </summary>
		/// <param name="address">Start address</param>
		/// <returns>read result</returns>
		public async Task<OperateResult<byte>> ReadByteAsync( string address ) => ByteTransformHelper.GetResultFromArray( await ReadAsync( address, 2 ) );

		/// <summary>
		/// Write single byte value to plc
		/// </summary>
		/// <param name="address">Start address</param>
		/// <param name="value">value</param>
		/// <returns>Whether to write the successful</returns>
		public async Task<OperateResult> WriteAsync( string address, byte value ) => await WriteAsync( address, new byte[] { value } );

#endif
		#endregion

		#region Read Write Bool

		/// <inheritdoc/>
		[HslMqttApi( "ReadBoolArray", "" )]
		public override OperateResult<bool[]> ReadBool( string address, ushort length )
		{
			OperateResult<byte[]> command = XGBCnetOverTcp.BuildReadOneCommand( Station, address, length );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( command );

			OperateResult<byte[]> read = ReadFromCoreServer( command.Content );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( read );

			return OperateResult.CreateSuccessResult( SoftBasic.ByteToBoolArray( XGBCnetOverTcp.ExtractActualData( read.Content, true ).Content, length ) );
		}

		/// <summary>
		/// ReadCoil, same as ReadBool
		/// </summary>
		/// <param name="address">address, for example: MX100, PX100</param>
		/// <returns>Result</returns>
		public OperateResult<bool> ReadCoil( string address ) => ReadBool( address );

		/// <summary>
		/// ReadCoil, same as ReadBool
		/// </summary>
		/// <param name="address">address, for example: MX100, PX100</param>
		/// <param name="length">array length</param>
		/// <returns>result</returns>
		public OperateResult<bool[]> ReadCoil( string address, ushort length ) => ReadBool( address, length );

		/// <summary>
		/// WriteCoil
		/// </summary>
		/// <param name="address">Start Address</param>
		/// <param name="value">value for write</param>
		/// <returns>whether write is success</returns>
		public OperateResult WriteCoil( string address, bool value ) => Write( address, value );

		/// <inheritdoc/>
		[HslMqttApi( "WriteBool", "" )]
		public override OperateResult Write( string address, bool value ) => Write( address, new byte[] { (byte)(value ? 0x01 : 0x00) } );

		#endregion

		#region Async Read Write Bool
#if !NET35 && !NET20
		/// <inheritdoc/>
		public async override Task<OperateResult<bool[]>> ReadBoolAsync( string address, ushort length )
		{
			OperateResult<byte[]> command = XGBCnetOverTcp.BuildReadOneCommand( Station, address, length );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( command );

			OperateResult<byte[]> read = await ReadFromCoreServerAsync( command.Content );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( read );

			return OperateResult.CreateSuccessResult( SoftBasic.ByteToBoolArray( XGBCnetOverTcp.ExtractActualData( read.Content, true ).Content, length ) );
		}

		/// <inheritdoc cref="ReadCoil(string)"/>
		public async Task<OperateResult<bool>> ReadCoilAsync( string address ) => await ReadBoolAsync( address );

		/// <inheritdoc cref="ReadCoil(string, ushort)"/>
		public async Task<OperateResult<bool[]>> ReadCoilAsync( string address, ushort length ) => await ReadBoolAsync( address, length );

		/// <inheritdoc cref="WriteCoil(string, bool)"/>
		public async Task<OperateResult> WriteCoilAsync( string address, bool value ) => await WriteAsync( address, value );

		/// <inheritdoc cref="WriteCoil(string, bool)"/>
		public async override Task<OperateResult> WriteAsync( string address, bool value ) => await WriteAsync( address, new byte[] { (byte)(value ? 0x01 : 0x00) } );

#endif
		#endregion

		#region Read Write Support

		/// <inheritdoc/>
		[HslMqttApi( "ReadByteArray", "" )]
		public override OperateResult<byte[]> Read(string address, ushort length)
		{
			OperateResult<byte[]> command = BuildReadCommand(Station, address, length);
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadFromCoreServer(command.Content);
			if (!read.IsSuccess) return read;

			return ExtractActualData(read.Content, true);
		}

		/// <inheritdoc/>
		[HslMqttApi( "WriteByteArray", "" )]
		public override OperateResult Write(string address, byte[] value)
		{
			OperateResult<byte[]> command = BuildWriteCommand(Station, address, value);
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadFromCoreServer(command.Content);
			if (!read.IsSuccess) return read;

			return ExtractActualData(read.Content, false);
		}

		#endregion

		#region Async Read Write Support
#if !NET35 && !NET20
		/// <inheritdoc/>
		public override async Task<OperateResult<byte[]>> ReadAsync( string address, ushort length )
		{
			OperateResult<byte[]> command = BuildReadCommand( Station, address, length );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = await ReadFromCoreServerAsync( command.Content );
			if (!read.IsSuccess) return read;

			return ExtractActualData( read.Content, true );
		}

		/// <inheritdoc/>
		public override async Task<OperateResult> WriteAsync( string address, byte[] value )
		{
			OperateResult<byte[]> command = BuildWriteCommand( Station, address, value );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = await ReadFromCoreServerAsync( command.Content );
			if (!read.IsSuccess) return read;

			return ExtractActualData( read.Content, false );
		}
#endif
		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString() => $"XGBCnetOverTcp[{IpAddress}:{Port}]";

		#endregion

		#region Static Helper

		/// <summary>
		/// AnalysisAddress IX0.0.0 QX0.0.0  MW1.0  MB1.0
		/// </summary>
		/// <param name="address"></param>
		/// <param name="QI"></param>
		/// <returns></returns>
		public static int CalculateAddressStarted(string address, bool QI = false)
		{
			if (address.IndexOf('.') < 0)
			{
				return Convert.ToInt32(address);
			}
			else
			{
				string[] temp = address.Split('.');
				if (!QI)
					return Convert.ToInt32(temp[0]);
				else
					return Convert.ToInt32(temp[2]);
			}
		}

        /// <summary>
        /// NumberStyles HexNumber
        /// </summary>
        /// <param name="value"></param>
        /// <returns></returns>
        static bool IsHex(string value)
        {
            if (string.IsNullOrEmpty(value))
                return false;


            var state = false;

            for (var i = 0; i < value.Length; i++)
            {
                switch (value[i])
                {


                    case 'A':
                    case 'B':
                    case 'C':
                    case 'D':
                    case 'E':
                    case 'F':
                    case 'a':
                    case 'b':
                    case 'c':
                    case 'd':
                    case 'e':
                    case 'f':
                        state = true;
                        break;

                }
            }

            return state;
        }
        /// <summary>
        /// AnalysisAddress
        /// </summary>
        /// <param name="address">start address</param>
        /// <returns>analysis result</returns>
        public static OperateResult<string> AnalysisAddress(string address)
		{
			// P,M,L,K,F,T
			// P,M,L,K,F,T,C,D,S
			StringBuilder sb = new StringBuilder();
			try
			{
				sb.Append("%");
				char[] types = new char[] { 'P', 'M', 'L', 'K', 'F', 'T', 'C', 'D', 'S', 'Q', 'I', 'N', 'U', 'Z', 'R' };
				bool exsist = false;
				for (int i = 0; i < types.Length; i++)
				{
					if (types[i] == address[0])
					{
						sb.Append(types[i]);

						switch (address[1])
						{
							case 'X':
								sb.Append("X");
								if (address[0] == 'I' || address[0] == 'Q')
								{
									sb.Append(CalculateAddressStarted(address.Substring(2), true));
								}
								else
								{


									if (IsHex(address.Substring(2))) { sb.Append(address.Substring(2)); }
									else sb.Append(CalculateAddressStarted(address.Substring(2)));
								}


								break;
							default:
								sb.Append("B");
								int startIndex = 0;
								if (address[1] == 'B')
								{
									startIndex = CalculateAddressStarted(address.Substring(2));
									sb.Append(startIndex == 0 ? startIndex : startIndex *= 2);
								}
								else if (address[1] == 'W')
								{
									startIndex = CalculateAddressStarted(address.Substring(2));
									sb.Append(startIndex == 0 ? startIndex : startIndex *= 2);
								}
								else if (address[1] == 'D')
								{
									startIndex = CalculateAddressStarted(address.Substring(2));
									sb.Append(startIndex == 0 ? startIndex : startIndex *= 4);
								}
								else if (address[1] == 'L')
								{
									startIndex = CalculateAddressStarted(address.Substring(2));
									sb.Append(startIndex == 0 ? startIndex : startIndex *= 8);
								}
								else
								{
									if (address[0] == 'I' || address[0] == 'Q')
									{
										sb.Append(CalculateAddressStarted(address.Substring(1), true));
									}
									else
									{
										if (IsHex(address.Substring(1))) { sb.Append(address.Substring(1)); }
										else sb.Append(CalculateAddressStarted(address.Substring(1)));
									}

								}

								break;
						}
						exsist = true;
						break;
					}
				}
				if (!exsist) throw new Exception(StringResources.Language.NotSupportedDataType);
			}
			catch (Exception ex)
			{
				return new OperateResult<string>(ex.Message);
			}

			return OperateResult.CreateSuccessResult(sb.ToString());
		}

		/// <summary>
		/// reading address  Type of ReadByte
		/// </summary>
		/// <param name="station">plc station</param>
		/// <param name="address">address, for example: M100, D100, DW100</param>
		/// <param name="length">read length</param>
		/// <returns>command bytes</returns>
		public static OperateResult<byte[]> BuildReadByteCommand(byte station, string address, ushort length)
		{
			var analysisResult = AnalysisAddress(address);
			if (!analysisResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>(analysisResult);

			List<byte> command = new List<byte>();
			command.Add(0x05);    // ENQ
			command.AddRange(SoftBasic.BuildAsciiBytesFrom(station));
			command.Add(0x72);    // command r
			command.Add(0x53);    // command type: SB
			command.Add(0x42);
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)analysisResult.Content.Length));
			command.AddRange(Encoding.ASCII.GetBytes(analysisResult.Content));
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)length));
			command.Add(0x04);    // EOT

			int sum = 0;
			for (int i = 0; i < command.Count; i++)
			{
				sum += command[i];
			}
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)sum));

			return OperateResult.CreateSuccessResult(command.ToArray());
		}

		/// <summary>
		/// One reading address Type of ReadByte
		/// </summary>
		/// <param name="station">plc station</param>
		/// <param name="address">address, for example: MX100, PX100</param>
		/// <param name="length">read length</param>
		/// <returns></returns>
		public static OperateResult<byte[]> BuildReadOneCommand(byte station, string address, ushort length)
		{
			var analysisResult = AnalysisAddress(address);
			if (!analysisResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>(analysisResult);

			List<byte> command = new List<byte>();
			command.Add(0x05);    // ENQ
			command.AddRange(SoftBasic.BuildAsciiBytesFrom(station));
			command.Add(0x72);    // command r
			command.Add(0x53);    // command type: SS
			command.Add(0x53);
			command.Add(0x30);    // Number of blocks
			command.Add(0x31);
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)analysisResult.Content.Length));
			command.AddRange(Encoding.ASCII.GetBytes(analysisResult.Content));
			command.Add(0x04);    // EOT

			int sum = 0;
			for (int i = 0; i < command.Count; i++)
			{
				sum += command[i];
			}
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)sum));

			return OperateResult.CreateSuccessResult(command.ToArray());
		}

		/// <summary>
		/// build read command. 
		/// </summary>
		/// <param name="station">station</param>
		/// <param name="address">start address</param>
		/// <param name="length">address length</param>
		/// <returns> command</returns>
		public static OperateResult<byte[]> BuildReadCommand( byte station, string address, ushort length )
		{
			var DataTypeResult = XGBFastEnet.GetDataTypeToAddress( address );
			if (!DataTypeResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( DataTypeResult );

			switch (DataTypeResult.Content)
			{
				case "Bit": return XGBCnetOverTcp.BuildReadOneCommand( station, address, length );
				case "Word":
				case "DWord":
				case "LWord":
				case "Continuous": return XGBCnetOverTcp.BuildReadByteCommand( station, address, length );
				default: return new OperateResult<byte[]>( StringResources.Language.NotSupportedDataType );
			}
		}

		/// <summary>
		/// write data to address  Type of ReadByte
		/// </summary>
		/// <param name="station">plc station</param>
		/// <param name="address">address, for example: M100, D100, DW100</param>
		/// <param name="value">source value</param>
		/// <returns>command bytes</returns>
		public static OperateResult<byte[]> BuildWriteByteCommand(byte station, string address, byte[] value)
		{
			var analysisResult = AnalysisAddress(address);
			if (!analysisResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>(analysisResult);
			List<byte> command = new List<byte>();
			command.Add(0x05);    // ENQ
			command.AddRange(SoftBasic.BuildAsciiBytesFrom(station));
			command.Add(0x77);    // command w
			command.Add(0x53);    // command type: S
			command.Add(0x42);       // command type: B
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)analysisResult.Content.Length));
			command.AddRange(Encoding.ASCII.GetBytes(analysisResult.Content));
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)value.Length));
			command.AddRange(SoftBasic.BytesToAsciiBytes(value));
			command.Add(0x04);    // EOT
			int sum = 0;
			for (int i = 0; i < command.Count; i++)
			{
				sum += command[i];
			}
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)sum));

			return OperateResult.CreateSuccessResult(command.ToArray());
		}
		/// <summary>
		/// write data to address  Type of One
		/// </summary>
		/// <param name="station">plc station</param>
		/// <param name="address">address, for example: M100, D100, DW100</param>
		/// <param name="value">source value</param>
		/// <returns>command bytes</returns>
		public static OperateResult<byte[]> BuildWriteOneCommand(byte station, string address, byte[] value)
		{
			var analysisResult = AnalysisAddress(address);
			if (!analysisResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>(analysisResult);

			List<byte> command = new List<byte>();
			command.Add(0x05);    // ENQ
			command.AddRange(SoftBasic.BuildAsciiBytesFrom(station));
			command.Add(0x77);    // command w
			command.Add(0x53);    // command type: S
			command.Add(0x53);     // command type: S
			command.Add(0x30);    // Number of blocks
			command.Add(0x31);
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)analysisResult.Content.Length));
			command.AddRange(Encoding.ASCII.GetBytes(analysisResult.Content));
			command.AddRange(SoftBasic.BytesToAsciiBytes(value));
			command.Add(0x04);    // EOT
			int sum = 0;
			for (int i = 0; i < command.Count; i++)
			{
				sum += command[i];
			}
			command.AddRange(SoftBasic.BuildAsciiBytesFrom((byte)sum));

			return OperateResult.CreateSuccessResult(command.ToArray());
		}

		/// <summary>
		/// write data to address  Type of ReadByte
		/// </summary>
		/// <param name="station">plc station</param>
		/// <param name="address">address, for example: M100, D100, DW100</param>
		/// <param name="value">source value</param>
		/// <returns>command bytes</returns>
		public static OperateResult<byte[]> BuildWriteCommand( byte station, string address, byte[] value )
		{
			var DataTypeResult = XGBFastEnet.GetDataTypeToAddress( address );
			if (!DataTypeResult.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( DataTypeResult );

			switch (DataTypeResult.Content)
			{
				case "Bit": return XGBCnetOverTcp.BuildWriteOneCommand( station, address, value );
				case "Word":
				case "DWord":
				case "LWord":
				case "Continuous": return XGBCnetOverTcp.BuildWriteByteCommand( station, address, value );
				default: return new OperateResult<byte[]>( StringResources.Language.NotSupportedDataType );
			}
		}

		/// <summary>
		/// Extract actual data form plc response
		/// </summary>
		/// <param name="response">response data</param>
		/// <param name="isRead">read</param>
		/// <returns>result</returns>
		public static OperateResult<byte[]> ExtractActualData(byte[] response, bool isRead)
		{
			try
			{
				if (isRead)
				{
					if (response[0] == 0x06)
					{
						byte[] buffer = new byte[response.Length - 13];
						Array.Copy(response, 10, buffer, 0, buffer.Length);
						return OperateResult.CreateSuccessResult(SoftBasic.AsciiBytesToBytes(buffer));
					}
					else
					{
						byte[] buffer = new byte[response.Length - 9];
						Array.Copy(response, 6, buffer, 0, buffer.Length);
						return new OperateResult<byte[]>(BitConverter.ToUInt16(SoftBasic.AsciiBytesToBytes(buffer), 0), "Data:" + SoftBasic.ByteToHexString(response));
					}
				}
				else
				{
					if (response[0] == 0x06)
					{
						return OperateResult.CreateSuccessResult(new byte[0]);
					}
					else
					{
						byte[] buffer = new byte[response.Length - 9];
						Array.Copy(response, 6, buffer, 0, buffer.Length);
						return new OperateResult<byte[]>(BitConverter.ToUInt16(SoftBasic.AsciiBytesToBytes(buffer), 0), "Data:" + SoftBasic.ByteToHexString(response));
					}
				}
			}
			catch (Exception ex)
			{
				return new OperateResult<byte[]>(ex.Message);
			}
		}

		#endregion
	}
}
