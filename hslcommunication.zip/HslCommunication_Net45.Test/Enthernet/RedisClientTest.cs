﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Enthernet.Redis;
using HslCommunication;

namespace HslCommunication_Net45.Test.Enthernet
{
	[TestClass]
	public class RedisClientTest
	{
		[TestMethod]
		public void RedisClientTest1( )
		{
			RedisClient redisClient = new RedisClient( "127.0.0.1", 6379, string.Empty );
			if (!redisClient.ConnectServer( ).IsSuccess) { Console.WriteLine( "Redis Can't Test! " ); return; }

			// 开始单元测试
			redisClient.DeleteKey( "UnitTest:1#" );
			redisClient.DeleteKey( "UnitTest:2#" );
			Assert.IsTrue( redisClient.WriteKey( "UnitTest:1#", "123542dasd四个" ).IsSuccess );
			Assert.IsTrue( redisClient.ReadKey( "UnitTest:1#" ).Content == "123542dasd四个" );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).IsSuccess );

			Assert.IsTrue( redisClient.WriteKey( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			}, new string[] {
				 "123542dasd四个",
				 "hi晒sdhi",
				 "asdhnoiw地"
			} ).IsSuccess );
			string[] readStrings = redisClient.ReadKey( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			} ).Content;
			Assert.IsTrue( readStrings[0] == "123542dasd四个" );
			Assert.IsTrue( readStrings[1] == "hi晒sdhi" );
			Assert.IsTrue( readStrings[2] == "asdhnoiw地" );

			Assert.IsTrue( redisClient.DeleteKey( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			} ).Content == 3 );

			Assert.IsTrue( redisClient.WriteKey( "UnitTest:1#", "123542dasd四个" ).IsSuccess );
			Assert.IsTrue( redisClient.ExistsKey( "UnitTest:1#" ).Content == 1 );
			Assert.IsTrue( redisClient.ReadKeyType( "UnitTest:1#" ).Content == "string" );
			Assert.IsTrue( redisClient.RenameKey( "UnitTest:1#", "UnitTest:2#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:2#" ).Content == 1 );


			Assert.IsTrue( redisClient.AppendKey( "UnitTest:1#", "1234567890" ).Content == 10 );
			Assert.IsTrue( redisClient.ReadKeyRange( "UnitTest:1#", 3, 6 ).Content == "4567" );
			Assert.IsTrue( redisClient.WriteKeyRange( "UnitTest:1#", "123", 5 ).Content == 10 );
			Assert.IsTrue( redisClient.ReadKeyLength( "UnitTest:1#" ).Content == 10 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );

			Assert.IsTrue( redisClient.IncrementKey( "UnitTest:1#" ).Content == 1 );
			Assert.IsTrue( redisClient.IncrementKey( "UnitTest:1#", 5 ).Content == 6 );
			Assert.IsTrue( redisClient.DecrementKey( "UnitTest:1#" ).Content == 5 );
			Assert.IsTrue( redisClient.DecrementKey( "UnitTest:1#", 5 ).Content == 0 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );

			Assert.IsTrue( redisClient.ListLeftPush( "UnitTest:1#", "1234" ).Content == 1 );
			Assert.IsTrue( redisClient.ListLeftPush( "UnitTest:1#", "a" ).Content == 2 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:1#", "b" ).Content == 3 );
			Assert.IsTrue( redisClient.ReadListByIndex( "UnitTest:1#", 2 ).Content == "b" );
			Assert.IsTrue( redisClient.ListLeftPush( "UnitTest:1#", new string[] { "m", "n", "l" } ).Content == 6 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:1#", new string[] { "x", "y", "z" } ).Content == 9 );
			Assert.IsTrue( redisClient.ReadListByIndex( "UnitTest:1#", 8 ).Content == "z" );
			Assert.IsTrue( redisClient.ListLeftPop( "UnitTest:1#" ).Content == "l" );
			Assert.IsTrue( redisClient.ListRightPop( "UnitTest:1#" ).Content == "z" );
			Assert.IsTrue( redisClient.GetListLength( "UnitTest:1#" ).Content == 7 );
			Assert.IsTrue( redisClient.ListSet( "UnitTest:1#", 5, "zxc" ).IsSuccess );
			Assert.IsTrue( redisClient.ReadListByIndex( "UnitTest:1#", 5 ).Content == "zxc" );
			Assert.IsTrue( redisClient.ListTrim( "UnitTest:1#", 3, 5 ).IsSuccess );
			Assert.IsTrue( redisClient.GetListLength( "UnitTest:1#" ).Content == 3 );
			Assert.IsTrue( redisClient.ListInsertBefore( "UnitTest:1#", "bbb", "b" ).Content == 4 );
			Assert.IsTrue( redisClient.ReadListByIndex( "UnitTest:1#", 1 ).Content == "bbb" );
			Assert.IsTrue( redisClient.ListInsertAfter( "UnitTest:1#", "ccc", "b" ).Content == 5 );
			Assert.IsTrue( redisClient.ReadListByIndex( "UnitTest:1#", 3 ).Content == "ccc" );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );

			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:1#", "test1", "1" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:1#", "test1", "101" ).Content == 0 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:1#", new string[] { "test2", "test3", "test4" }, new string[] { "102", "103", "104" } ).IsSuccess );
			readStrings = redisClient.ReadHashKeyAll( "UnitTest:1#" ).Content;

			Assert.IsTrue( readStrings[0] == "test1" );
			Assert.IsTrue( readStrings[1] == "101" );
			Assert.IsTrue( readStrings[2] == "test2" );
			Assert.IsTrue( readStrings[3] == "102" );
			Assert.IsTrue( readStrings[4] == "test3" );
			Assert.IsTrue( readStrings[5] == "103" );
			Assert.IsTrue( readStrings[6] == "test4" );
			Assert.IsTrue( readStrings[7] == "104" );

			Assert.IsTrue( redisClient.ReadHashKeyLength( "UnitTest:1#" ).Content == 4 );
			Assert.IsTrue( redisClient.ExistsHashKey( "UnitTest:1#", "test3" ).Content == 1 );
			Assert.IsTrue( redisClient.ExistsHashKey( "UnitTest:1#", "test10" ).Content == 0 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );

			Assert.IsTrue( redisClient.SelectDB( 1 ).IsSuccess );
			Assert.IsTrue( redisClient.WriteKey( "UnitTest:1#", "123542dasd四个" ).IsSuccess );
			Assert.IsTrue( redisClient.SelectDB( 0 ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 0 );
			Assert.IsTrue( redisClient.SelectDB( 1 ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );
			Assert.IsTrue( redisClient.SelectDB( 0 ).IsSuccess );

			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:2#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:3#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:4#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:5#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:6#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:7#" ).IsSuccess );
			Assert.IsTrue( redisClient.WriteKey( "UnitTest:1#", "1111" ).IsSuccess );
			Assert.IsTrue( redisClient.WriteKey( "UnitTest:2#", "2222" ).IsSuccess );
			Assert.IsTrue( redisClient.WriteKey( "UnitTest:3#", "3333" ).IsSuccess );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:4#", "4444" ).Content == 1 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:4#", "5555" ).Content == 2 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:4#", "6666" ).Content == 3 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:5#", "7777" ).Content == 1 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:5#", "8888" ).Content == 2 );
			Assert.IsTrue( redisClient.ListRightPush( "UnitTest:5#", "9999" ).Content == 3 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:6#", "a", "1000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:6#", "b", "2000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:6#", "c", "3000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:6#", "d", "4000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:7#", "a", "5000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:7#", "b", "6000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:7#", "c", "7000" ).Content == 1 );
			Assert.IsTrue( redisClient.WriteHashKey( "UnitTest:7#", "d", "8000" ).Content == 1 );
			OperateResult<UserClass> readClass = redisClient.Read<UserClass>( );
			Assert.IsTrue( readClass.IsSuccess );
			Assert.IsTrue( readClass.Content.AAA == "1111" );
			Assert.IsTrue( readClass.Content.BBB == 2222 );
			Assert.IsTrue( readClass.Content.CCC == 3333d );
			Assert.IsTrue( readClass.Content.ListAAA == "5555" );
			Assert.IsTrue( readClass.Content.ListBBB.Length == 3 );
			Assert.IsTrue( readClass.Content.ListBBB[0] == 7777 );
			Assert.IsTrue( readClass.Content.ListBBB[1] == 8888 );
			Assert.IsTrue( readClass.Content.ListBBB[2] == 9999 );
			Assert.IsTrue( readClass.Content.HashAAA == "1000" );
			Assert.IsTrue( readClass.Content.HashBBB == "2000" );
			Assert.IsTrue( readClass.Content.HashCCC == "3000" );
			Assert.IsTrue( readClass.Content.HashDDD == "7000" );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:2#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:3#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:4#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:5#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:6#" ).Content == 1 );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:7#" ).Content == 1 );
			Assert.IsTrue( redisClient.Write( readClass.Content ).IsSuccess );
			Assert.IsTrue( redisClient.ReadKey( "UnitTest:1#" ).Content == "1111" );
			Assert.IsTrue( redisClient.ReadKey( "UnitTest:2#" ).Content == "2222" );
			Assert.IsTrue( redisClient.ReadKey( "UnitTest:3#" ).Content == "3333" );
			Assert.IsTrue( redisClient.ReadHashKey( "UnitTest:6#", "a" ).Content == "1000" );
			Assert.IsTrue( redisClient.ReadHashKey( "UnitTest:6#", "b" ).Content == "2000" );
			Assert.IsTrue( redisClient.ReadHashKey( "UnitTest:6#", "c" ).Content == "3000" );
			Assert.IsTrue( redisClient.ReadHashKey( "UnitTest:7#", "c" ).Content == "7000" );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:2#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:3#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:4#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:5#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:6#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:7#" ).IsSuccess );

			// Set Test
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", "AAA" ).Content );
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", "BBB" ).Content );
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", "CCC" ).Content );
			Assert.AreEqual( 2, redisClient.SetAdd( "UnitTest:1#", new string[] { "DDD", "EEE" } ).Content );
			Assert.AreEqual( 5, redisClient.SetCard( "UnitTest:1#" ).Content );
			Assert.AreEqual( 1, redisClient.SetIsMember( "UnitTest:1#", "BBB" ).Content );
			Assert.AreEqual( 0, redisClient.SetIsMember( "UnitTest:1#", "asd" ).Content );
			OperateResult<string[]> members = redisClient.SetMembers( "UnitTest:1#" );
			Assert.IsTrue( members.IsSuccess, members.Message );
			Assert.IsTrue( members.Content.Contains( "AAA" ) );
			Assert.IsTrue( members.Content.Contains( "BBB" ) );
			Assert.IsTrue( members.Content.Contains( "CCC" ) );
			Assert.IsTrue( members.Content.Contains( "DDD" ) );
			Assert.IsTrue( members.Content.Contains( "EEE" ) );
			OperateResult<string> remove = redisClient.SetPop( "UnitTest:1#" );
			Assert.IsTrue( remove.IsSuccess );
			Assert.AreEqual( 0, redisClient.SetIsMember( "UnitTest:1#", remove.Content ).Content );
			Assert.AreEqual( 1, redisClient.SetIsMember( "UnitTest:1#", redisClient.SetRandomMember( "UnitTest:1#" ).Content ).Content );
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", remove.Content ).Content );
			Assert.AreEqual( 2, redisClient.SetRemove( "UnitTest:1#", new string[] { "AAA", "BBB" } ).Content );
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", "AAA" ).Content );
			Assert.AreEqual( 1, redisClient.SetAdd( "UnitTest:1#", "BBB" ).Content );


			Assert.AreEqual( 4, redisClient.SetAdd( "UnitTest:2#", new string[] { "AAA", "CCC", "GGG", "HHH" } ).Content );
			OperateResult<string[]> diff = redisClient.SetDiff( "UnitTest:1#", "UnitTest:2#" );
			Assert.IsTrue( diff.IsSuccess, diff.Message );
			Assert.AreEqual( 3, diff.Content.Length );
			Assert.IsTrue( diff.Content.Contains( "BBB" ) );
			Assert.IsTrue( diff.Content.Contains( "DDD" ) );
			Assert.IsTrue( diff.Content.Contains( "EEE" ) );

			OperateResult<string[]> inter = redisClient.SetInter( "UnitTest:1#", "UnitTest:2#" );
			Assert.IsTrue( inter.IsSuccess, inter.Message );
			Assert.AreEqual( 2, inter.Content.Length );
			Assert.IsTrue( inter.Content.Contains( "AAA" ) );
			Assert.IsTrue( inter.Content.Contains( "CCC" ) );

			OperateResult<string[]> union = redisClient.SetUnion( "UnitTest:1#", "UnitTest:2#" );
			Assert.IsTrue( union.IsSuccess, inter.Message );
			Assert.AreEqual( 7, union.Content.Length );
			Assert.IsTrue( union.Content.Contains( "AAA" ) );
			Assert.IsTrue( union.Content.Contains( "BBB" ) );
			Assert.IsTrue( union.Content.Contains( "CCC" ) );
			Assert.IsTrue( union.Content.Contains( "DDD" ) );
			Assert.IsTrue( union.Content.Contains( "EEE" ) );
			Assert.IsTrue( union.Content.Contains( "GGG" ) );
			Assert.IsTrue( union.Content.Contains( "HHH" ) );

			Assert.AreEqual( 1, redisClient.SetMove( "UnitTest:1#", "UnitTest:2#", "BBB" ).Content );
			Assert.AreEqual( 0, redisClient.SetIsMember( "UnitTest:1#", "BBB" ).Content );
			Assert.AreEqual( 1, redisClient.SetIsMember( "UnitTest:2#", "BBB" ).Content );

			OperateResult<string[]> random = redisClient.SetRandomMember( "UnitTest:1#", 2 );
			Assert.IsTrue( random.IsSuccess, random.Message );
			Assert.AreEqual( 1, redisClient.SetIsMember( "UnitTest:1#", random.Content[0] ).Content );
			Assert.AreEqual( 1, redisClient.SetIsMember( "UnitTest:1#", random.Content[1] ).Content );

			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).IsSuccess );
			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:2#" ).IsSuccess );

			// 有序集合
			// C:1  D:3.2  B:5  E:7  A:10
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "A", 10 ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "B", 5 ).Content );
			Assert.AreEqual( 3, redisClient.ZSetAdd( "UnitTest:1#", new string[] { "C", "D", "E" }, new double[] { 1, 3.2d, 7 } ).Content );
			Assert.AreEqual( 5, redisClient.ZSetCard( "UnitTest:1#" ).Content );
			Assert.AreEqual( 3, redisClient.ZSetCount( "UnitTest:1#", 2, 7 ).Content );
			Assert.AreEqual( "12", redisClient.ZSetIncreaseBy( "UnitTest:1#", "A", 2 ).Content );
			Assert.AreEqual( "10", redisClient.ZSetIncreaseBy( "UnitTest:1#", "A", -2 ).Content );
			OperateResult<string[]> zSetRange = redisClient.ZSetRange( "UnitTest:1#", 0, 2 );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "C", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetRange( "UnitTest:1#", 1, 3, true );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 6, zSetRange.Content.Length );
			Assert.AreEqual( "D", zSetRange.Content[0] );
			Assert.AreEqual( 3.2d, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			Assert.AreEqual( 5, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( "E", zSetRange.Content[4] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[5] ) );
			zSetRange = redisClient.ZSetRangeByScore( "UnitTest:1#", "3.2", "7.1" );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "D", zSetRange.Content[0] );
			Assert.AreEqual( "B", zSetRange.Content[1] );
			Assert.AreEqual( "E", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetRangeByScore( "UnitTest:1#", "1", "(7" );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "C", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetRangeByScore( "UnitTest:1#", "(5", "+inf", true );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 4, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "A", zSetRange.Content[2] );
			Assert.AreEqual( 10, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( 0, redisClient.ZSetRank( "UnitTest:1#", "C" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetRank( "UnitTest:1#", "D" ).Content );
			Assert.AreEqual( 2, redisClient.ZSetRank( "UnitTest:1#", "B" ).Content );
			Assert.AreEqual( 3, redisClient.ZSetRank( "UnitTest:1#", "E" ).Content );
			Assert.AreEqual( 4, redisClient.ZSetRank( "UnitTest:1#", "A" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetRemove( "UnitTest:1#", "A" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "A", 10 ).Content );
			Assert.AreEqual( 2, redisClient.ZSetRemoveRangeByRank( "UnitTest:1#", 1, 2 ).Content ); 
			Assert.AreEqual( 3, redisClient.ZSetCard( "UnitTest:1#" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "B", 5 ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "D", 3.2d ).Content );
			Assert.AreEqual( 2, redisClient.ZSetRemoveRangeByScore( "UnitTest:1#", "5", "(10" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "B", 5 ).Content );
			Assert.AreEqual( 1, redisClient.ZSetAdd( "UnitTest:1#", "E", 7 ).Content );


			// A:10  E:7  B:5  D:3.2  C:1
			zSetRange = redisClient.ZSetReverseRange( "UnitTest:1#", 0, 2 );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "A", zSetRange.Content[0] );
			Assert.AreEqual( "E", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetReverseRange( "UnitTest:1#", 1, 3, true );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 6, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			Assert.AreEqual( 5, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( "D", zSetRange.Content[4] );
			Assert.AreEqual( 3.2d, double.Parse( zSetRange.Content[5] ) );
			zSetRange = redisClient.ZSetReverseRangeByScore( "UnitTest:1#", "7.1", "3.2" );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( "B", zSetRange.Content[1] );
			Assert.AreEqual( "D", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetReverseRangeByScore( "UnitTest:1#", "(7", "1" );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "B", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "C", zSetRange.Content[2] );
			zSetRange = redisClient.ZSetReverseRangeByScore( "UnitTest:1#", "+inf", "(5", true );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 4, zSetRange.Content.Length );
			Assert.AreEqual( "A", zSetRange.Content[0] );
			Assert.AreEqual( 10, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "E", zSetRange.Content[2] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( 0, redisClient.ZSetReverseRank( "UnitTest:1#", "A" ).Content );
			Assert.AreEqual( 1, redisClient.ZSetReverseRank( "UnitTest:1#", "E" ).Content );
			Assert.AreEqual( 2, redisClient.ZSetReverseRank( "UnitTest:1#", "B" ).Content );
			Assert.AreEqual( 3, redisClient.ZSetReverseRank( "UnitTest:1#", "D" ).Content );
			Assert.AreEqual( 4, redisClient.ZSetReverseRank( "UnitTest:1#", "C" ).Content );

			Assert.AreEqual( 10, double.Parse( redisClient.ZSetScore( "UnitTest:1#", "A" ).Content ) );
			Assert.AreEqual( 7, double.Parse( redisClient.ZSetScore( "UnitTest:1#", "E" ).Content ) );
			Assert.AreEqual( 5, double.Parse( redisClient.ZSetScore( "UnitTest:1#", "B" ).Content ) );
			Assert.AreEqual( 3.2d, double.Parse( redisClient.ZSetScore( "UnitTest:1#", "D" ).Content ) );
			Assert.AreEqual( 1, double.Parse( redisClient.ZSetScore( "UnitTest:1#", "C" ).Content ) );

			Assert.IsTrue( redisClient.DeleteKey( "UnitTest:1#" ).IsSuccess );

			redisClient.ConnectClose( );
		}

		[TestMethod]
		public async Task RedisClientTest2( )
		{
			RedisClient redisClient = new RedisClient( "127.0.0.1", 6379, string.Empty );
			if (!(await redisClient.ConnectServerAsync( )).IsSuccess) { Console.WriteLine( "Redis Can't Test! " ); return; }

			// 开始单元测试
			await redisClient.DeleteKeyAsync( "UnitTest:1#" );
			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:1#", "123542dasd四个" )).IsSuccess );
			Assert.IsTrue( (await redisClient.ReadKeyAsync( "UnitTest:1#" ) ).Content == "123542dasd四个" );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).IsSuccess );

			Assert.IsTrue( (await redisClient.WriteKeyAsync( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			}, new string[] {
				 "123542dasd四个",
				 "hi晒sdhi",
				 "asdhnoiw地"
			} ) ).IsSuccess );
			string[] readStrings = (await redisClient.ReadKeyAsync( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			} ) ).Content;
			Assert.IsTrue( readStrings[0] == "123542dasd四个" );
			Assert.IsTrue( readStrings[1] == "hi晒sdhi" );
			Assert.IsTrue( readStrings[2] == "asdhnoiw地" );

			Assert.IsTrue( (await redisClient.DeleteKeyAsync( new string[]
			{
				"UnitTest:1#",
				"UnitTest:2#",
				"UnitTest:3#",
			} ) ).Content == 3 );

			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:1#", "123542dasd四个" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.ExistsKeyAsync( "UnitTest:1#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.ReadKeyTypeAsync( "UnitTest:1#" ) ).Content == "string" );
			Assert.IsTrue( (await redisClient.RenameKeyAsync( "UnitTest:1#", "UnitTest:2#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:2#" ) ).Content == 1 );


			Assert.IsTrue( (await redisClient.AppendKeyAsync( "UnitTest:1#", "1234567890" ) ).Content == 10 );
			Assert.IsTrue( (await redisClient.ReadKeyRangeAsync( "UnitTest:1#", 3, 6 ) ).Content == "4567" );
			Assert.IsTrue( (await redisClient.WriteKeyRangeAsync( "UnitTest:1#", "123", 5 ) ).Content == 10 );
			Assert.IsTrue( (await redisClient.ReadKeyLengthAsync( "UnitTest:1#" ) ).Content == 10 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );

			Assert.IsTrue( (await redisClient.IncrementKeyAsync( "UnitTest:1#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.IncrementKeyAsync( "UnitTest:1#", 5 ) ).Content == 6 );
			Assert.IsTrue( (await redisClient.DecrementKeyAsync( "UnitTest:1#" ) ).Content == 5 );
			Assert.IsTrue( (await redisClient.DecrementKeyAsync( "UnitTest:1#", 5 ) ).Content == 0 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );

			Assert.IsTrue( (await redisClient.ListLeftPushAsync( "UnitTest:1#", "1234" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.ListLeftPushAsync( "UnitTest:1#", "a" ) ).Content == 2 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:1#", "b" ) ).Content == 3 );
			Assert.IsTrue( (await redisClient.ReadListByIndexAsync( "UnitTest:1#", 2 ) ).Content == "b" );
			Assert.IsTrue( (await redisClient.ListLeftPushAsync( "UnitTest:1#", new string[] { "m", "n", "l" } ) ).Content == 6 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:1#", new string[] { "x", "y", "z" } ) ).Content == 9 );
			Assert.IsTrue( (await redisClient.ReadListByIndexAsync( "UnitTest:1#", 8 ) ).Content == "z" );
			Assert.IsTrue( (await redisClient.ListLeftPopAsync( "UnitTest:1#" ) ).Content == "l" );
			Assert.IsTrue( (await redisClient.ListRightPopAsync( "UnitTest:1#" ) ).Content == "z" );
			Assert.IsTrue( (await redisClient.GetListLengthAsync( "UnitTest:1#" ) ).Content == 7 );
			Assert.IsTrue( (await redisClient.ListSetAsync( "UnitTest:1#", 5, "zxc" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.ReadListByIndexAsync( "UnitTest:1#", 5 ) ).Content == "zxc" );
			Assert.IsTrue( (await redisClient.ListTrimAsync( "UnitTest:1#", 3, 5 ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.GetListLengthAsync( "UnitTest:1#" ) ).Content == 3 );
			Assert.IsTrue( (await redisClient.ListInsertBeforeAsync( "UnitTest:1#", "bbb", "b" ) ).Content == 4 );
			Assert.IsTrue( (await redisClient.ReadListByIndexAsync( "UnitTest:1#", 1 ) ).Content == "bbb" );
			Assert.IsTrue( (await redisClient.ListInsertAfterAsync( "UnitTest:1#", "ccc", "b" ) ).Content == 5 );
			Assert.IsTrue( (await redisClient.ReadListByIndexAsync( "UnitTest:1#", 3 ) ).Content == "ccc" );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );

			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:1#", "test1", "1" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:1#", "test1", "101" ) ).Content == 0 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:1#", new string[] { "test2", "test3", "test4" }, new string[] { "102", "103", "104" } ) ).IsSuccess );
			readStrings = (await redisClient.ReadHashKeyAllAsync( "UnitTest:1#" ) ).Content;

			Assert.IsTrue( readStrings[0] == "test1" );
			Assert.IsTrue( readStrings[1] == "101" );
			Assert.IsTrue( readStrings[2] == "test2" );
			Assert.IsTrue( readStrings[3] == "102" );
			Assert.IsTrue( readStrings[4] == "test3" );
			Assert.IsTrue( readStrings[5] == "103" );
			Assert.IsTrue( readStrings[6] == "test4" );
			Assert.IsTrue( readStrings[7] == "104" );

			Assert.IsTrue( (await redisClient.ReadHashKeyLengthAsync( "UnitTest:1#" ) ).Content == 4 );
			Assert.IsTrue( (await redisClient.ExistsHashKeyAsync( "UnitTest:1#", "test3" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.ExistsHashKeyAsync( "UnitTest:1#", "test10" ) ).Content == 0 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );

			Assert.IsTrue( (await redisClient.SelectDBAsync( 1 ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:1#", "123542dasd四个" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.SelectDBAsync( 0 ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 0 );
			Assert.IsTrue( (await redisClient.SelectDBAsync( 1 ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );

			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:2#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:3#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:4#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:5#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:6#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:7#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:1#", "1111" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:2#", "2222" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.WriteKeyAsync( "UnitTest:3#", "3333" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:4#", "4444" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:4#", "5555" ) ).Content == 2 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:4#", "6666" ) ).Content == 3 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:5#", "7777" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:5#", "8888" ) ).Content == 2 );
			Assert.IsTrue( (await redisClient.ListRightPushAsync( "UnitTest:5#", "9999" ) ).Content == 3 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:6#", "a", "1000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:6#", "b", "2000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:6#", "c", "3000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:6#", "d", "4000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:7#", "a", "5000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:7#", "b", "6000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:7#", "c", "7000" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteHashKeyAsync( "UnitTest:7#", "d", "8000" ) ).Content == 1 );
			OperateResult<UserClass> readClass = await redisClient.ReadAsync<UserClass>( );
			Assert.IsTrue( readClass.IsSuccess );
			Assert.IsTrue( readClass.Content.AAA == "1111" );
			Assert.IsTrue( readClass.Content.BBB == 2222 );
			Assert.IsTrue( readClass.Content.CCC == 3333d );
			Assert.IsTrue( readClass.Content.ListAAA == "5555" );
			Assert.IsTrue( readClass.Content.ListBBB.Length == 3 );
			Assert.IsTrue( readClass.Content.ListBBB[0] == 7777 );
			Assert.IsTrue( readClass.Content.ListBBB[1] == 8888 );
			Assert.IsTrue( readClass.Content.ListBBB[2] == 9999 );
			Assert.IsTrue( readClass.Content.HashAAA == "1000" );
			Assert.IsTrue( readClass.Content.HashBBB == "2000" );
			Assert.IsTrue( readClass.Content.HashCCC == "3000" );
			Assert.IsTrue( readClass.Content.HashDDD == "7000" );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:2#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:3#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:4#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:5#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:6#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:7#" ) ).Content == 1 );
			Assert.IsTrue( (await redisClient.WriteAsync( readClass.Content ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.ReadKeyAsync( "UnitTest:1#" ) ).Content == "1111" );
			Assert.IsTrue( (await redisClient.ReadKeyAsync( "UnitTest:2#" ) ).Content == "2222" );
			Assert.IsTrue( (await redisClient.ReadKeyAsync( "UnitTest:3#" ) ).Content == "3333" );
			Assert.IsTrue( (await redisClient.ReadHashKeyAsync( "UnitTest:6#", "a" ) ).Content == "1000" );
			Assert.IsTrue( (await redisClient.ReadHashKeyAsync( "UnitTest:6#", "b" ) ).Content == "2000" );
			Assert.IsTrue( (await redisClient.ReadHashKeyAsync( "UnitTest:6#", "c" ) ).Content == "3000" );
			Assert.IsTrue( (await redisClient.ReadHashKeyAsync( "UnitTest:7#", "c" ) ).Content == "7000" );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:2#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:3#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:4#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:5#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:6#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:7#" ) ).IsSuccess );


			// Set Test
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", "AAA" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", "BBB" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", "CCC" ) ).Content );
			Assert.AreEqual( 2, (await redisClient.SetAddAsync( "UnitTest:1#", new string[] { "DDD", "EEE" } ) ).Content );
			Assert.AreEqual( 5, (await redisClient.SetCardAsync( "UnitTest:1#" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetIsMemberAsync( "UnitTest:1#", "BBB" ) ).Content );
			Assert.AreEqual( 0, (await redisClient.SetIsMemberAsync( "UnitTest:1#", "asd" ) ).Content );
			OperateResult<string[]> members = (await redisClient.SetMembersAsync( "UnitTest:1#" ) );
			Assert.IsTrue( members.IsSuccess, members.Message );
			Assert.IsTrue( members.Content.Contains( "AAA" ) );
			Assert.IsTrue( members.Content.Contains( "BBB" ) );
			Assert.IsTrue( members.Content.Contains( "CCC" ) );
			Assert.IsTrue( members.Content.Contains( "DDD" ) );
			Assert.IsTrue( members.Content.Contains( "EEE" ) );
			OperateResult<string> remove = (await redisClient.SetPopAsync( "UnitTest:1#" ) );
			Assert.IsTrue( remove.IsSuccess );
			Assert.AreEqual( 0, (await redisClient.SetIsMemberAsync( "UnitTest:1#", remove.Content ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetIsMemberAsync( "UnitTest:1#", (await redisClient.SetRandomMemberAsync( "UnitTest:1#" ) ).Content ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", remove.Content ) ).Content );
			Assert.AreEqual( 2, (await redisClient.SetRemoveAsync( "UnitTest:1#", new string[] { "AAA", "BBB" } ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", "AAA" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetAddAsync( "UnitTest:1#", "BBB" ) ).Content );


			Assert.AreEqual( 4, (await redisClient.SetAddAsync( "UnitTest:2#", new string[] { "AAA", "CCC", "GGG", "HHH" } ) ).Content );
			OperateResult<string[]> diff = (await redisClient.SetDiffAsync( "UnitTest:1#", "UnitTest:2#" ) );
			Assert.IsTrue( diff.IsSuccess, diff.Message );
			Assert.AreEqual( 3, diff.Content.Length );
			Assert.IsTrue( diff.Content.Contains( "BBB" ) );
			Assert.IsTrue( diff.Content.Contains( "DDD" ) );
			Assert.IsTrue( diff.Content.Contains( "EEE" ) );

			OperateResult<string[]> inter = (await redisClient.SetInterAsync( "UnitTest:1#", "UnitTest:2#" ) );
			Assert.IsTrue( inter.IsSuccess, inter.Message );
			Assert.AreEqual( 2, inter.Content.Length );
			Assert.IsTrue( inter.Content.Contains( "AAA" ) );
			Assert.IsTrue( inter.Content.Contains( "CCC" ) );

			OperateResult<string[]> union = (await redisClient.SetUnionAsync( "UnitTest:1#", "UnitTest:2#" ) );
			Assert.IsTrue( union.IsSuccess, inter.Message );
			Assert.AreEqual( 7, union.Content.Length );
			Assert.IsTrue( union.Content.Contains( "AAA" ) );
			Assert.IsTrue( union.Content.Contains( "BBB" ) );
			Assert.IsTrue( union.Content.Contains( "CCC" ) );
			Assert.IsTrue( union.Content.Contains( "DDD" ) );
			Assert.IsTrue( union.Content.Contains( "EEE" ) );
			Assert.IsTrue( union.Content.Contains( "GGG" ) );
			Assert.IsTrue( union.Content.Contains( "HHH" ) );

			Assert.AreEqual( 1, (await redisClient.SetMoveAsync( "UnitTest:1#", "UnitTest:2#", "BBB" ) ).Content );
			Assert.AreEqual( 0, (await redisClient.SetIsMemberAsync( "UnitTest:1#", "BBB" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetIsMemberAsync( "UnitTest:2#", "BBB" ) ).Content );

			OperateResult<string[]> random = (await redisClient.SetRandomMemberAsync( "UnitTest:1#", 2 ) );
			Assert.IsTrue( random.IsSuccess, random.Message );
			Assert.AreEqual( 1, (await redisClient.SetIsMemberAsync( "UnitTest:1#", random.Content[0] ) ).Content );
			Assert.AreEqual( 1, (await redisClient.SetIsMemberAsync( "UnitTest:1#", random.Content[1] ) ).Content );

			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).IsSuccess );
			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:2#" ) ).IsSuccess );

			// 有序集合
			// C:1  D:3.2  B:5  E:7  A:10
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "A", 10 ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "B", 5 ) ).Content );
			Assert.AreEqual( 3, (await redisClient.ZSetAddAsync( "UnitTest:1#", new string[] { "C", "D", "E" }, new double[] { 1, 3.2d, 7 } ) ).Content );
			Assert.AreEqual( 5, (await redisClient.ZSetCardAsync( "UnitTest:1#" ) ).Content );
			Assert.AreEqual( 3, (await redisClient.ZSetCountAsync( "UnitTest:1#", 2, 7 ) ).Content );
			Assert.AreEqual( "12", (await redisClient.ZSetIncreaseByAsync( "UnitTest:1#", "A", 2 ) ).Content );
			Assert.AreEqual( "10", (await redisClient.ZSetIncreaseByAsync( "UnitTest:1#", "A", -2 ) ).Content );
			OperateResult<string[]> zSetRange = (await redisClient.ZSetRangeAsync( "UnitTest:1#", 0, 2 ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "C", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetRangeAsync( "UnitTest:1#", 1, 3, true ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 6, zSetRange.Content.Length );
			Assert.AreEqual( "D", zSetRange.Content[0] );
			Assert.AreEqual( 3.2d, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			Assert.AreEqual( 5, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( "E", zSetRange.Content[4] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[5] ) );
			zSetRange = (await redisClient.ZSetRangeByScoreAsync( "UnitTest:1#", "3.2", "7.1" ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "D", zSetRange.Content[0] );
			Assert.AreEqual( "B", zSetRange.Content[1] );
			Assert.AreEqual( "E", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetRangeByScoreAsync( "UnitTest:1#", "1", "(7" ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "C", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetRangeByScoreAsync( "UnitTest:1#", "(5", "+inf", true ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 4, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "A", zSetRange.Content[2] );
			Assert.AreEqual( 10, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( 0, (await redisClient.ZSetRankAsync( "UnitTest:1#", "C" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetRankAsync( "UnitTest:1#", "D" ) ).Content );
			Assert.AreEqual( 2, (await redisClient.ZSetRankAsync( "UnitTest:1#", "B" ) ).Content );
			Assert.AreEqual( 3, (await redisClient.ZSetRankAsync( "UnitTest:1#", "E" ) ).Content );
			Assert.AreEqual( 4, (await redisClient.ZSetRankAsync( "UnitTest:1#", "A" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetRemoveAsync( "UnitTest:1#", "A" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "A", 10 ) ).Content );
			Assert.AreEqual( 2, (await redisClient.ZSetRemoveRangeByRankAsync( "UnitTest:1#", 1, 2 ) ).Content );
			Assert.AreEqual( 3, (await redisClient.ZSetCardAsync( "UnitTest:1#" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "B", 5 ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "D", 3.2d ) ).Content );
			Assert.AreEqual( 2, (await redisClient.ZSetRemoveRangeByScoreAsync( "UnitTest:1#", "5", "(10" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "B", 5 ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetAddAsync( "UnitTest:1#", "E", 7 ) ).Content );


			// A:10  E:7  B:5  D:3.2  C:1
			zSetRange = (await redisClient.ZSetReverseRangeAsync( "UnitTest:1#", 0, 2 ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "A", zSetRange.Content[0] );
			Assert.AreEqual( "E", zSetRange.Content[1] );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetReverseRangeAsync( "UnitTest:1#", 1, 3, true ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 6, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "B", zSetRange.Content[2] );
			Assert.AreEqual( 5, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( "D", zSetRange.Content[4] );
			Assert.AreEqual( 3.2d, double.Parse( zSetRange.Content[5] ) );
			zSetRange = (await redisClient.ZSetReverseRangeByScoreAsync( "UnitTest:1#", "7.1", "3.2" ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "E", zSetRange.Content[0] );
			Assert.AreEqual( "B", zSetRange.Content[1] );
			Assert.AreEqual( "D", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetReverseRangeByScoreAsync( "UnitTest:1#", "(7", "1" ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 3, zSetRange.Content.Length );
			Assert.AreEqual( "B", zSetRange.Content[0] );
			Assert.AreEqual( "D", zSetRange.Content[1] );
			Assert.AreEqual( "C", zSetRange.Content[2] );
			zSetRange = (await redisClient.ZSetReverseRangeByScoreAsync( "UnitTest:1#", "+inf", "(5", true ) );
			Assert.IsTrue( zSetRange.IsSuccess, zSetRange.Message );
			Assert.AreEqual( 4, zSetRange.Content.Length );
			Assert.AreEqual( "A", zSetRange.Content[0] );
			Assert.AreEqual( 10, double.Parse( zSetRange.Content[1] ) );
			Assert.AreEqual( "E", zSetRange.Content[2] );
			Assert.AreEqual( 7, double.Parse( zSetRange.Content[3] ) );
			Assert.AreEqual( 0, (await redisClient.ZSetReverseRankAsync( "UnitTest:1#", "A" ) ).Content );
			Assert.AreEqual( 1, (await redisClient.ZSetReverseRankAsync( "UnitTest:1#", "E" ) ).Content );
			Assert.AreEqual( 2, (await redisClient.ZSetReverseRankAsync( "UnitTest:1#", "B" ) ).Content );
			Assert.AreEqual( 3, (await redisClient.ZSetReverseRankAsync( "UnitTest:1#", "D" ) ).Content );
			Assert.AreEqual( 4, (await redisClient.ZSetReverseRankAsync( "UnitTest:1#", "C" ) ).Content );

			Assert.AreEqual( 10, double.Parse( (await redisClient.ZSetScoreAsync( "UnitTest:1#", "A" ) ).Content ) );
			Assert.AreEqual( 7, double.Parse( (await redisClient.ZSetScoreAsync( "UnitTest:1#", "E" ) ).Content ) );
			Assert.AreEqual( 5, double.Parse( (await redisClient.ZSetScoreAsync( "UnitTest:1#", "B" ) ).Content ) );
			Assert.AreEqual( 3.2d, double.Parse( (await redisClient.ZSetScoreAsync( "UnitTest:1#", "D" ) ).Content ) );
			Assert.AreEqual( 1, double.Parse( (await redisClient.ZSetScoreAsync( "UnitTest:1#", "C" ) ).Content ) );

			Assert.IsTrue( (await redisClient.DeleteKeyAsync( "UnitTest:1#" ) ).IsSuccess );

			await redisClient.ConnectCloseAsync( );
		}
	}

	public class UserClass
	{
		[HslCommunication.Reflection.HslRedisKey( "UnitTest:1#" )]
		public string AAA { get; set; }

		[HslCommunication.Reflection.HslRedisKey( "UnitTest:2#" )]
		public int BBB { get; set; }

		[HslCommunication.Reflection.HslRedisKey( "UnitTest:3#" )]
		public double CCC { get; set; }

		[HslCommunication.Reflection.HslRedisListItem( "UnitTest:4#", 1 )]
		public string ListAAA { get; set; }

		[HslCommunication.Reflection.HslRedisList( "UnitTest:5#", 0 )]
		public int[] ListBBB { get; set; }

		[HslCommunication.Reflection.HslRedisHashField( "UnitTest:6#", "a" )]
		public string HashAAA { get; set; }

		[HslCommunication.Reflection.HslRedisHashField( "UnitTest:6#", "b" )]
		public string HashBBB { get; set; }

		[HslCommunication.Reflection.HslRedisHashField( "UnitTest:6#", "c" )]
		public string HashCCC { get; set; }

		[HslCommunication.Reflection.HslRedisHashField( "UnitTest:7#", "c" )]
		public string HashDDD { get; set; }
	}
}
