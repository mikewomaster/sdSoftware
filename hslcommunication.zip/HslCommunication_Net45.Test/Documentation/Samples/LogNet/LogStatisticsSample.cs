﻿using HslCommunication.LogNet;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HslCommunication_Net45.Test.Documentation.Samples.LogNet
{
	public class LogStatisticsSample
	{
		#region Sample1

		/// <summary>
		/// 定义一个缓存60天统计的信息内容，假设我们要统计最近60天内一个方法的调用次数<br />
		/// Define a cache for 60 days of statistical information content, suppose we want to count the number of calls to a method in the last 60 days
		/// </summary>
		public LogStatistics logStatistics = new LogStatistics( GenerateMode.ByEveryDay, 60 );

		/// <summary>
		/// 假设这个方法就是我们需要统计的方法，我们统计最近的连续30天的使用次数情况<br />
		/// Assuming that this method is the method we need to count, we count the number of uses for the most recent 30 consecutive days
		/// </summary>
		public void Example( )
		{
			logStatistics.StatisticsAdd( );

			// 下面执行这个方法真正执行的内容

		}

		// 然后你就可以在其他的任何地方，其他线程里获取到当前的最新的long数组
		public void AAA( )
		{
			long[] data = logStatistics.GetStatisticsSnapshot( );  // 可以用于显示，然后监视系统的基本情况
		}

		#endregion

		public void VVV( )
		{
			#region Sample2

			// 如果需要对数据进行保存
			logStatistics.SaveToFile( "D:\\123.txt" );

			// 当你系统启动的是，需要加载旧的数据信息
			logStatistics.LoadFromFile( "D:\\123.txt" );

			#endregion
		}
	}
}
