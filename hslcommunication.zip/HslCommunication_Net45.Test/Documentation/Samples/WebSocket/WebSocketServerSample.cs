﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.WebSocket;

namespace HslCommunication_Net45.Test.Documentation.Samples.WebSocket
{
	class WebSocketServerSample1
	{
		#region Sample1

		// 定义一个对象
		// Define an object
		public WebSocketServer webSocketServer;

		public void Start( )
		{
			try
			{
				webSocketServer = new WebSocketServer( );
				webSocketServer.ServerStart( 1883 );
			}
			catch(Exception ex)
			{
				Console.WriteLine( ex.Message );
			}
		}

		#endregion
	}

	class WebSocketServerSample2
	{
		#region Sample2

		public WebSocketServer webSocketServer;

		public void Start( )
		{
			try
			{
				webSocketServer = new WebSocketServer( );
				webSocketServer.OnClientApplicationMessageReceive += WebSocketServer_OnClientApplicationMessageReceive;
				// 如果要控制心跳时间，需要在ServerStart方法调用之前
				webSocketServer.KeepAliveSendInterval = TimeSpan.FromSeconds( 20 ); // 默认间隔30秒发送客户端一次心跳
				webSocketServer.KeepAlivePeriod = TimeSpan.FromSeconds( 100 );      // 如果100秒之内都没有任何的心跳回复，就认为掉线了
				webSocketServer.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( ex.Message );
			}
		}

		private void WebSocketServer_OnClientApplicationMessageReceive( WebSocketSession session, WebSocketMessage message )
		{
			// 当接收到客户端的数据的时候触发，session参数就是会话信息，你可以选择打印数据，或是回发数据
			// Triggered when data is received from the client. The session parameter is the session information. You can choose to print the data or send it back.
			Console.WriteLine( message.ToString( ) );
			webSocketServer.SendClientPayload( session, "I hava received your data, thank you" );
		}

		#endregion

		#region Sample3

		// 以下的信息会发布到所有的连接的客户端，包括网页端或是桌面程序
		// The following information will be published to all connected clients, including web or desktop
		private void Button1_Click(object sender, EventArgs e )
		{
			webSocketServer.PublishAllClientPayload( "This is sample data, thank you for use hslcommunication" );
		}

		#endregion

	}
	class WebSocketServerSample3
	{
		#region Sample4

		public WebSocketServer webSocketServer;

		public void Start( )
		{
			try
			{
				webSocketServer = new WebSocketServer( );
				webSocketServer.OnClientApplicationMessageReceive += WebSocketServer_OnClientApplicationMessageReceive;
				webSocketServer.OnClientConnected += ( WebSocketSession session ) =>
				{
					Console.WriteLine( session.Remote.ToString( ) + " Online" );
				};
				webSocketServer.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( ex.Message );
			}
		}


		private void WebSocketServer_OnClientApplicationMessageReceive( WebSocketSession session, WebSocketMessage message )
		{
			// 当接收到客户端的数据的时候触发，session参数就是会话信息，你可以选择打印数据，或是回发数据
			// Triggered when data is received from the client. The session parameter is the session information. You can choose to print the data or send it back.
			Console.WriteLine( message.ToString( ) );
			webSocketServer.SendClientPayload( session, "I hava received your data, thank you" );
		}

		#endregion


	}

	class WebSocketServerSample4
	{
		#region Sample5

		public WebSocketServer webSocketServer;

		public void Start( )
		{
			try
			{
				webSocketServer = new WebSocketServer( );
				webSocketServer.OnClientApplicationMessageReceive += WebSocketServer_OnClientApplicationMessageReceive;
				webSocketServer.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( ex.Message );
			}
		}

		private void WebSocketServer_OnClientApplicationMessageReceive( WebSocketSession session, WebSocketMessage message )
		{
			// 客户端发过来的数据就是订阅的主题，服务器在收到数据后加入到订阅的数据信息里去，假如订阅的数据已经存在，会自动推送数据
			// The data sent by the client is the subject of the subscription. After receiving the data, the server adds it to the subscribed data information. 
			// If the subscribed data already exists, it will automatically push the data.
			Console.WriteLine( message.ToString( ) );
			string topic = Encoding.UTF8.GetString( message.Payload );
			if(!string.IsNullOrEmpty( topic ))
			{
				webSocketServer.AddSessionTopic( session, topic );
			}
		}

		#endregion

		#region Sample6

		// 以下的信息会发布到所有的连接的客户端，包括网页端或是桌面程序
		// The following information will be published to all connected clients, including web or desktop
		private void Button1_Click( object sender, EventArgs e )
		{
			webSocketServer.PublishClientPayload( "A", "This is sample data, thank you for use hslcommunication" );
		}

		#endregion

	}
}
