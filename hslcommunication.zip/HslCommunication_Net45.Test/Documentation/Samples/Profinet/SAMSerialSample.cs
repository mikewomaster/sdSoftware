﻿using HslCommunication;
using HslCommunication.Profinet.IDCard;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace HslCommunication_Net45.Test.Documentation.Samples.Profinet
{
	class SAMSerialSample1
	{
		#region Sample1

		private SAMSerial sAMSerial = new SAMSerial( );

		public void Open( )
		{
			// 下面是初始化连接的代码，在读取身份证信息之前需要被调用一次
			// The following is the code to initialize the connection. It needs to be called once before reading the ID information.
			try
			{
				sAMSerial.SerialPortInni( sp =>
				{
					sp.PortName = "COM1";
					sp.BaudRate = 115200;
					sp.DataBits = 0;
					sp.StopBits = System.IO.Ports.StopBits.None;
					sp.Parity = System.IO.Ports.Parity.None;
				} );

				sAMSerial.Open( );

			}
			catch (Exception ex)
			{
				Console.WriteLine( ex.Message );
			}
		}

		#endregion

		#region Sample2

		// 通常是放到后台进行循环扫描，此处举例开了一个线程的操作，实际上你在开发的时候需要注意GC回收垃圾的事
		// Usually it is placed in the background for circular scanning. Here is an example of a thread operation. In fact, you need to pay attention to GC garbage collection when you develop
		public void StartRead( )
		{
			new Thread( new ThreadStart( ThreadBackgroundReadCard ) ) { IsBackground = true }.Start( );
		}

		private void ThreadBackgroundReadCard( )
		{
			while (true)
			{
				Thread.Sleep( 100 );
				// 首先进行寻卡，成功才进行下一步
				// Find the card first, then proceed to the next step
				OperateResult search = sAMSerial.SearchCard( );
				{
					if (!search.IsSuccess)
					{
						continue;
					}
				}

				Thread.Sleep( 100 );
				// 寻卡成功后开始选卡，选卡成功才进行下一步
				// Select card after successful card search, then proceed to the next step after successful card selection
				if (sAMSerial.SelectCard( ).IsSuccess)
				{
					OperateResult<IdentityCard> read = sAMSerial.ReadCard( );
					if (read.IsSuccess)
					{
						// read.Content，详细的身份证信息，需要查看 IdentityCard 类型的定义，包含身份的名字，
						Console.WriteLine( read.Content.ToString( ) );
					}
					else
					{
						Console.WriteLine( $"读卡失败：{read.Message}" );
					}
				}
			}
		}

		#endregion
	}

	class SAMSerialSample2
	{
		#region Sample3

		private SAMTcpNet sAMTcpNet = null;

		public void Open( )
		{
			// 下面是初始化连接的代码，在读取身份证信息之前需要被调用一次
			// The following is the code to initialize the connection. It needs to be called once before reading the ID information.
			sAMTcpNet = new SAMTcpNet( "192.168.0.100", 1000 );
			OperateResult connect = sAMTcpNet.ConnectServer( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "success" );
			}
			else
			{
				Console.WriteLine( "failed" );
			}
		}

		#endregion

		#region Sample4

		// 通常是放到后台进行循环扫描，此处举例开了一个线程的操作，实际上你在开发的时候需要注意GC回收垃圾的事
		// Usually it is placed in the background for circular scanning. Here is an example of a thread operation. In fact, you need to pay attention to GC garbage collection when you develop
		public void StartRead( )
		{
			new Thread( new ThreadStart( ThreadBackgroundReadCard ) ) { IsBackground = true }.Start( );
		}

		private void ThreadBackgroundReadCard( )
		{
			while (true)
			{
				Thread.Sleep( 100 );
				// 首先进行寻卡，成功才进行下一步
				// Find the card first, then proceed to the next step
				OperateResult search = sAMTcpNet.SearchCard( );
				{
					if (!search.IsSuccess)
					{
						continue;
					}
				}

				Thread.Sleep( 100 );
				// 寻卡成功后开始选卡，选卡成功才进行下一步
				// Select card after successful card search, then proceed to the next step after successful card selection
				if (sAMTcpNet.SelectCard( ).IsSuccess)
				{
					OperateResult<IdentityCard> read = sAMTcpNet.ReadCard( );
					if (read.IsSuccess)
					{
						// read.Content，详细的身份证信息，需要查看 IdentityCard 类型的定义，包含身份的名字，
						Console.WriteLine( read.Content.ToString( ) );
					}
					else
					{
						Console.WriteLine( $"读卡失败：{read.Message}" );
					}
				}
			}
		}

		#endregion
	}

	class SAMSerialSample3
	{
		#region Sample5

		private SAMTcpNet sAMTcpNet = null;

		public async void Open( )
		{
			// 下面是初始化连接的代码，在读取身份证信息之前需要被调用一次
			// The following is the code to initialize the connection. It needs to be called once before reading the ID information.
			sAMTcpNet = new SAMTcpNet( "192.168.0.100", 1000 );
			OperateResult connect = await sAMTcpNet.ConnectServerAsync( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "success" );
			}
			else
			{
				Console.WriteLine( "failed" );
			}
		}

		#endregion

		#region Sample6

		// 通常是放到后台进行循环扫描，此处举例开了一个线程的操作，实际上你在开发的时候需要注意GC回收垃圾的事
		// Usually it is placed in the background for circular scanning. Here is an example of a thread operation. In fact, you need to pay attention to GC garbage collection when you develop
		public void StartRead( )
		{
			new Thread( new ThreadStart( ThreadBackgroundReadCard ) ) { IsBackground = true }.Start( );
		}

		private async void ThreadBackgroundReadCard( )
		{
			while (true)
			{
				Thread.Sleep( 100 );
				// 首先进行寻卡，成功才进行下一步
				// Find the card first, then proceed to the next step
				OperateResult search = await sAMTcpNet.SearchCardAsync( );
				if (!search.IsSuccess)
				{
					continue;
				}

				Thread.Sleep( 100 );
				// 寻卡成功后开始选卡，选卡成功才进行下一步
				// Select card after successful card search, then proceed to the next step after successful card selection
				if ((await sAMTcpNet.SelectCardAsync( )).IsSuccess)
				{
					OperateResult<IdentityCard> read = await sAMTcpNet.ReadCardAsync( );
					if (read.IsSuccess)
					{
						// read.Content，详细的身份证信息，需要查看 IdentityCard 类型的定义，包含身份的名字，
						Console.WriteLine( read.Content.ToString( ) );
					}
					else
					{
						Console.WriteLine( $"读卡失败：{read.Message}" );
					}
				}
			}
		}

		#endregion
	}
}
