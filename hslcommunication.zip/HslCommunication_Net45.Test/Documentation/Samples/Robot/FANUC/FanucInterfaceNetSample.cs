﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Robot.FANUC;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.Robot.FANUC
{
	public class FanucInterfaceNetSample
	{
		#region Sample1

		// 实例化
		private FanucInterfaceNet fanuc = new FanucInterfaceNet( "127.0.0.1" );

		public void Sample1( )
		{
			// 设置长连接
			fanuc.SetPersistentConnection( );

			// 简单的读取数据
			OperateResult<FanucData> read = fanuc.ReadFanucData( );
			if (read.IsSuccess)
			{
				// 所有的数据就都在read.Content里了，可以获取到目前支持的几乎所有的数据。
			}

			// 剩下的IO数据呢？地址都是从1开始的
			OperateResult<bool[]> sdo = fanuc.ReadSDO( 1, 100 );
			if (sdo.IsSuccess)
			{
				// 这时就获取到了100长度的bool数组
			}

			// 其他的SDI,SDR,SO,UI等等，都是类似，详细参考demo
		}

		#endregion

		public void Sample2( )
		{
			#region Sample2

			// 跳过实例化的操作，现在来看看一种特殊的读取
			// 因为FanucData的数据对象很多，假设我不需要所有的属性，我只想读单个的属性，比如CurrentPose属性
			OperateResult<string> readCurrentPose = fanuc.ReadString( "CurrentPose" );
			if (readCurrentPose.IsSuccess)
			{
				// content是json的对象信息
//  "Xyzwpr": [
//    360.0015,
//    -0.00723832054,
//    279.9837,
//    177.4754,
//    -89.99734,
//    2.52343941,
//    0.0,
//    0.0,
//    0.0
//  ],
//  "Config": [
//    "N",
//    "R",
//    "U",
//    "T",
//    "0",
//    "0",
//    "0"
//  ],
//  "Joint": [
//    -0.0011520097,
//    0.000135969414,
//    -0.00257415767,
//    -1.54076552E-05,
//    -8.724436E-05,
//    0.000132751462,
//    0.0,
//    0.0,
//    0.0
//  ],
//  "UF": 0,
//  "UT": 1,
//  "ValidC": 1,
//  "ValidJ": 1
//}
			}

			// 如果我读取属性很频繁怎么办？是不是会频繁和机器人交互？（一条完整的fanucdata大小在12k左右）
			// 下面的属性就开始起作用了，我们看下面的代码
			fanuc.FanucDataRetainTime = 100; // 单位毫秒
			for (int i = 0; i < 100; i++)
			{
				OperateResult<string> read1 = fanuc.ReadString( "CurrentPose" );  // 刷新了数据
				OperateResult<string> read2 = fanuc.ReadString( "AlarmCurrent" ); // 读缓存
				OperateResult<string> read3 = fanuc.ReadString( "FAST_CLOCK" );   // 读缓存
				OperateResult<string> read4 = fanuc.ReadString( "DUTY_TEMP" );    // 读缓存
				OperateResult<string> read5 = fanuc.ReadString( "MNUTOOL1_1" );   // 读缓存
				// ... 等等，只要在read1读取的100ms内读取属性，就是读取缓存的。过了100ms后继续读取呢？又会自动刷新缓存的，如是往复循环

				System.Threading.Thread.Sleep( 200 );
			}

			#endregion
		}

		public void Sample3( )
		{
			#region Sample3

			// 跳过实例化的操作，现在来看看一种更加牛逼的读取
			// 我现在就想读一个数据，CurrentPose的xyzwpr的第一个数，就是上面所示的360.0015，我也不想读缓存，怎么办？
			// 这时候就需要最底层的读写操作了，我们就针对寄存器地址进行读写操作了，详细看下面的示例
			OperateResult<float> read = fanuc.ReadFloat( "D751" );
			if (read.IsSuccess)
			{
				float x = read.Content; // 就是360.0015
			}

			// 如果xyzwpr都读取出来
			OperateResult<float[]> xyzwpr = fanuc.ReadFloat( "D751", 9 );
			if (xyzwpr.IsSuccess)
			{
				// xyzwpr.Content 就是 "Xyzwpr":
				//    360.0015,
				//    -0.00723832054,
				//    279.9837,
				//    177.4754,
				//    -89.99734,
				//    2.52343941,
				//    0.0,
				//    0.0,
				//    0.0
			}

			// 如果是joint呢？
			OperateResult<float[]> joint = fanuc.ReadFloat( "D777", 9 );
			if (joint.IsSuccess)
			{
				// joint.Content值如下[-0.00115201,0.0001359694,-0.002574158,-1.540766E-05,-8.724436E-05,0.0001327515,0,0,0]
			}

			// 那么问题来了，我们怎么知道偏移地址呢？
			//"Index Length    1 500 ALARM*5",                                // 1.
			//"Index Length  501 100 ALM[1] 1",                               // 2.
			//"Index Length  601 100 ALM[P1] 1",                              // 3.
			//"Index Length  701 50 POS[15] 0.0",                             // 4.
			//"Index Length  751 50 POS[15] 0.0",                             // 5.
			//"Index Length  801 50 POS[G2: 15] 0.0",                         // 6.
			//"Index Length  851 50 POS[G3: 0] 0.0",                          // 7.
			//"Index Length  901 50 POS[G4:0] 0.0",                           // 8.
			//"Index Length  951 50 POS[G5:0] 0.0",                           // 9.
			//"Index Length 1001 18 PRG[1] 1",                                // 10.
			//"Index Length 1019 18 PRG[M1] 1",                               // 11.
			//"Index Length 1037 18 PRG[K1] 1",                               // 12.
			//"Index Length 1055 18 PRG[MK1] 1",                              // 13.
			//"Index Length 1073 500 PR[1] 0.0",                              // 14.
			//"Index Length 1573 200 PR[G2:1] 0.0",                           // 15.
			//"Index Length 1773 500 PR[G3:1] 0.0",                           // 16.
			//"Index Length 2273 500 PR[G4: 1] 0.0",                          // 17.
			//"Index Length 2773 500 PR[G5: 1] 0.0",                          // 18.
			//"Index Length 3273 2 $FAST_CLOCK 1",                            // 19.
			//"Index Length 3275 2 $TIMER[10].$TIMER_VAL 1",                  // 20.
			//"Index Length 3277 2 $MOR_GRP[1].$CURRENT_ANG[1] 0",            // 21.
			//"Index Length 3279 2 $DUTY_TEMP 0",                             // 22.
			//"Index Length 3281 40 $TIMER[10].$COMMENT 1",                   // 23.
			//"Index Length 3321 40 $TIMER[2].$COMMENT 1",                    // 24.
			//"Index Length 3361 50 $MNUTOOL[1,1] 0.0",                       // 25.
			//"Index Length 3411 40 $[HTTPKCL]CMDS[1] 1",                     // 26.
			//"Index Length 3451 10 R[1] 1.0",                                // 27.
			//"Index Length 3461 10 R[6] 0",                                  // 28.
			//"Index Length 3471 250 PR[1]@1.25 0.0",                         // 29.
			//"Index Length 3721 250 PR[1]@1.25 0.0",                         // 30.
			//"Index Length 3971 120 PR[G2:1]@27.12 0.0",                     // 31.
			//"Index Length 4091 120 DI[C1] 1",                               // 32.
			//"Index Length 4211 120 DO[C1] 1",                               // 33.
			//"Index Length 4331 120 RI[C1] 1",                               // 34.
			//"Index Length 4451 120 RO[C1] 1",                               // 35.
			//"Index Length 4571 120 UI[C1] 1",                               // 36.
			//"Index Length 4691 120 UO[C1] 1",                               // 37.
			//"Index Length 4811 120 SI[C1] 1",                               // 38.
			//"Index Length 4931 120 SO[C1] 1",                               // 39.
			//"Index Length 5051 120 WI[C1] 1",                               // 40.
			//"Index Length 5171 120 WO[C1] 1",                               // 41.
			//"Index Length 5291 120 WSI[C1] 1",                              // 42.
			//"Index Length 5411 120 AI[C1] 1",                               // 43.
			//"Index Length 5531 120 AO[C1] 1",                               // 44.
			//"Index Length 5651 120 GI[C1] 1",                               // 45.
			//"Index Length 5771 120 GO[C1] 1",                               // 46.
			//"Index Length 5891 120 SR[1] 1",                                // 47.
			//"Index Length 6011 120 SR[C1] 1",                               // 48.
			//"Index Length 6131 10 R[1] 1.0",                                // 49.
			//"Index Length 6141 2 $TIMER[1].$TIMER_VAL 1",                   // 50.
			//"Index Length 6143 2 $TIMER[2].$TIMER_VAL 1",                   // 51.
			//"Index Length 6145 2 $TIMER[3].$TIMER_VAL 1",                   // 52.
			//"Index Length 6147 2 $TIMER[4].$TIMER_VAL 1",                   // 53.
			//"Index Length 6149 2 $TIMER[5].$TIMER_VAL 1",                   // 54.
			//"Index Length 6151 2 $TIMER[6].$TIMER_VAL 1",                   // 55.
			//"Index Length 6153 2 $TIMER[7].$TIMER_VAL 1",                   // 56.
			//"Index Length 6155 2 $TIMER[8].$TIMER_VAL 1",                   // 57.
			//"Index Length 6157 2 $TIMER[9].$TIMER_VAL 1",                   // 58.
			//"Index Length 6159 2 $TIMER[10].$TIMER_VAL 1",                  // 59

			// 对于POSE数据，一个POSE共计站100个字节内部的信息如下：
			// [0-35]      [36-49]     [50-51]   [52-87]   [88-89]  [90-91]  [92-93]
			// xyzwpr*9    config*7    validC    Joints*9  ValidJ   UF       UT

			// 同理，我们也可以针对指定的地址进行写入操作   注意，防止出现意外。
			OperateResult write = fanuc.Write( "D751", 123.456f );


			#endregion
		}
	}
}
