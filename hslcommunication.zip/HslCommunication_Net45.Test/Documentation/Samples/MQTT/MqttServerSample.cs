﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.MQTT;
using HslCommunication.Profinet.Siemens;
using HslCommunication.Reflection;

namespace HslCommunication_Net45.Test.Documentation.Samples.MQTT
{
	class MqttServerSample1
	{
		#region Sample1

		MqttServer server;
		public void Start( )
		{
			try
			{
				server = new MqttServer( );
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		#endregion
	}

	class MqttServerSample2
	{
		#region Sample2

		MqttServer server;
		public void Start( )
		{
			try
			{
				server = new MqttServer( );
				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") return 0;
					return 4;

					// 返回错误码说明 Return error code description
					// 1: unacceptable protocol version
					// 2: identifier rejected
					// 3: server unavailable
					// 4: bad user name or password
					// 5: not authorized
				};
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		#endregion

		public void Start1( )
		{
			try
			{
				server = new MqttServer( );

				#region Sample2_1

				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") { session.ClientId = "admin"; return 0; }
					if (userName == "hsl" && passwrod == "123456") { session.ClientId = "GM"; return 0; }  // 也可以写入中文总经理，方便后续其他接口的权限限制
					return 4;

					// 返回错误码说明 Return error code description
					// 1: unacceptable protocol version
					// 2: identifier rejected
					// 3: server unavailable
					// 4: bad user name or password
					// 5: not authorized
				};

				#endregion
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}


		public void Start2( )
		{
			try
			{
				server = new MqttServer( );

				#region Sample2_2

				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") { return 0; } // admin 账户允许发布  admin Account allows posting
					if (userName == "hsl" && passwrod == "123456") { session.ForbidPublishTopic = true; return 0; } // 禁止发布 Prohibit posting
					return 4; // 其他账户不允许登录 Other accounts are not allowed to log in

					// 返回错误码说明 Return error code description
					// 1: unacceptable protocol version
					// 2: identifier rejected
					// 3: server unavailable
					// 4: bad user name or password
					// 5: not authorized
				};

				#endregion
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}
	}

	class MqttServerSample3
	{
		#region Sample3

		MqttServer server;
		public void Start( )
		{
			try
			{
				server = new MqttServer( );
				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") return 0;
					return 4;
				};
				server.OnClientApplicationMessageReceive += ( MqttSession session, MqttClientApplicationMessage message ) =>
				{
					// 此处举例是打印，当然了，你也可以做一些其他的处理，当所有的客户端进行发布操作的时候，就会触发当前的方法
					// The example here is printing. Of course, you can also do some other processing. When all clients perform publishing operations, the current method will be triggered.
					Console.WriteLine( $"ClientId:[{message.ClientId}] Topic:[{message.Topic}] Payload: {Encoding.UTF8.GetString( message.Payload )}" );

					// 如果你想阻止当前的消息推送给客户端，那么可以按照下面的操作
					// If you want to prevent the current message from being pushed to the client, then you can follow
					message.IsCancelPublish = true;
				};
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		#endregion
	}

	class MqttServerSample4
	{
		#region Sample4

		MqttServer server;
		public void Start( )
		{
			try
			{
				server = new MqttServer( );
				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") return 0;
					return 5;
				};
				server.OnClientApplicationMessageReceive += ( MqttSession session, MqttClientApplicationMessage message ) =>
				{
					// 此处举例是打印，当然了，你也可以做一些其他的处理，当所有的客户端进行发布操作的时候，就会触发当前的方法
					// The example here is printing. Of course, you can also do some other processing. When all clients perform publishing operations, the current method will be triggered.
					Console.WriteLine( $"ClientId:[{message.ClientId}] Topic:[{message.Topic}] Payload: {Encoding.UTF8.GetString( message.Payload )}" );

					// 如果你想阻止当前的消息推送给客户端，那么可以按照下面的操作
					// If you want to prevent the current message from being pushed to the client, then you can follow
					message.IsCancelPublish = true;
				};
				server.OnClientConnected += ( MqttSession session ) =>
				{
					// 当客户端连接上服务器的时候触发，你可以做一些额外的数据处理，或是情况处理。比如发送一条消息出去
					// Triggered when the client connects to the server, you can do some additional data processing or situation processing. Such as sending a message out
					server.PublishTopicPayload( session, "Online", Encoding.UTF8.GetBytes( "Thank you for use hsl" ) );
				};
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		#endregion

		#region Sample5

		public void button1_Click(object sender, EventArgs e )
		{
			// 此处示例是发布给指定的主题
			// The example here is posted to the specified topic
			server.PublishTopicPayload( "Topic", Encoding.UTF8.GetBytes( "Test Data" ) );

			// 此处示例是发布给指定的clientId
			// The example here is posted to the specified clientId
			server.PublishTopicPayload( "ClientId1", "Topic", Encoding.UTF8.GetBytes( "Test Data" ) );

			// 此处的示例是发布给所有的客户端，不管这个客户端有没有订阅相关的主题
			// The example here is published to all clients, regardless of whether the client is subscribed to related topics
			server.PublishAllClientTopicPayload("Topic", Encoding.UTF8.GetBytes( "Test Data" ) );




			// 如果要消息驻留，意思就是当其他的客户端订阅了驻留的主题，会立即收到一条最后更新的数据内容，那么上面的代码可以修改成下面的形式
			// If you want the message to reside, it means that when other clients subscribe to the resident topic, they will immediately receive a last updated data content, then the above code can be modified into the following form
			server.PublishTopicPayload( "Topic", Encoding.UTF8.GetBytes( "Test Data" ), true );
			server.PublishTopicPayload( "ClientId1", "Topic", Encoding.UTF8.GetBytes( "Test Data" ), true );
			server.PublishAllClientTopicPayload( "Topic", Encoding.UTF8.GetBytes( "Test Data" ), true );
		}

		#endregion
	}

	class MqttServerSample5
	{
		#region Sample6

		MqttServer server;
		public void Start( )
		{
			try
			{
				server = new MqttServer( );
				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") return 0;
					return 4;
				};
				server.OnClientApplicationMessageReceive += ( MqttSession session, MqttClientApplicationMessage message ) =>
				{
					if (session.Protocol == "MQTT")
					{
						// 正常的MQTT协议的内容，进行发布订阅操作

						// 此处举例是打印，当然了，你也可以做一些其他的处理，当所有的客户端进行发布操作的时候，就会触发当前的方法
						// The example here is printing. Of course, you can also do some other processing. When all clients perform publishing operations, the current method will be triggered.
						Console.WriteLine( $"ClientId:[{message.ClientId}] Topic:[{message.Topic}] Payload: {Encoding.UTF8.GetString( message.Payload )}" );

						// 如果你想阻止当前的消息推送给客户端，那么可以按照下面的操作
						// If you want to prevent the current message from being pushed to the client, then you can follow
						message.IsCancelPublish = true;
					}
					else
					{
						// 同步网络的情况，正常情况都是需要返回信息的，否则客户端就会引发接收超时的异常
						// In the case of synchronous network, the normal situation is to return information, otherwise the client will cause an exception of receiving timeout
						if (message.Topic == "GetA")
						{
							server.PublishTopicPayload( session, "Success", Encoding.UTF8.GetBytes( "这是你获取的数据A" ) );
						}
						else if (message.Topic == "GetB")
						{
							server.PublishTopicPayload( session, "Success", Encoding.UTF8.GetBytes( "这是你获取的数据B" ) );
						}
						else
						{
							// 如果需要返回错误的信息，客户端直接IsSuccess为False，然后这个Message就是下面的字符串
							// If you need to return wrong information, the client directly IsSuccess is False, and then this Message is the following string
							server.ReportOperateResult( session, "当前的操作不支持" );
						}
					}
				};
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		#endregion
	}


	class MqttServerSample6
	{
		#region Sample7

		MqttServer server;
		SiemensS7Net siemens;

		public void Start( )
		{
			try
			{
				siemens = new SiemensS7Net( SiemensPLCS.S1200, "127.0.0.1" );
				siemens.SetPersistentConnection( );

				server = new MqttServer( );
				server.ClientVerification += ( MqttSession session, string clientId, string userName, string passwrod ) =>
				{
					if (userName == "admin" && passwrod == "123456") return 0;
					return 4;
				};
				server.OnClientApplicationMessageReceive += ( MqttSession session, MqttClientApplicationMessage message ) =>
				{
					if (session.Protocol == "MQTT")
					{
						// 正常的MQTT协议的内容，进行发布订阅操作

						// 此处举例是打印，当然了，你也可以做一些其他的处理，当所有的客户端进行发布操作的时候，就会触发当前的方法
						// The example here is printing. Of course, you can also do some other processing. When all clients perform publishing operations, the current method will be triggered.
						Console.WriteLine( $"ClientId:[{message.ClientId}] Topic:[{message.Topic}] Payload: {Encoding.UTF8.GetString( message.Payload )}" );

						// 如果你想阻止当前的消息推送给客户端，那么可以按照下面的操作
						// If you want to prevent the current message from being pushed to the client, then you can follow
						message.IsCancelPublish = true;
					}
					else
					{
						// 同步网络的情况，正常情况都是需要返回信息的，否则客户端就会引发接收超时的异常
						// In the case of synchronous network, the normal situation is to return information, otherwise the client will cause an exception of receiving timeout
						if (message.Topic == "GetA")
						{
							server.PublishTopicPayload( session, "Success", Encoding.UTF8.GetBytes( "这是你获取的数据A" ) );
						}
						else if (message.Topic == "GetB")
						{
							server.PublishTopicPayload( session, "Success", Encoding.UTF8.GetBytes( "这是你获取的数据B" ) );
						}
						else
						{
							// 如果需要返回错误的信息，客户端直接IsSuccess为False，然后这个Message就是下面的字符串
							// If you need to return wrong information, the client directly IsSuccess is False, and then this Message is the following string
							server.ReportOperateResult( session, "当前的操作不支持" );
						}
					}
				};

				// 注册当前的服务，当下面所有的带特性HslMqttApi的方法都暴露出来，其中，设备温度仅支持admin账户设定
				// Register the current service, when all the following methods with characteristic HslMqttApi are exposed, 
				// the device temperature only supports the admin account setting
				server.RegisterMqttRpcApi( this );
				server.ServerStart( 1883 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Start Failed: " + ex.Message );
			}
		}

		[HslMqttApi( "启动设备" )]
		public OperateResult StartDevice( ) => siemens.Write( "M100.0", true );

		[HslMqttApi( "停止设备" )]
		public OperateResult StopDevice( ) => siemens.Write( "M100.0", false );

		[HslMqttApi( "设置设备的温度信息，当设备处于非工作状态才有效，仅允许admin账户设置" )]
		[HslMqttPermission(UserName = "admin")]
		public OperateResult SetTemperature( float temp )
		{
			// 此处假设设置PLC的温度，当设备停止的时候才能设备
			var check = siemens.ReadBool( "M100.0" ).Check( m => m == false, "当前的设备状态在运行中，无法设置！" );
			if (!check.IsSuccess) return OperateResult.CreateFailedResult<string>( check );

			return siemens.Write( "M200", temp );
		}

		[HslMqttApi( "读取设备的温度信息" )]
		public OperateResult<float> ReadTemperature( ) => siemens.ReadFloat( "M200" );

		#endregion
	}
}
