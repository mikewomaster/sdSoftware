﻿// CppDemoVs2019.cpp : 此文件包含 "main" 函数。程序执行将在此处开始并结束。
//

#include <iostream>
using namespace HslCommunication;
using namespace HslCommunication::Core::Net;
using namespace HslCommunication::ModBus;
using namespace HslCppExtension;

int main()
{
    std::cout << "Hello World!\n";

	// 此处演示了modbus协议读取，其他的plc读取是类似的
	System::String^ ipAddress = gcnew System::String("127.0.0.1");
	ModbusTcpNet^ modbus = gcnew ModbusTcpNet(ipAddress, 502, 1);

	// 连接
	modbus->ConnectServer();

	// 读取的示例
	System::String^ dataAddress = gcnew System::String("100");
	OperateResult<short>^ readValue = modbus->ReadInt16(dataAddress);
	if (readValue->IsSuccess) {
		short value = readValue->Content;
		printf("Read Value：%d \n", value);
	}
	else
	{
		printf("Read Failed");
	}

	// 写入的示例，因为重载方法很多，所以此处使用了扩展的方法
	dataAddress = gcnew System::String("200");
	printf("Write Test\n");
	float aa = 1.1;
	NetworkDeviceBaseExtension::WriteSingle(modbus, dataAddress, aa);

	OperateResult<float>^ readFloatValue = modbus->ReadFloat(dataAddress);
	if (readFloatValue->IsSuccess) {
		float value = readFloatValue->Content;
		printf("Read Value：%f \n", value);
	}

	// 断开连接
	modbus->ConnectClose();

	return 0;
}


// 要想调试成功下面的两个步骤非常重要
// 第一，引用.net35版本的dll
// 第二，项目->属性->公共语言运行时->支持clr
// 第三，项目->属性->C/C++->语言->符合模式：否


// 运行程序: Ctrl + F5 或调试 >“开始执行(不调试)”菜单
// 调试程序: F5 或调试 >“开始调试”菜单

// 入门使用技巧: 
//   1. 使用解决方案资源管理器窗口添加/管理文件
//   2. 使用团队资源管理器窗口连接到源代码管理
//   3. 使用输出窗口查看生成输出和其他消息
//   4. 使用错误列表窗口查看错误
//   5. 转到“项目”>“添加新项”以创建新的代码文件，或转到“项目”>“添加现有项”以将现有代码文件添加到项目
//   6. 将来，若要再次打开此项目，请转到“文件”>“打开”>“项目”并选择 .sln 文件
