﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Profinet.Freedom;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.Profinet
{
    class FreedomExample
    {
        #region Sample1

        // 指定IP地址及端口号来实例化一个自由协议的数据信息，此处演示使用自由协议类来读取Modbus-Tcp的服务器
        private FreedomTcpNet freedom = new FreedomTcpNet( "127.0.0.1", 502 );

        #endregion

        #region Sample2

        public void ReadSample( )
        {
            // 我们来演示如何读取地址100的数据
            // 如果使用TCP我们发送数据 00 00 00 00 00 06 01 03 00 64 00 01
            // 对方将会返回数据 00 00 00 00 00 05 01 03 02 00 7B  (假设地址100的数据是123)

            // 在实际的读取之前需要配置一次相关的参数信息，如果是三菱或是西门子，就不一样，需要自己根据实际的数据转换规则来设定
            freedom.ByteTransform = new HslCommunication.Core.ReverseWordTransform( ); // modbus协议的字节变换操作

            OperateResult connect = freedom.ConnectServer( );
            if (connect.IsSuccess)
            {
                // 连接成功，我们进行读取，地址为报文数据，可以携带stx参数，在解析数据结果的时候，进行偏移多少地址
                OperateResult<short> read = freedom.ReadInt16( "00 00 00 00 00 06 01 03 00 64 00 01;stx=9" );
                if (read.IsSuccess)
                {
                    Console.WriteLine( "Read Value:" + read.Content );
                }
                else
                {
                    // 读取失败
                }
            }
            else
            {
                // 连接失败，不进行操作
            }
        }

        #endregion
    }
    class FreedomExample2
    {
        #region Sample3

        // 指定IP地址及端口号来实例化一个自由协议的数据信息，此处演示使用自由协议类来读取Modbus-Tcp的服务器
        private FreedomUdpNet freedom = new FreedomUdpNet( "127.0.0.1", 502 );

        #endregion

        #region Sample4

        public void ReadSample( )
        {
            // 我们来演示如何读取地址100的数据
            // 如果使用UDP我们发送数据 00 00 00 00 00 06 01 03 00 64 00 01
            // 对方将会返回数据 00 00 00 00 00 05 01 03 02 00 7B  (假设地址100的数据是123)

            // 在实际的读取之前需要配置一次相关的参数信息，如果是三菱或是西门子，就不一样，需要自己根据实际的数据转换规则来设定
            freedom.ByteTransform = new HslCommunication.Core.ReverseWordTransform( ); // modbus协议的字节变换操作

            // UDP协议不需要连接，直接读取，我们进行读取，地址为报文数据，可以携带stx参数，在解析数据结果的时候，进行偏移多少地址
            OperateResult<short> read = freedom.ReadInt16( "00 00 00 00 00 06 01 03 00 64 00 01;stx=9" );
            if (read.IsSuccess)
            {
                Console.WriteLine( "Read Value:" + read.Content );
            }
            else
            {
                // 读取失败
            }
        }

        #endregion
    }
    class FreedomExample3
    {
        #region Sample5

        // 指定IP地址及端口号来实例化一个自由协议的数据信息，此处演示使用自由协议类来读取Modbus-Tcp的服务器
        private FreedomSerial freedom = new FreedomSerial( );

        #endregion

        #region Sample6

        public void ReadSample( )
        {
            // 我们来演示如何读取地址100的数据
            // 如果使用串口我们发送数据 01 03 00 64 00 01 C5 D5
            // 对方将会返回数据 01 03 02 00 7B F8 67  (假设地址100的数据是123)

            // 先初始化串口
            freedom.SerialPortInni( "COM2", 9600, 8, System.IO.Ports.StopBits.One, System.IO.Ports.Parity.None );

            // 在实际的读取之前需要配置一次相关的参数信息，如果是三菱或是西门子，就不一样，需要自己根据实际的数据转换规则来设定
            freedom.ByteTransform = new HslCommunication.Core.ReverseWordTransform( ); // modbus协议的字节变换操作

            // 串口不需要连接，直接读取，如果串口没有打开，会去打开串口，我们进行读取，地址为报文数据，可以携带stx参数，在解析数据结果的时候，进行偏移多少地址
            OperateResult<short> read = freedom.ReadInt16( "01 03 00 64 00 01 C5 D5;stx=3" );
            if (read.IsSuccess)
            {
                Console.WriteLine( "Read Value:" + read.Content );
            }
            else
            {
                // 读取失败
            }
        }

        #endregion
    }
}
