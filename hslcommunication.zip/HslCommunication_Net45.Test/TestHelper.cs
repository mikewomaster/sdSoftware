﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.BasicFramework;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HslCommunication_Net45.Test
{
    public static class TestHelper
    {

    }

    public class HslAssert
    {
        public static void IsTrue( OperateResult result )
        {
            Assert.IsTrue( result.IsSuccess, result.Message );
        }

        public static void IsFalse( OperateResult result )
        {
            Assert.IsFalse( result.IsSuccess );
        }

        public static void AreArrayEqual( bool[] expect, bool[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( bool[] expect, OperateResult<bool[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( byte[] expect, byte[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            Assert.IsTrue( SoftBasic.IsTwoBytesEquel( expect, actual ), $"\r\nExpect:{expect.ToHexString( ' ' )} \r\nActual:{actual.ToHexString( ' ' )}" );
        }

        public static void AreArrayEqual( byte[] expect, OperateResult<byte[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( short[] expect, short[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( short[] expect, OperateResult<short[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( ushort[] expect, ushort[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( ushort[] expect, OperateResult<ushort[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( int[] expect, int[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( int[] expect, OperateResult<int[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( uint[] expect, uint[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( uint[] expect, OperateResult<uint[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( long[] expect, long[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( long[] expect, OperateResult<long[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( ulong[] expect, ulong[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( ulong[] expect, OperateResult<ulong[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( float[] expect, float[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( float[] expect, OperateResult<float[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

        public static void AreArrayEqual( double[] expect, double[] actual )
        {
            if (expect == null || actual == null) Assert.Fail( "一方为Null或是双方为Null" );
            if (expect.Length != actual.Length) Assert.Fail( "双方数组长度不一致" );
            for (int i = 0; i < expect.Length; i++)
            {
                if (expect[i] != actual[i])
                {
                    Assert.Fail( $"\r\nExpect:{expect.ToArrayString( )} \r\nActual:{actual.ToArrayString( )}" );
                }
            }
        }

        public static void AreArrayEqual( double[] expect, OperateResult<double[]> actual )
        {
            IsTrue( actual );
            AreArrayEqual( expect, actual.Content );
        }

    }
}
