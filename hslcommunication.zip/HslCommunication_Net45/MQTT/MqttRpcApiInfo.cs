﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using HslCommunication.Reflection;
using Newtonsoft.Json;

namespace HslCommunication.MQTT
{
	/// <summary>
	/// Mqtt的同步网络服务的单Api信息描述类<br />
	/// Single Api information description class of Mqtt's synchronous network service
	/// </summary>
	public class MqttRpcApiInfo
	{
		/// <summary>
		/// 当前的Api的路由信息，对于注册服务来说，是类名/方法名
		/// </summary>
		public string ApiTopic { get; set; }

		/// <summary>
		/// 当前的Api的路由说明
		/// </summary>
		public string Description { get; set; }

		/// <summary>
		/// 当前Api的调用次数
		/// </summary>
		public long CalledCount { get; set; }

		/// <summary>
		/// 示例的
		/// </summary>
		public string ExamplePayload { get; set; }

		/// <summary>
		/// 当前Api的调用总耗时
		/// </summary>
		public double SpendTotalTime { get; set; }

		/// <summary>
		/// 当前的Api的方法是否是异步的Task类型
		/// </summary>
		[JsonIgnore]
		public bool IsOperateResultApi { get; set; }

		/// <summary>
		/// 当前的Api关联的方法反射，本属性在JSON中将会忽略
		/// </summary>
		[JsonIgnore]
		public MethodInfo Method { get; set; }

		/// <summary>
		/// 当前Api的方法的权限访问反射，本属性在JSON中将会忽略
		/// </summary>
		[JsonIgnore]
		public HslMqttPermissionAttribute PermissionAttribute { get; set; }

		/// <summary>
		/// 当前Api绑定的对象的，实际的接口请求，将会从对象进行调用，本属性在JSON中将会忽略
		/// </summary>
		[JsonIgnore]
		public object SourceObject { get; set; }

		/// <inheritdoc/>
		public override string ToString( ) => this.ApiTopic;
    }
}
