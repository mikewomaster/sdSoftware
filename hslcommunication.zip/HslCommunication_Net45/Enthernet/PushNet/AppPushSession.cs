﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HslCommunication.Enthernet
{
    /// <summary>
    /// 当前的推送的会话的基本信息
    /// </summary>
    public class AppPushSession
    {

    }
}
