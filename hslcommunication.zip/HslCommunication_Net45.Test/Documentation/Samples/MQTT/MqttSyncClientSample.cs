﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.MQTT;

namespace HslCommunication_Net45.Test.Documentation.Samples.MQTT
{
    public class MqttSyncClientSample
    {

        public void Test1( )
        {
            #region Test

            // 简单的实例化例子
            MqttSyncClient mqttSyncClient = new MqttSyncClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );


            #endregion

        }

        public void Test2( )
        {
            #region Test2

            // 如果有密码的情况
            MqttSyncClient mqttSyncClient = new MqttSyncClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                                            // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",                                     // 服务器的地址
                Credentials = new MqttCredential( "admin", "123456" )        // 设置了用户名和密码
            } );

            #endregion
        }

        public void Test3( )
        {
            #region Test3

            // 连接服务器
            MqttSyncClient mqttSyncClient = new MqttSyncClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );
            HslCommunication.OperateResult connect = mqttSyncClient.ConnectServer( );
            if (connect.IsSuccess)
            {
                // 连接成功
            }
            else
            {
                // 连接失败，过会就需要重新连接了
            }

            // 关闭的话
            mqttSyncClient.ConnectClose( );

            #endregion
        }

        public void Test4( )
        {
            #region Test4

            MqttSyncClient mqttSyncClient = new MqttSyncClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );

            // 设置长连接
            mqttSyncClient.SetPersistentConnection( );

            // 读取服务器的数据示例
            HslCommunication.OperateResult<string, byte[]> read = mqttSyncClient.Read( topic: "A", payload: Encoding.UTF8.GetBytes( "测试数据" ) );
            if (read.IsSuccess)
            {
                // 读取成功
                string topic = read.Content1;
                byte[] payload = read.Content2;
            }
            else
            {
                // 读取失败
            }

            // 你只需要负责不停的读取就好了，单次读取数据限制为200多M，如果网络异常，会自动重新连接的。
            // 如果你的服务器都是按照字符串来处理的话，那么客户端可以简便代码，客户端默认采用UTF8编码，当然也可以自己指定
            HslCommunication.OperateResult<string, string> read2 = mqttSyncClient.ReadString( "A", "测试数据" );
            if (read2.IsSuccess)
            {
                // 读取成功
                string topic = read2.Content1;
                string payload = read2.Content2;
            }
            else
            {
                // 读取失败
            }

            #endregion
        }

        public void Test5( )
        {
            #region Test5

            MqttSyncClient mqttSyncClient = new MqttSyncClient( new MqttConnectionOptions( )
            {
                ClientId = "ABC",                     // 客户端的唯一的ID信息
                IpAddress = "127.0.0.1",              // 服务器的地址
            } );

            // 设置长连接
            mqttSyncClient.SetPersistentConnection( );

            // 读取服务器的时候进行进度报告，主要分为上传进度和下载进度，此处就简单的显示下而已
            Action<long, long> uploadProgress = new Action<long, long>( ( already, total ) =>
             {
                 Console.WriteLine( $"已发送：{(already * 100 / total)}%    已发送/总字节：{already}/{total}" );
             } );
            Action<long, long> downloadProgress = new Action<long, long>( ( already, total ) =>
            {
                Console.WriteLine( $"已下载：{(already * 100 / total)}%    已下载/总字节：{already}/{total}" );
            } );
            HslCommunication.OperateResult<string, byte[]> read = mqttSyncClient.Read( topic: "A", payload: Encoding.UTF8.GetBytes( "测试数据" ), uploadProgress, null, downloadProgress );
            if (read.IsSuccess)
            {
                // 读取成功
                string topic = read.Content1;
                byte[] payload = read.Content2;
            }
            else
            {
                // 读取失败
            }

            // 你只需要负责不停的读取就好了，单次读取数据限制为200多M，如果网络异常，会自动重新连接的。

            // 还有一种更复杂的情况，需要配合服务器侧来完成，现在假设一种情况，客户端向服务器发送一个命令，
            // 然后服务器执行相关的操作，这个操作分为5个小操作，时间1-5秒不等，然后处理好后将结果发送给客户端
            Action<string, string> handleProgress = new Action<string, string>( ( topic, msg ) =>
            {
                // topic服务器可以存放处理进度
                Console.WriteLine( $"已完成：{topic}%    当前正在执行：{msg}" );
            } );
            HslCommunication.OperateResult<string, byte[]> read2 = mqttSyncClient.Read( topic: "B", payload: Encoding.UTF8.GetBytes( "测试数据" ), null, handleProgress, null );
            if (read2.IsSuccess)
            {
                // 读取成功
                string topic = read.Content1;
                byte[] payload = read.Content2;
            }
            else
            {
                // 读取失败
            }

            #endregion
        }
    }
}
