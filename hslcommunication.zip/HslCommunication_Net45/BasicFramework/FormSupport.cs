﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace HslCommunication.BasicFramework
{
    /// <summary>
    /// 作者的技术支持的窗口界面
    /// </summary>
    public partial class FormSupport : Form
    {
        /// <summary>
        /// 实例化一个默认的界面
        /// </summary>
        public FormSupport( )
        {
            InitializeComponent( );
        }
    }
}
