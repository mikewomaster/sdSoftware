﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Profinet.Panasonic;
using HslCommunication;

namespace HslCommunication_Net45.Test.Profinet.Panasonic
{
    [TestClass]
    public class PanasonicHelperTest
    {
        [TestMethod]
        public void Test1( )
        {
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "10" ) == 16 );
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "1F" ) == 31 );
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "2.1" ) == 33 );
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "2.F" ) == 47 );
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "2.15" ) == 47 );
            Assert.IsTrue( PanasonicHelper.CalculateComplexAddress( "7.5" ) == 7 * 16 + 5 );
        }
    }
}
