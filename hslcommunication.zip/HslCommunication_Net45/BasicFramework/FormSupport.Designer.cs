﻿namespace HslCommunication.BasicFramework
{
    partial class FormSupport
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
			this.label1 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.pictureBox2 = new System.Windows.Forms.PictureBox();
			this.label6 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.label10 = new System.Windows.Forms.Label();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(32, 356);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(608, 17);
			this.label1.TabIndex = 1;
			this.label1.Text = "如果这个组件真的帮到了你或你们公司，那么非常感谢您的支持，个人打赏，请视个人能力选择金额，感谢支持。";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(32, 501);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(560, 17);
			this.label3.TabIndex = 3;
			this.label3.Text = "如果您的公司使用了本产品，那么非常感谢对本产品的信任，企业赞助或是合作请加群后专门联系作者。";
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(312, 519);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(387, 17);
			this.label4.TabIndex = 4;
			this.label4.Text = "作者：Richard.Hu 上图为支付宝和微信账户的收钱码，请认准官方账户";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(32, 373);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(488, 17);
			this.label5.TabIndex = 5;
			this.label5.Text = "如果不小心点错了，需要退款，请通过邮箱联系作者，提供付款的截图或是其他证明即可。";
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = global::HslCommunication.Properties.Resources.alipay;
			this.pictureBox1.Location = new System.Drawing.Point(35, 13);
			this.pictureBox1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(267, 339);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 0;
			this.pictureBox1.TabStop = false;
			// 
			// pictureBox2
			// 
			this.pictureBox2.Image = global::HslCommunication.Properties.Resources.mm_facetoface_collect_qrcode_1525331158525;
			this.pictureBox2.Location = new System.Drawing.Point(411, 10);
			this.pictureBox2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.pictureBox2.Name = "pictureBox2";
			this.pictureBox2.Size = new System.Drawing.Size(247, 342);
			this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox2.TabIndex = 6;
			this.pictureBox2.TabStop = false;
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.ForeColor = System.Drawing.Color.Blue;
			this.label6.Location = new System.Drawing.Point(32, 396);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(653, 34);
			this.label6.TabIndex = 7;
			this.label6.Text = "技术支持及探讨学习群，需要赞助240元以上才能加入，申请入群时请提供微信或是支付宝的付款时间，方便管理员核对，\r\n谢谢支持：群号：838185568  群功能如下" +
    "：";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.label2.Location = new System.Drawing.Point(32, 439);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(226, 17);
			this.label2.TabIndex = 8;
			this.label2.Text = "1. 作者给与一定的经验分享，疑问解答。";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.label7.Location = new System.Drawing.Point(352, 439);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(262, 17);
			this.label7.TabIndex = 9;
			this.label7.Text = "2. 群里聚集了各个行业的朋友，行业经验交流。";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.label8.Location = new System.Drawing.Point(32, 456);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(228, 17);
			this.label8.TabIndex = 10;
			this.label8.Text = "3. 探讨交流上位机开发，MES系统开发。";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.label9.Location = new System.Drawing.Point(352, 456);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(310, 17);
			this.label9.TabIndex = 11;
			this.label9.Text = "4. 时不时会有项目需求发布，面向个人，外包或是公司。";
			// 
			// label10
			// 
			this.label10.AutoSize = true;
			this.label10.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
			this.label10.Location = new System.Drawing.Point(32, 473);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(505, 17);
			this.label10.TabIndex = 12;
			this.label10.Text = "5. 免费使用HslControls控件库，demo参照 https://github.com/dathlin/HslControlsDemo";
			// 
			// FormSupport
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(710, 542);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.pictureBox2);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.pictureBox1);
			this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "FormSupport";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "开发不易，如果您觉得类库好用，并应用到了实际项目，感谢赞助";
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
    }
}