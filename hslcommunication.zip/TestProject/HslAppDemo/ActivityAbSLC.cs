﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Support.V7.App;
using Android.Views;
using Android.Widget;
using HslCommunication;
using HslCommunication.Profinet.AllenBradley;
using HslCommunication.Profinet.Melsec;

namespace HslAppDemo
{
    [Activity( Label = "AB SLC Net" )]
    public class ActivityAbSLC : AppCompatActivity
    {
        protected override void OnCreate( Bundle savedInstanceState )
        {
            base.OnCreate( savedInstanceState );

            SetContentView( Resource.Layout.layout_melsec_mc );

            ipAddressText   = FindViewById<EditText>( Resource.Id.editText_ip_address );
            portText        = FindViewById<EditText>( Resource.Id.editText_ip_port );
            btnConnect      = FindViewById<Button>( Resource.Id.button_connect );
            btnDisconnect   = FindViewById<Button>( Resource.Id.button_disconnect );

            ipAddressText.Text = AppDemoUtils.GetAppConfigue( "ab_slc_ip", "192.168.0.100" );
            portText.Text      = AppDemoUtils.GetAppConfigue( "ab_slc_port", "44818" );
            ConnectInitialization( );
        }


        public override void OnBackPressed( )
        {
            base.OnBackPressed( );
            melsec?.ConnectClose( );
            melsec = null;
        }

        #region Connect DisConnect

        private void ConnectInitialization( )
        {
            btnConnect.Click += Activity_Click_connect;
            btnDisconnect.Click += Activity_Click_disconnect;
            btnDisconnect.Enabled = false;
        }

        private void Activity_Click_connect( object sender, EventArgs e )
        {
            if(!IPAddress.TryParse( ipAddressText.Text, out IPAddress ip ))
            {
                AppDemoUtils.ToastMessage( this, "IpAddress Input Failed!" );
                return;
            }

            if(!int.TryParse( portText.Text, out int port ))
            {
                AppDemoUtils.ToastMessage( this, "Port Input Failed!" );
                return;
            }

            melsec?.ConnectClose( );
            melsec = new AllenBradleySLCNet( ipAddressText.Text, port );
            melsec.ConnectTimeOut = 2000;

            OperateResult connect = melsec.ConnectServer( );
            if (connect.IsSuccess)
            {
                AppDemoUtils.ToastMessage( this, "Connect Success" );
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;

                AppDemoUtils.SetAppConfigue( "ab_slc_ip", ipAddressText.Text );
                AppDemoUtils.SetAppConfigue( "ab_slc_port", portText.Text );

                FindViewById<IReadWriteControl>( Resource.Id.iReadWriteControl1 ).SetReadWriteNet( melsec, "A9:0", true );
            }
            else
            {
                melsec = null;
                AppDemoUtils.ToastMessage( this, "Connect Failed" + connect.ToMessageShowString( ) );
            }
        }

        private void Activity_Click_disconnect( object sender, EventArgs e )
        {
            melsec?.ConnectClose( );
            melsec = null;
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
            AppDemoUtils.ToastMessage( this, "Connect Close" );
            FindViewById<IReadWriteControl>( Resource.Id.iReadWriteControl1 ).SetReadWriteNet( null, "" );
        }

        #endregion

        private Button btnConnect = null;
        private Button btnDisconnect = null;
        private EditText ipAddressText = null;
        private EditText portText = null;
        private AllenBradleySLCNet melsec = null;
    }
}