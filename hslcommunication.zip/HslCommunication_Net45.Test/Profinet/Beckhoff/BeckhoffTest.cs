﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Profinet.Beckhoff;
using HslCommunication.BasicFramework;
using HslCommunication;

namespace HslCommunication_Net45.Test.Profinet.Beckhoff
{
    [TestClass]
    public class BeckhoffTest
    {
        [TestMethod]
        public void StrToAdsBytesTest( )
        {
            byte[] amsName = BeckhoffAdsNet.StrToAdsBytes( "MAIN.bool1" );
            byte[] right = SoftBasic.HexStringToBytes( "4d 41 49 4e 2e 62 6f 6f 6c 31 00" );
            HslAssert.AreArrayEqual( right, amsName );
        }

        [TestMethod]
        public void StrToAMSNetIdTest( )
        {
            byte[] data = BeckhoffAdsNet.StrToAMSNetId( "192.168.182.131.1.1:801" );
            byte[] right = SoftBasic.HexStringToBytes( "C0 A8 B6 83 01 01 21 03" );
            HslAssert.AreArrayEqual( right, data );


            byte[] data2 = BeckhoffAdsNet.StrToAMSNetId( "192.168.182.131.1.1" );
            byte[] right2 = SoftBasic.HexStringToBytes( "C0 A8 B6 83 01 01" );
            HslAssert.AreArrayEqual( right2, data2 );
        }

        [TestMethod]
        public void BuildReadWriteCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildReadWriteCommand(
                "s=MES_Update.RWstruct1.HmiCode", 4, false, BeckhoffAdsNet.StrToAdsBytes( "MES_Update.RWstruct1.HmiCode" ) );

            byte[] expect = "00004d000000050cf4c401012103ac1c507101010000090004002d000000000000000100000003f0000000000000040000001d0000004d45535f5570646174652e5257737472756374312e486d69436f646500".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }


        [TestMethod]
        public void BuildReadStateCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildReadStateCommand( );

            byte[] expect = "000020000000050cf4c401012103ac1c507101010000040004000000000000000000010000000".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }

        [TestMethod]
        public void BuildReadDeviceInfoCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildReadDeviceInfoCommand( );

            byte[] expect = "000020000000050cf4c401012103ac1c507101010000010004000000000000000000010000000".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }

        [TestMethod]
        public void BuildReadCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildReadCommand(
                "M100", 4, false );

            byte[] expect = "00002C000000050cf4c401012103ac1c507101010000020004000C0000000000000001000000204000006400000004000000".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }

        [TestMethod]
        public void BuildWriteCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildWriteCommand(
                "M100", BitConverter.GetBytes( (short)100 ), false );

            byte[] expect = "00002E000000050cf4c401012103ac1c507101010000030004000E00000000000000010000002040000064000000020000006400".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }

        [TestMethod]
        public void BuildWriteControlCommandTest( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "5.12.244.196.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "172.28.80.113.1.1" );

            OperateResult<byte[]> build = beckhoffAdsNet.BuildWriteControlCommand(
                10, 20, null );

            byte[] expect = "000028000000050cf4c401012103ac1c507101010000050004000800000000000000010000000A00140000000000".ToHexBytes( );
            HslAssert.AreArrayEqual( expect, build.Content );
        }

        public void Test1( )
        {
            BeckhoffAdsNet beckhoffAdsNet = new BeckhoffAdsNet( "192.168.182.131", 48898 );
            beckhoffAdsNet.SetTargetAMSNetId( "192.168.182.131.1.1:801" );
            beckhoffAdsNet.SetSenderAMSNetId( "192.168.235.128.1.1" );

            OperateResult connect = beckhoffAdsNet.ConnectServer( );
            if (connect.IsSuccess)
            {
                // connect success
            }
            else
            {
                // failed
            }

            OperateResult<short> read = beckhoffAdsNet.ReadInt16( "s=MAIN.int1" );
            short value = read.Content;
        }
    }
}
