﻿using HslCommunication;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HslCommunication.Serial;
using HslCommunication.Core;

namespace HslCppExtension
{
	/// <summary>
	/// SerialDeviceBase的写入数据的方法扩展，方便CPP项目的调用，解决方法重载的问题。
	/// </summary>
	public static class SerialDeviceBaseExtension
	{
		/// <inheritdoc cref="IReadWriteNet.Write(string, short)"/>
		public static OperateResult WriteInt16( this SerialDeviceBase device, string address, short value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, short[])"/>
		public static OperateResult WriteInt16Array( this SerialDeviceBase device, string address, short[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ushort)"/>
		public static OperateResult WriteUInt16( this SerialDeviceBase device, string address, ushort value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ushort[])"/>
		public static OperateResult WriteUInt16Array( this SerialDeviceBase device, string address, ushort[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, int)"/>
		public static OperateResult WriteInt32( this SerialDeviceBase device, string address, int value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, int[])"/>
		public static OperateResult WriteInt32Array( this SerialDeviceBase device, string address, int[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, uint)"/>
		public static OperateResult WriteUInt32( this SerialDeviceBase device, string address, uint value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, uint[])"/>
		public static OperateResult WriteUInt32Array( this SerialDeviceBase device, string address, uint[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, long)"/>
		public static OperateResult WriteInt64( this SerialDeviceBase device, string address, long value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, long[])"/>
		public static OperateResult WriteInt64Array( this SerialDeviceBase device, string address, long[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ulong)"/>
		public static OperateResult WriteUInt64( this SerialDeviceBase device, string address, ulong value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ulong[])"/>
		public static OperateResult WriteUInt64Array( this SerialDeviceBase device, string address, ulong[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, float)"/>
		public static OperateResult WriteSingle( this SerialDeviceBase device, string address, float value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, float[])"/>
		public static OperateResult WriteSingleArray( this SerialDeviceBase device, string address, float[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, double)"/>
		public static OperateResult WriteDouble( this SerialDeviceBase device, string address, double value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, double[])"/>
		public static OperateResult WriteDoubleArray( this SerialDeviceBase device, string address, double[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, string)"/>
		public static OperateResult WriteString( this SerialDeviceBase device, string address, string value ) 
		{
			return device.Write( address, value );
		}


		/// <inheritdoc cref="IReadWriteNet.Wait(string, bool, int, int)"/>
		public static OperateResult WaitBool( this SerialDeviceBase device, string address, bool waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, short, int, int)"/>
		public static OperateResult WaitInt16( this SerialDeviceBase device, string address, short waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, ushort, int, int)"/>
		public static OperateResult WaitUInt16( this SerialDeviceBase device, string address, ushort waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, int, int, int)"/>
		public static OperateResult WaitInt32( this SerialDeviceBase device, string address, int waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, uint, int, int)"/>
		public static OperateResult WaitUInt32( this SerialDeviceBase device, string address, uint waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, long, int, int)"/>
		public static OperateResult WaitInt64( this SerialDeviceBase device, string address, long waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, ulong, int, int)"/>
		public static OperateResult WaitUInt64( this SerialDeviceBase device, string address, ulong waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}
	}
}
