﻿namespace HslCommunicationDemo
{
    partial class FormSelect
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent( )
        {
			this.components = new System.ComponentModel.Container();
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormSelect));
			this.menuStrip1 = new System.Windows.Forms.MenuStrip();
			this.aboutToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.blogsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.webSideToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.support赞助ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.authorization授权ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.简体中文ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.englishToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.论坛toolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
			this.日志ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.verisonToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.免责条款ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.授权ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.vS2015BlueTheme1 = new WeifenLuo.WinFormsUI.Docking.VS2015BlueTheme();
			this.treeView1 = new System.Windows.Forms.TreeView();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.treeView2 = new System.Windows.Forms.TreeView();
			this.dockPanel1 = new WeifenLuo.WinFormsUI.Docking.DockPanel();
			this.label1 = new System.Windows.Forms.Label();
			this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
			this.deleteDeviceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
			this.label2 = new System.Windows.Forms.Label();
			this.menuStrip1.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.contextMenuStrip1.SuspendLayout();
			this.SuspendLayout();
			// 
			// menuStrip1
			// 
			this.menuStrip1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutToolStripMenuItem,
            this.简体中文ToolStripMenuItem,
            this.englishToolStripMenuItem,
            this.论坛toolStripMenuItem,
            this.toolStripMenuItem1,
            this.日志ToolStripMenuItem,
            this.verisonToolStripMenuItem,
            this.免责条款ToolStripMenuItem,
            this.授权ToolStripMenuItem});
			this.menuStrip1.Location = new System.Drawing.Point(0, 0);
			this.menuStrip1.Name = "menuStrip1";
			this.menuStrip1.Size = new System.Drawing.Size(1240, 25);
			this.menuStrip1.TabIndex = 26;
			this.menuStrip1.Text = "menuStrip1";
			// 
			// aboutToolStripMenuItem
			// 
			this.aboutToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.blogsToolStripMenuItem,
            this.webSideToolStripMenuItem,
            this.support赞助ToolStripMenuItem,
            this.authorization授权ToolStripMenuItem});
			this.aboutToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.aboutToolStripMenuItem.Name = "aboutToolStripMenuItem";
			this.aboutToolStripMenuItem.Size = new System.Drawing.Size(55, 21);
			this.aboutToolStripMenuItem.Text = "About";
			// 
			// blogsToolStripMenuItem
			// 
			this.blogsToolStripMenuItem.Name = "blogsToolStripMenuItem";
			this.blogsToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.blogsToolStripMenuItem.Text = "Blogs [博客]";
			this.blogsToolStripMenuItem.Click += new System.EventHandler(this.blogsToolStripMenuItem_Click);
			// 
			// webSideToolStripMenuItem
			// 
			this.webSideToolStripMenuItem.Name = "webSideToolStripMenuItem";
			this.webSideToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.webSideToolStripMenuItem.Text = "WebSide [官网]";
			this.webSideToolStripMenuItem.Click += new System.EventHandler(this.webSideToolStripMenuItem_Click);
			// 
			// support赞助ToolStripMenuItem
			// 
			this.support赞助ToolStripMenuItem.Name = "support赞助ToolStripMenuItem";
			this.support赞助ToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.support赞助ToolStripMenuItem.Text = "Support [赞助]";
			// 
			// authorization授权ToolStripMenuItem
			// 
			this.authorization授权ToolStripMenuItem.Name = "authorization授权ToolStripMenuItem";
			this.authorization授权ToolStripMenuItem.Size = new System.Drawing.Size(189, 22);
			this.authorization授权ToolStripMenuItem.Text = "Authorization [授权]";
			this.authorization授权ToolStripMenuItem.Click += new System.EventHandler(this.authorization授权ToolStripMenuItem_Click);
			// 
			// 简体中文ToolStripMenuItem
			// 
			this.简体中文ToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.简体中文ToolStripMenuItem.Name = "简体中文ToolStripMenuItem";
			this.简体中文ToolStripMenuItem.Size = new System.Drawing.Size(68, 21);
			this.简体中文ToolStripMenuItem.Text = "简体中文";
			this.简体中文ToolStripMenuItem.Click += new System.EventHandler(this.简体中文ToolStripMenuItem_Click);
			// 
			// englishToolStripMenuItem
			// 
			this.englishToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.englishToolStripMenuItem.Name = "englishToolStripMenuItem";
			this.englishToolStripMenuItem.Size = new System.Drawing.Size(61, 21);
			this.englishToolStripMenuItem.Text = "English";
			this.englishToolStripMenuItem.Click += new System.EventHandler(this.englishToolStripMenuItem_Click);
			// 
			// 论坛toolStripMenuItem
			// 
			this.论坛toolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.论坛toolStripMenuItem.Name = "论坛toolStripMenuItem";
			this.论坛toolStripMenuItem.Size = new System.Drawing.Size(47, 21);
			this.论坛toolStripMenuItem.Text = "Blog";
			this.论坛toolStripMenuItem.Click += new System.EventHandler(this.论坛toolStripMenuItem_Click);
			// 
			// toolStripMenuItem1
			// 
			this.toolStripMenuItem1.ForeColor = System.Drawing.Color.Silver;
			this.toolStripMenuItem1.Name = "toolStripMenuItem1";
			this.toolStripMenuItem1.Size = new System.Drawing.Size(80, 21);
			this.toolStripMenuItem1.Text = "MesDemo";
			this.toolStripMenuItem1.Click += new System.EventHandler(this.toolStripMenuItem1_Click);
			// 
			// 日志ToolStripMenuItem
			// 
			this.日志ToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.日志ToolStripMenuItem.Name = "日志ToolStripMenuItem";
			this.日志ToolStripMenuItem.Size = new System.Drawing.Size(67, 21);
			this.日志ToolStripMenuItem.Text = "API 文档";
			this.日志ToolStripMenuItem.Click += new System.EventHandler(this.日志ToolStripMenuItem_Click);
			// 
			// verisonToolStripMenuItem
			// 
			this.verisonToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.verisonToolStripMenuItem.Name = "verisonToolStripMenuItem";
			this.verisonToolStripMenuItem.Size = new System.Drawing.Size(64, 21);
			this.verisonToolStripMenuItem.Text = "Verison";
			// 
			// 免责条款ToolStripMenuItem
			// 
			this.免责条款ToolStripMenuItem.ForeColor = System.Drawing.Color.Silver;
			this.免责条款ToolStripMenuItem.Name = "免责条款ToolStripMenuItem";
			this.免责条款ToolStripMenuItem.Size = new System.Drawing.Size(92, 21);
			this.免责条款ToolStripMenuItem.Text = "全国使用情况";
			this.免责条款ToolStripMenuItem.Click += new System.EventHandler(this.免责条款ToolStripMenuItem_Click);
			// 
			// 授权ToolStripMenuItem
			// 
			this.授权ToolStripMenuItem.Name = "授权ToolStripMenuItem";
			this.授权ToolStripMenuItem.Size = new System.Drawing.Size(12, 21);
			// 
			// treeView1
			// 
			this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView1.Location = new System.Drawing.Point(3, 3);
			this.treeView1.Name = "treeView1";
			this.treeView1.Size = new System.Drawing.Size(201, 655);
			this.treeView1.TabIndex = 31;
			this.treeView1.DoubleClick += new System.EventHandler(this.TreeView1_DoubleClick);
			this.treeView1.MouseClick += new System.Windows.Forms.MouseEventHandler(this.treeView1_MouseClick);
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Left;
			this.tabControl1.Location = new System.Drawing.Point(0, 25);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.Padding = new System.Drawing.Point(0, 0);
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(215, 691);
			this.tabControl1.TabIndex = 35;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.treeView1);
			this.tabPage1.Location = new System.Drawing.Point(4, 26);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(207, 661);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "所有设备列表";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.treeView2);
			this.tabPage2.Location = new System.Drawing.Point(4, 26);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(207, 661);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "保存的列表";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// treeView2
			// 
			this.treeView2.Dock = System.Windows.Forms.DockStyle.Fill;
			this.treeView2.Location = new System.Drawing.Point(3, 3);
			this.treeView2.Name = "treeView2";
			this.treeView2.Size = new System.Drawing.Size(201, 655);
			this.treeView2.TabIndex = 0;
			this.treeView2.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.treeView2_MouseDoubleClick);
			// 
			// dockPanel1
			// 
			this.dockPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.dockPanel1.Location = new System.Drawing.Point(215, 25);
			this.dockPanel1.Name = "dockPanel1";
			this.dockPanel1.Size = new System.Drawing.Size(1025, 691);
			this.dockPanel1.TabIndex = 36;
			// 
			// label1
			// 
			this.label1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.label1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label1.Location = new System.Drawing.Point(1031, 3);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(209, 21);
			this.label1.TabIndex = 39;
			this.label1.Text = "Thread:0  Lock:0";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// contextMenuStrip1
			// 
			this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.deleteDeviceToolStripMenuItem});
			this.contextMenuStrip1.Name = "contextMenuStrip1";
			this.contextMenuStrip1.Size = new System.Drawing.Size(152, 26);
			// 
			// deleteDeviceToolStripMenuItem
			// 
			this.deleteDeviceToolStripMenuItem.Image = global::HslCommunicationDemo.Properties.Resources.action_Cancel_16xLG;
			this.deleteDeviceToolStripMenuItem.Name = "deleteDeviceToolStripMenuItem";
			this.deleteDeviceToolStripMenuItem.Size = new System.Drawing.Size(151, 22);
			this.deleteDeviceToolStripMenuItem.Text = "DeleteDevice";
			// 
			// label2
			// 
			this.label2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.label2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
			this.label2.Location = new System.Drawing.Point(816, 3);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(209, 21);
			this.label2.TabIndex = 42;
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// FormSelect
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.BackColor = System.Drawing.Color.AliceBlue;
			this.ClientSize = new System.Drawing.Size(1240, 716);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.dockPanel1);
			this.Controls.Add(this.tabControl1);
			this.Controls.Add(this.menuStrip1);
			this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.IsMdiContainer = true;
			this.MainMenuStrip = this.menuStrip1;
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "FormSelect";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "HslCommunication Test Tools";
			this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.FormSelect_FormClosing);
			this.Load += new System.EventHandler(this.FormLoad_Load);
			this.Shown += new System.EventHandler(this.FormLoad_Shown);
			this.menuStrip1.ResumeLayout(false);
			this.menuStrip1.PerformLayout();
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage2.ResumeLayout(false);
			this.contextMenuStrip1.ResumeLayout(false);
			this.ResumeLayout(false);
			this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem aboutToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blogsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem webSideToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 简体中文ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem englishToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 日志ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem verisonToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 免责条款ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 论坛toolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem 授权ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem support赞助ToolStripMenuItem;
        private WeifenLuo.WinFormsUI.Docking.VS2015BlueTheme vS2015BlueTheme1;
        private System.Windows.Forms.TreeView treeView1;
		private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private WeifenLuo.WinFormsUI.Docking.DockPanel dockPanel1;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TreeView treeView2;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
		private System.Windows.Forms.ToolStripMenuItem authorization授权ToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem deleteDeviceToolStripMenuItem;
		private System.Windows.Forms.Label label2;
	}
}

