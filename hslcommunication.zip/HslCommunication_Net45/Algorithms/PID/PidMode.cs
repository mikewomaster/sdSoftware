﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HslCommunication.Algorithms.PID
{
	/// <summary>
	/// Pid的模式选择
	/// </summary>
	public enum PidMode
	{
		/// <summary>
		/// 增量模式
		/// </summary>
		Increment = 1,

	}
}
