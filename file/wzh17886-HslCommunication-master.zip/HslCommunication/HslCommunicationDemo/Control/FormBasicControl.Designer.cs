﻿namespace HslCommunicationDemo
{
    partial class FormBasicControl
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormBasicControl));
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label10 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.userVerticalProgress8 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress7 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress1 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress2 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress6 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress3 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress5 = new HslCommunication.Controls.UserVerticalProgress();
            this.userVerticalProgress4 = new HslCommunication.Controls.UserVerticalProgress();
            this.userBottle1 = new HslCommunication.Controls.UserBottle();
            this.userSwitch1 = new HslCommunication.Controls.UserSwitch();
            this.userSwitch2 = new HslCommunication.Controls.UserSwitch();
            this.userDrum1 = new HslCommunication.Controls.UserDrum();
            this.userClock1 = new HslCommunication.Controls.UserClock();
            this.userLantern3 = new HslCommunication.Controls.UserLantern();
            this.userLantern1 = new HslCommunication.Controls.UserLantern();
            this.userLantern2 = new HslCommunication.Controls.UserLantern();
            this.userButton1 = new HslCommunication.Controls.UserButton();
            this.userButton2 = new HslCommunication.Controls.UserButton();
            this.userButton3 = new HslCommunication.Controls.UserButton();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel5.SuspendLayout();
            this.SuspendLayout();
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(274, 61);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 17);
            this.label3.TabIndex = 11;
            this.label3.Text = "禁用状态";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(137, 61);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 17);
            this.label2.TabIndex = 10;
            this.label2.Text = "选中模式";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 61);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(56, 17);
            this.label1.TabIndex = 9;
            this.label1.Text = "基础按钮";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(3, 180);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(188, 17);
            this.label8.TabIndex = 27;
            this.label8.Text = "状态灯控件，目前只有简单的颜色";
            // 
            // panel1
            // 
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel1.Controls.Add(this.userButton1);
            this.panel1.Controls.Add(this.userButton2);
            this.panel1.Controls.Add(this.userButton3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Location = new System.Drawing.Point(14, 16);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(533, 99);
            this.panel1.TabIndex = 28;
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.label4);
            this.panel2.Controls.Add(this.userLantern3);
            this.panel2.Controls.Add(this.userLantern1);
            this.panel2.Controls.Add(this.userLantern2);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(556, 16);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(436, 217);
            this.panel2.TabIndex = 29;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(327, 159);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(32, 17);
            this.label4.TabIndex = 29;
            this.label4.Text = "闪烁";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(315, 297);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 17);
            this.label5.TabIndex = 31;
            this.label5.Text = "时钟控件";
            // 
            // panel3
            // 
            this.panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel3.Controls.Add(this.userDrum1);
            this.panel3.Controls.Add(this.label10);
            this.panel3.Controls.Add(this.button1);
            this.panel3.Controls.Add(this.userClock1);
            this.panel3.Controls.Add(this.label5);
            this.panel3.Location = new System.Drawing.Point(556, 239);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(436, 394);
            this.panel3.TabIndex = 32;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(69, 297);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 17);
            this.label10.TabIndex = 34;
            this.label10.Text = "罐子控件";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(300, 341);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(123, 38);
            this.button1.TabIndex = 32;
            this.button1.Text = "右下角弹窗";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(154, 204);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(159, 17);
            this.label9.TabIndex = 35;
            this.label9.Text = "旋转开关控件，只有2个状态";
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.Control;
            this.panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel4.Controls.Add(this.userBottle1);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.userSwitch1);
            this.panel4.Controls.Add(this.userSwitch2);
            this.panel4.Location = new System.Drawing.Point(14, 397);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(536, 236);
            this.panel4.TabIndex = 36;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(13, 242);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(284, 17);
            this.label6.TabIndex = 43;
            this.label6.Text = "进度条控件，允许设置背景，文本，还有简单的动画";
            // 
            // panel5
            // 
            this.panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel5.Controls.Add(this.userVerticalProgress8);
            this.panel5.Controls.Add(this.label7);
            this.panel5.Controls.Add(this.userVerticalProgress7);
            this.panel5.Controls.Add(this.userVerticalProgress1);
            this.panel5.Controls.Add(this.label6);
            this.panel5.Controls.Add(this.userVerticalProgress2);
            this.panel5.Controls.Add(this.userVerticalProgress6);
            this.panel5.Controls.Add(this.userVerticalProgress3);
            this.panel5.Controls.Add(this.userVerticalProgress5);
            this.panel5.Controls.Add(this.userVerticalProgress4);
            this.panel5.Location = new System.Drawing.Point(14, 121);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(536, 270);
            this.panel5.TabIndex = 44;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(479, 239);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(32, 17);
            this.label7.TabIndex = 45;
            this.label7.Text = "随机";
            // 
            // userVerticalProgress8
            // 
            this.userVerticalProgress8.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress8.BorderColor = System.Drawing.Color.Blue;
            this.userVerticalProgress8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress8.Location = new System.Drawing.Point(430, 16);
            this.userVerticalProgress8.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress8.Name = "userVerticalProgress8";
            this.userVerticalProgress8.Size = new System.Drawing.Size(33, 216);
            this.userVerticalProgress8.TabIndex = 46;
            this.userVerticalProgress8.Value = 50;
            // 
            // userVerticalProgress7
            // 
            this.userVerticalProgress7.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress7.BorderColor = System.Drawing.Color.Blue;
            this.userVerticalProgress7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress7.Location = new System.Drawing.Point(479, 16);
            this.userVerticalProgress7.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress7.Name = "userVerticalProgress7";
            this.userVerticalProgress7.Size = new System.Drawing.Size(33, 216);
            this.userVerticalProgress7.TabIndex = 44;
            this.userVerticalProgress7.UseAnimation = true;
            this.userVerticalProgress7.Value = 50;
            // 
            // userVerticalProgress1
            // 
            this.userVerticalProgress1.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress1.Location = new System.Drawing.Point(15, 16);
            this.userVerticalProgress1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress1.Name = "userVerticalProgress1";
            this.userVerticalProgress1.Size = new System.Drawing.Size(51, 216);
            this.userVerticalProgress1.TabIndex = 37;
            this.userVerticalProgress1.Value = 50;
            // 
            // userVerticalProgress2
            // 
            this.userVerticalProgress2.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress2.IsTextRender = false;
            this.userVerticalProgress2.Location = new System.Drawing.Point(72, 16);
            this.userVerticalProgress2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress2.Name = "userVerticalProgress2";
            this.userVerticalProgress2.Size = new System.Drawing.Size(42, 216);
            this.userVerticalProgress2.TabIndex = 38;
            this.userVerticalProgress2.Value = 50;
            // 
            // userVerticalProgress6
            // 
            this.userVerticalProgress6.BackColor = System.Drawing.Color.Blue;
            this.userVerticalProgress6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress6.Location = new System.Drawing.Point(216, 45);
            this.userVerticalProgress6.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress6.Name = "userVerticalProgress6";
            this.userVerticalProgress6.ProgressStyle = HslCommunication.Controls.ProgressStyle.Horizontal;
            this.userVerticalProgress6.Size = new System.Drawing.Size(191, 29);
            this.userVerticalProgress6.TabIndex = 42;
            this.userVerticalProgress6.Value = 80;
            // 
            // userVerticalProgress3
            // 
            this.userVerticalProgress3.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress3.Location = new System.Drawing.Point(120, 16);
            this.userVerticalProgress3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress3.Name = "userVerticalProgress3";
            this.userVerticalProgress3.ProgressColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.userVerticalProgress3.Size = new System.Drawing.Size(42, 216);
            this.userVerticalProgress3.TabIndex = 39;
            this.userVerticalProgress3.Value = 50;
            // 
            // userVerticalProgress5
            // 
            this.userVerticalProgress5.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress5.Location = new System.Drawing.Point(216, 16);
            this.userVerticalProgress5.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress5.Name = "userVerticalProgress5";
            this.userVerticalProgress5.ProgressStyle = HslCommunication.Controls.ProgressStyle.Horizontal;
            this.userVerticalProgress5.Size = new System.Drawing.Size(191, 28);
            this.userVerticalProgress5.TabIndex = 41;
            this.userVerticalProgress5.Value = 50;
            // 
            // userVerticalProgress4
            // 
            this.userVerticalProgress4.BackColor = System.Drawing.SystemColors.Control;
            this.userVerticalProgress4.BorderColor = System.Drawing.Color.Blue;
            this.userVerticalProgress4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userVerticalProgress4.Location = new System.Drawing.Point(168, 16);
            this.userVerticalProgress4.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userVerticalProgress4.Name = "userVerticalProgress4";
            this.userVerticalProgress4.Size = new System.Drawing.Size(42, 216);
            this.userVerticalProgress4.TabIndex = 40;
            this.userVerticalProgress4.Value = 50;
            // 
            // userBottle1
            // 
            this.userBottle1.BackColor = System.Drawing.Color.Transparent;
            this.userBottle1.BottleTag = "1#";
            this.userBottle1.HeadTag = "1#";
            this.userBottle1.IsOpen = true;
            this.userBottle1.Location = new System.Drawing.Point(442, 17);
            this.userBottle1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userBottle1.Name = "userBottle1";
            this.userBottle1.Size = new System.Drawing.Size(45, 180);
            this.userBottle1.TabIndex = 36;
            this.userBottle1.Value = 20D;
            // 
            // userSwitch1
            // 
            this.userSwitch1.BackColor = System.Drawing.Color.Transparent;
            this.userSwitch1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.userSwitch1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userSwitch1.Location = new System.Drawing.Point(34, 17);
            this.userSwitch1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userSwitch1.Name = "userSwitch1";
            this.userSwitch1.Size = new System.Drawing.Size(197, 204);
            this.userSwitch1.SwitchForeground = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.userSwitch1.SwitchStatusDescription = new string[] {
        "Off",
        "On"};
            this.userSwitch1.TabIndex = 33;
            // 
            // userSwitch2
            // 
            this.userSwitch2.BackColor = System.Drawing.Color.Transparent;
            this.userSwitch2.Cursor = System.Windows.Forms.Cursors.Hand;
            this.userSwitch2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userSwitch2.Location = new System.Drawing.Point(224, 12);
            this.userSwitch2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userSwitch2.Name = "userSwitch2";
            this.userSwitch2.Size = new System.Drawing.Size(197, 204);
            this.userSwitch2.SwitchForeground = System.Drawing.Color.FromArgb(((int)(((byte)(36)))), ((int)(((byte)(36)))), ((int)(((byte)(36)))));
            this.userSwitch2.SwitchStatus = true;
            this.userSwitch2.SwitchStatusDescription = new string[] {
        "Off",
        "On"};
            this.userSwitch2.TabIndex = 34;
            // 
            // userDrum1
            // 
            this.userDrum1.BackColor = System.Drawing.Color.Transparent;
            this.userDrum1.BorderColor = System.Drawing.Color.Red;
            this.userDrum1.DrumBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.userDrum1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userDrum1.Location = new System.Drawing.Point(26, 22);
            this.userDrum1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userDrum1.Name = "userDrum1";
            this.userDrum1.Size = new System.Drawing.Size(149, 223);
            this.userDrum1.TabIndex = 35;
            this.userDrum1.Text = "userDrum1";
            // 
            // userClock1
            // 
            this.userClock1.BackColor = System.Drawing.Color.Transparent;
            this.userClock1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("userClock1.BackgroundImage")));
            this.userClock1.Font = new System.Drawing.Font("Courier New", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.userClock1.Location = new System.Drawing.Point(187, 3);
            this.userClock1.Name = "userClock1";
            this.userClock1.Size = new System.Drawing.Size(236, 259);
            this.userClock1.TabIndex = 30;
            // 
            // userLantern3
            // 
            this.userLantern3.BackColor = System.Drawing.Color.Transparent;
            this.userLantern3.LanternBackground = System.Drawing.Color.Tomato;
            this.userLantern3.Location = new System.Drawing.Point(280, 18);
            this.userLantern3.Margin = new System.Windows.Forms.Padding(3, 6, 3, 6);
            this.userLantern3.Name = "userLantern3";
            this.userLantern3.Size = new System.Drawing.Size(143, 135);
            this.userLantern3.TabIndex = 28;
            // 
            // userLantern1
            // 
            this.userLantern1.BackColor = System.Drawing.Color.Transparent;
            this.userLantern1.Location = new System.Drawing.Point(3, 4);
            this.userLantern1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userLantern1.Name = "userLantern1";
            this.userLantern1.Size = new System.Drawing.Size(142, 152);
            this.userLantern1.TabIndex = 25;
            // 
            // userLantern2
            // 
            this.userLantern2.BackColor = System.Drawing.Color.Transparent;
            this.userLantern2.LanternBackground = System.Drawing.Color.Tomato;
            this.userLantern2.Location = new System.Drawing.Point(165, 18);
            this.userLantern2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userLantern2.Name = "userLantern2";
            this.userLantern2.Size = new System.Drawing.Size(100, 101);
            this.userLantern2.TabIndex = 26;
            // 
            // userButton1
            // 
            this.userButton1.BackColor = System.Drawing.Color.Transparent;
            this.userButton1.CustomerInformation = "";
            this.userButton1.EnableColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.userButton1.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.userButton1.Location = new System.Drawing.Point(15, 18);
            this.userButton1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userButton1.Name = "userButton1";
            this.userButton1.Size = new System.Drawing.Size(118, 39);
            this.userButton1.TabIndex = 6;
            // 
            // userButton2
            // 
            this.userButton2.BackColor = System.Drawing.Color.Transparent;
            this.userButton2.CustomerInformation = "";
            this.userButton2.EnableColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.userButton2.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.userButton2.Location = new System.Drawing.Point(139, 18);
            this.userButton2.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userButton2.Name = "userButton2";
            this.userButton2.Selected = true;
            this.userButton2.Size = new System.Drawing.Size(131, 39);
            this.userButton2.TabIndex = 7;
            // 
            // userButton3
            // 
            this.userButton3.BackColor = System.Drawing.Color.Transparent;
            this.userButton3.CustomerInformation = "";
            this.userButton3.EnableColor = System.Drawing.Color.FromArgb(((int)(((byte)(190)))), ((int)(((byte)(190)))), ((int)(((byte)(190)))));
            this.userButton3.Enabled = false;
            this.userButton3.Font = new System.Drawing.Font("微软雅黑", 9F);
            this.userButton3.Location = new System.Drawing.Point(276, 19);
            this.userButton3.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.userButton3.Name = "userButton3";
            this.userButton3.Size = new System.Drawing.Size(131, 39);
            this.userButton3.TabIndex = 8;
            // 
            // FormBasicControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1004, 645);
            this.Controls.Add(this.panel5);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel3);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "FormBasicControl";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "FormBasicControl";
            this.Load += new System.EventHandler(this.FormBasicControl_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private HslCommunication.Controls.UserButton userButton3;
        private HslCommunication.Controls.UserButton userButton2;
        private HslCommunication.Controls.UserButton userButton1;
        private System.Windows.Forms.Label label8;
        private HslCommunication.Controls.UserLantern userLantern2;
        private HslCommunication.Controls.UserLantern userLantern1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private HslCommunication.Controls.UserClock userClock1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label9;
        private HslCommunication.Controls.UserSwitch userSwitch2;
        private HslCommunication.Controls.UserSwitch userSwitch1;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label6;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress6;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress5;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress4;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress3;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress2;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress1;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Label label7;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress7;
        private HslCommunication.Controls.UserLantern userLantern3;
        private HslCommunication.Controls.UserVerticalProgress userVerticalProgress8;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label10;
        private HslCommunication.Controls.UserDrum userDrum1;
        private HslCommunication.Controls.UserBottle userBottle1;
    }
}