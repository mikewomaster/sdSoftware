﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using HslCommunication.BasicFramework;
using HslCommunication.Core;
using HslCommunication.Core.Net;
using HslCommunication.Core.IMessage;
using HslCommunication.Core.Address;
using HslCommunication.Reflection;

namespace HslCommunication.Profinet.Melsec
{
	/// <summary>
	/// <b>[商业授权]</b> 三菱MC协议的虚拟服务器，支持M,X,Y,D,W的数据池读写操作，支持二进制及ASCII格式进行读写操作，需要在实例化的时候指定。<br />
	/// <b>[Authorization]</b> The Mitsubishi MC protocol virtual server supports M, X, Y, D, W data pool read and write operations, 
	/// and supports binary and ASCII format read and write operations, which need to be specified during instantiation.
	/// </summary>
	/// <remarks>
	/// 本三菱的虚拟PLC仅限商业授权用户使用，感谢支持。
	/// 如果你没有可以测试的三菱PLC，想要测试自己开发的上位机软件，或是想要在本机实现虚拟PLC，然后进行IO的输入输出练习，都可以使用本类来实现，先来说明下地址信息
	/// <br />
	/// 地址的输入的格式说明如下：
	/// <list type="table">
	///   <listheader>
	///     <term>地址名称</term>
	///     <term>地址代号</term>
	///     <term>示例</term>
	///     <term>地址进制</term>
	///     <term>字操作</term>
	///     <term>位操作</term>
	///     <term>备注</term>
	///   </listheader>
	///   <item>
	///     <term>内部继电器</term>
	///     <term>M</term>
	///     <term>M100,M200</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>输入继电器</term>
	///     <term>X</term>
	///     <term>X100,X1A0</term>
	///     <term>16</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>输出继电器</term>
	///     <term>Y</term>
	///     <term>Y100,Y1A0</term>
	///     <term>16</term>
	///     <term>√</term>
	///     <term>√</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>数据寄存器</term>
	///     <term>D</term>
	///     <term>D1000,D2000</term>
	///     <term>10</term>
	///     <term>√</term>
	///     <term>×</term>
	///     <term></term>
	///   </item>
	///   <item>
	///     <term>链接寄存器</term>
	///     <term>W</term>
	///     <term>W100,W1A0</term>
	///     <term>16</term>
	///     <term>√</term>
	///     <term>×</term>
	///     <term></term>
	///   </item>
	/// </list>
	/// </remarks>
	public class MelsecMcServer : NetworkDataServerBase
	{
		#region Constructor

		/// <summary>
		/// 实例化一个默认参数的mc协议的服务器<br />
		/// Instantiate a mc protocol server with default parameters
		/// </summary>
		/// <param name="isBinary">是否是二进制，默认是二进制，否则是ASCII格式</param>
		public MelsecMcServer( bool isBinary = true )
		{
			// 共计使用了五个数据池
			xBuffer = new SoftBuffer( DataPoolLength );
			yBuffer = new SoftBuffer( DataPoolLength );
			mBuffer = new SoftBuffer( DataPoolLength );
			dBuffer = new SoftBuffer( DataPoolLength * 2 );
			wBuffer = new SoftBuffer( DataPoolLength * 2 );

			WordLength = 1;
			ByteTransform = new RegularByteTransform( );
			this.isBinary = isBinary;
		}

		#endregion

		#region NetworkDataServerBase Override

		/// <inheritdoc/>
		[HslMqttApi( "ReadByteArray", "" )]
		public override OperateResult<byte[]> Read( string address, ushort length )
		{
			// 分析地址
			OperateResult<McAddressData> analysis = McAddressData.ParseMelsecFrom( address, length );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( analysis );

			if(analysis.Content.McDataType.DataCode == MelsecMcDataType.M.DataCode)
			{
				bool[] buffer = mBuffer.GetBytes( analysis.Content.AddressStart, length * 16 ).Select( m => m != 0x00 ).ToArray( );
				return OperateResult.CreateSuccessResult( SoftBasic.BoolArrayToByte( buffer ) );
			}
			else if(analysis.Content.McDataType.DataCode == MelsecMcDataType.X.DataCode)
			{
				bool[] buffer = xBuffer.GetBytes( analysis.Content.AddressStart, length * 16 ).Select( m => m != 0x00 ).ToArray( );
				return OperateResult.CreateSuccessResult( SoftBasic.BoolArrayToByte( buffer ) );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.Y.DataCode)
			{
				bool[] buffer = yBuffer.GetBytes( analysis.Content.AddressStart, length * 16 ).Select( m => m != 0x00 ).ToArray( );
				return OperateResult.CreateSuccessResult( SoftBasic.BoolArrayToByte( buffer ) );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.D.DataCode)
			{
				return OperateResult.CreateSuccessResult( dBuffer.GetBytes( analysis.Content.AddressStart * 2, length * 2 ) );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.W.DataCode)
			{
				return OperateResult.CreateSuccessResult( wBuffer.GetBytes( analysis.Content.AddressStart * 2, length * 2 ) );
			}
			else
			{
				return new OperateResult<byte[]>( StringResources.Language.NotSupportedDataType );
			}
		}

		/// <inheritdoc/>
		[HslMqttApi( "WriteByteArray", "" )]
		public override OperateResult Write( string address, byte[] value )
		{
			// 分析地址
			OperateResult<McAddressData> analysis = McAddressData.ParseMelsecFrom( address, 0 );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( analysis );

			if (analysis.Content.McDataType.DataCode == MelsecMcDataType.M.DataCode)
			{
				byte[] buffer = SoftBasic.ByteToBoolArray( value ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
				mBuffer.SetBytes( buffer, analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.X.DataCode)
			{
				byte[] buffer = SoftBasic.ByteToBoolArray( value ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
				xBuffer.SetBytes( buffer, analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.Y.DataCode)
			{
				byte[] buffer = SoftBasic.ByteToBoolArray( value ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
				yBuffer.SetBytes( buffer, analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.D.DataCode)
			{
				dBuffer.SetBytes( value, analysis.Content.AddressStart * 2 );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.W.DataCode)
			{
				wBuffer.SetBytes( value, analysis.Content.AddressStart * 2 );
				return OperateResult.CreateSuccessResult( );
			}
			else
			{
				return new OperateResult<byte[]>( StringResources.Language.NotSupportedDataType );
			}
		}

		#endregion

		#region Bool Read Write Operate

		/// <inheritdoc/>
		[HslMqttApi( "ReadBoolArray", "" )]
		public override OperateResult<bool[]> ReadBool( string address, ushort length )
		{
			// 分析地址
			OperateResult<McAddressData> analysis = McAddressData.ParseMelsecFrom( address, 0 );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( analysis );

			if (analysis.Content.McDataType.DataType == 0) return new OperateResult<bool[]>( StringResources.Language.MelsecCurrentTypeNotSupportedWordOperate );

			if (analysis.Content.McDataType.DataCode == MelsecMcDataType.M.DataCode)
				return OperateResult.CreateSuccessResult( mBuffer.GetBytes( analysis.Content.AddressStart, length ).Select( m => m != 0x00 ).ToArray( ) );
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.X.DataCode)
				return OperateResult.CreateSuccessResult( xBuffer.GetBytes( analysis.Content.AddressStart, length ).Select( m => m != 0x00 ).ToArray( ) );
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.Y.DataCode)
				return OperateResult.CreateSuccessResult( yBuffer.GetBytes( analysis.Content.AddressStart, length ).Select( m => m != 0x00 ).ToArray( ) );
			else
				return new OperateResult<bool[]>( StringResources.Language.NotSupportedDataType );
		}

		/// <inheritdoc/>
		[HslMqttApi( "WriteBoolArray", "" )]
		public override OperateResult Write( string address, bool[] value )
		{
			// 分析地址
			OperateResult<McAddressData> analysis = McAddressData.ParseMelsecFrom( address, 0 );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<bool[]>( analysis );

			if (analysis.Content.McDataType.DataType == 0) return new OperateResult<bool[]>( StringResources.Language.MelsecCurrentTypeNotSupportedWordOperate );

			if (analysis.Content.McDataType.DataCode == MelsecMcDataType.M.DataCode)
			{
				mBuffer.SetBytes( value.Select( m => m ? (byte)1 : (byte)0 ).ToArray( ), analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.X.DataCode)
			{
				xBuffer.SetBytes( value.Select( m => m ? (byte)1 : (byte)0 ).ToArray( ), analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else if (analysis.Content.McDataType.DataCode == MelsecMcDataType.Y.DataCode)
			{
				yBuffer.SetBytes( value.Select( m => m ? (byte)1 : (byte)0 ).ToArray( ), analysis.Content.AddressStart );
				return OperateResult.CreateSuccessResult( );
			}
			else
			{
				return new OperateResult<bool[]>( StringResources.Language.NotSupportedDataType );
			}
		}

		#endregion

		#region NetServer Override

		/// <inheritdoc/>
		protected override void ThreadPoolLoginAfterClientCheck( Socket socket, System.Net.IPEndPoint endPoint )
		{
			// 开始接收数据信息
			AppSession appSession = new AppSession( );
			appSession.IpEndPoint = endPoint;
			appSession.WorkSocket = socket;
			try
			{
				socket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketAsyncCallBack ), appSession );
				AddClient( appSession );
			}
			catch
			{
				socket.Close( );
				LogNet?.WriteDebug( ToString( ), string.Format( StringResources.Language.ClientOfflineInfo, endPoint ) );
			}
		}

		private void SocketAsyncCallBack( IAsyncResult ar )
		{
			if (ar.AsyncState is AppSession session)
			{
				try
				{
					int receiveCount = session.WorkSocket.EndReceive( ar );
					byte[] back = null;
					OperateResult<byte[]> read1;

					if (!Authorization.asdniasnfaksndiqwhawfskhfaiw( )) { RemoveClient( session ); return; };

					if (isBinary)
					{
						read1 = ReceiveByMessage( session.WorkSocket, 5000, new MelsecQnA3EBinaryMessage( ) );
						if (!read1.IsSuccess) { RemoveClient( session ); return; };

						back = ReadFromMcCore( read1.Content.RemoveBegin( 11 ) );
					}
					else
					{
						read1 = ReceiveByMessage( session.WorkSocket, 5000, new MelsecQnA3EAsciiMessage( ) );
						if (!read1.IsSuccess) { RemoveClient( session ); return; };

						back = ReadFromMcAsciiCore( read1.Content.RemoveBegin( 22 ) );
					}

					LogNet?.WriteDebug( ToString( ), $"Tcp {StringResources.Language.Receive}：{(this.isBinary ? read1.Content.ToHexString( ' ' ) : Encoding.ASCII.GetString( read1.Content ))}" );

					if (back != null)
					{
						session.WorkSocket.Send( back );
						LogNet?.WriteDebug( ToString( ), $"Tcp {StringResources.Language.Send}：{(this.isBinary ? back.ToHexString( ' ' ) : Encoding.ASCII.GetString( back ))}" );
					}
					else
					{
						RemoveClient( session );
						return;
					}

					session.HeartTime = DateTime.Now;
					RaiseDataReceived( read1.Content );
					session.WorkSocket.BeginReceive( new byte[0], 0, 0, SocketFlags.None, new AsyncCallback( SocketAsyncCallBack ), session );
				}
				catch
				{
					RemoveClient( session );
				}
			}
		}

		/// <summary>
		/// 当收到mc协议的报文的时候应该触发的方法，允许继承重写，来实现自定义的返回，或是数据监听。<br />
		/// The method that should be triggered when a message of the mc protocol is received, 
		/// allowing inheritance to be rewritten to implement custom return or data monitoring.
		/// </summary>
		/// <param name="mcCore">mc报文</param>
		/// <returns>返回的报文信息</returns>
		protected virtual byte[] ReadFromMcCore( byte[] mcCore )
		{
			if (mcCore[0] == 0x01 && mcCore[1] == 0x04)      return PackCommand( ReadByCommand(  mcCore ) ); // 读数据
			else if (mcCore[0] == 0x01 && mcCore[1] == 0x14) return PackCommand( WriteByMessage( mcCore ) ); // 写数据
			else return null;
		}

		/// <summary>
		/// 当收到mc协议的报文的时候应该触发的方法，允许继承重写，来实现自定义的返回，或是数据监听。<br />
		/// The method that should be triggered when a message of the mc protocol is received, 
		/// allowing inheritance to be rewritten to implement custom return or data monitoring.
		/// </summary>
		/// <param name="mcCore">mc报文</param>
		/// <returns>返回的报文信息</returns>
		protected virtual byte[] ReadFromMcAsciiCore( byte[] mcCore )
		{
			if (mcCore[0] == 0x30 && mcCore[1] == 0x34 && mcCore[2] == 0x30 && mcCore[3] == 0x31)
				return PackCommand( ReadAsciiByCommand( mcCore ) );
			else if (mcCore[0] == 0x31 && mcCore[1] == 0x34 && mcCore[2] == 0x30 && mcCore[3] == 0x31)
				return PackCommand( WriteAsciiByMessage( mcCore ) );
			else
				return null;
		}

		private byte[] PackCommand( byte[] data )
		{
			if (isBinary)
			{
				byte[] back = new byte[11 + data.Length];
				SoftBasic.HexStringToBytes( "D0 00 00 FF FF 03 00 00 00 00 00" ).CopyTo( back, 0 );
				if (data.Length > 0) data.CopyTo( back, 11 );

				BitConverter.GetBytes( (short)(data.Length + 2) ).CopyTo( back, 7 );
				return back;
			}
			else
			{
				byte[] back = new byte[22 + data.Length];
				Encoding.ASCII.GetBytes( "D00000FF03FF0000000000" ).CopyTo( back, 0 );
				if (data.Length > 0) data.CopyTo( back, 22 );

				Encoding.ASCII.GetBytes( (data.Length + 4).ToString( "X4" ) ).CopyTo( back, 14 );
				return back;
			}
		}

		private byte[] ReadByCommand( byte[] command )
		{
			ushort length = ByteTransform.TransUInt16( command, 8 );
			int startIndex = (command[6] * 65536 + command[5] * 256 + command[4]);

			if (command[2] == 0x01)
			{
				// 位读取
				if (     command[7] == MelsecMcDataType.M.DataCode) return MelsecHelper.TransBoolArrayToByteData( mBuffer.GetBytes( startIndex, length ) );
				else if (command[7] == MelsecMcDataType.X.DataCode) return MelsecHelper.TransBoolArrayToByteData( xBuffer.GetBytes( startIndex, length ) );
				else if (command[7] == MelsecMcDataType.Y.DataCode) return MelsecHelper.TransBoolArrayToByteData( yBuffer.GetBytes( startIndex, length ) );
				else throw new Exception( StringResources.Language.NotSupportedDataType );
			}
			else
			{
				// 字读取
				if (command[7] == MelsecMcDataType.M.DataCode)
					return mBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( ).ToByteArray( );
				else if(command[7] == MelsecMcDataType.X.DataCode)
					return xBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( ).ToByteArray( );
				else if (command[7] == MelsecMcDataType.Y.DataCode)
					return yBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( ).ToByteArray( );
				else if (command[7] == MelsecMcDataType.D.DataCode)
					return dBuffer.GetBytes( startIndex * 2, length * 2 );
				else if (command[7] == MelsecMcDataType.W.DataCode)
					return wBuffer.GetBytes( startIndex * 2, length * 2 );
				else
					throw new Exception( StringResources.Language.NotSupportedDataType );
			}
		}

		private byte[] ReadAsciiByCommand( byte[] command )
		{
			ushort length = Convert.ToUInt16( Encoding.ASCII.GetString( command, 16, 4 ), 16 );
			string typeCode = Encoding.ASCII.GetString( command, 8, 2 );
			int startIndex = 0;
			if(typeCode == MelsecMcDataType.X.AsciiCode || typeCode == MelsecMcDataType.Y.AsciiCode || typeCode == MelsecMcDataType.W.AsciiCode)
				startIndex = Convert.ToUInt16( Encoding.ASCII.GetString( command, 10, 6 ), 16 );
			else
				startIndex = Convert.ToUInt16( Encoding.ASCII.GetString( command, 10, 6 ) );

			if (command[7] == 0x31)
			{
				// 位读取
				if (typeCode == MelsecMcDataType.M.AsciiCode)
					return mBuffer.GetBytes( startIndex, length ).Select( m => m != 0x00 ? (byte)0x31 : (byte)0x30 ).ToArray( );
				else if (typeCode == MelsecMcDataType.X.AsciiCode)
					return xBuffer.GetBytes( startIndex, length ).Select( m => m != 0x00 ? (byte)0x31 : (byte)0x30 ).ToArray( );
				else if (typeCode == MelsecMcDataType.Y.AsciiCode)
					return yBuffer.GetBytes( startIndex, length ).Select( m => m != 0x00 ? (byte)0x31 : (byte)0x30 ).ToArray( );
				else
					throw new Exception( StringResources.Language.NotSupportedDataType );
			}
			else
			{
				// 字读取
				if (typeCode == MelsecMcDataType.M.AsciiCode)
				{
					bool[] buffer = mBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( );
					return MelsecHelper.TransByteArrayToAsciiByteArray( SoftBasic.BoolArrayToByte( buffer ) );
				}
				else if (typeCode == MelsecMcDataType.X.AsciiCode)
				{
					bool[] buffer = xBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( );
					return MelsecHelper.TransByteArrayToAsciiByteArray( SoftBasic.BoolArrayToByte( buffer ) );
				}
				else if (typeCode == MelsecMcDataType.Y.AsciiCode)
				{
					bool[] buffer = yBuffer.GetBytes( startIndex, length * 16 ).Select( m => m != 0x00 ).ToArray( );
					return MelsecHelper.TransByteArrayToAsciiByteArray( SoftBasic.BoolArrayToByte( buffer ) );
				}
				else if (typeCode == MelsecMcDataType.D.AsciiCode) return MelsecHelper.TransByteArrayToAsciiByteArray( dBuffer.GetBytes( startIndex * 2, length * 2 ) );
				else if (typeCode == MelsecMcDataType.W.AsciiCode) return MelsecHelper.TransByteArrayToAsciiByteArray( wBuffer.GetBytes( startIndex * 2, length * 2 ) );
				else throw new Exception( StringResources.Language.NotSupportedDataType );
			}
		}

		private byte[] WriteByMessage( byte[] command )
		{
			ushort length = ByteTransform.TransUInt16( command, 8 );
			int startIndex = command[6] * 65536 + command[5] * 256 + command[4];
			if (command[2] == 0x01)
			{
				// 位写入
				byte[] buffer = MelsecMcNet.ExtractActualData( command.RemoveBegin( 10 ), true ).Content;

				if (     command[7] == MelsecMcDataType.M.DataCode) mBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else if (command[7] == MelsecMcDataType.X.DataCode) xBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else if (command[7] == MelsecMcDataType.Y.DataCode) yBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else throw new Exception( StringResources.Language.NotSupportedDataType );

				return new byte[0];
			}
			else
			{
				// 字写入
				if (command[7] == MelsecMcDataType.M.DataCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( SoftBasic.ArrayRemoveBegin( command, 10 ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					mBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (command[7] == MelsecMcDataType.X.DataCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( SoftBasic.ArrayRemoveBegin( command, 10 ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					xBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (command[7] == MelsecMcDataType.Y.DataCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( SoftBasic.ArrayRemoveBegin( command, 10 ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					yBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (command[7] == MelsecMcDataType.D.DataCode)
				{
					dBuffer.SetBytes( SoftBasic.ArrayRemoveBegin( command, 10 ), startIndex * 2 );
					return new byte[0];
				}
				else if (command[7] == MelsecMcDataType.W.DataCode)
				{
					wBuffer.SetBytes( SoftBasic.ArrayRemoveBegin( command, 10 ), startIndex * 2 );
					return new byte[0];
				}
				else
				{
					throw new Exception( StringResources.Language.NotSupportedDataType );
				}
			}
		}

		private byte[] WriteAsciiByMessage( byte[] command )
		{
			ushort length = Convert.ToUInt16( Encoding.ASCII.GetString( command, 16, 4 ), 16 );
			string typeCode = Encoding.ASCII.GetString( command, 8, 2 );
			int startIndex = 0;
			if (typeCode == MelsecMcDataType.X.AsciiCode || typeCode == MelsecMcDataType.Y.AsciiCode || typeCode == MelsecMcDataType.W.AsciiCode)
				startIndex = Convert.ToUInt16( Encoding.ASCII.GetString( command, 10, 6 ), 16 );
			else
				startIndex = Convert.ToUInt16( Encoding.ASCII.GetString( command, 10, 6 ) );

			if (command[7] == 0x31)
			{
				// 位写入
				byte[] buffer = command.RemoveBegin( 20 ).Select( m => m == 0x31 ? (byte)1 : (byte)0 ).ToArray( );

				if (     typeCode == MelsecMcDataType.M.AsciiCode) mBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else if (typeCode == MelsecMcDataType.X.AsciiCode) xBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else if (typeCode == MelsecMcDataType.Y.AsciiCode) yBuffer.SetBytes( buffer.Take( length ).ToArray( ), startIndex );
				else throw new Exception( StringResources.Language.NotSupportedDataType );

				return new byte[0];
			}
			else
			{
				// 字写入
				if (typeCode == MelsecMcDataType.M.AsciiCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( MelsecHelper.TransAsciiByteArrayToByteArray( command.RemoveBegin(20) ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					mBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (typeCode == MelsecMcDataType.X.AsciiCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( MelsecHelper.TransAsciiByteArrayToByteArray( command.RemoveBegin( 20 ) ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					xBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (typeCode == MelsecMcDataType.Y.AsciiCode)
				{
					byte[] buffer = SoftBasic.ByteToBoolArray( MelsecHelper.TransAsciiByteArrayToByteArray( command.RemoveBegin( 20 ) ) ).Select( m => m ? (byte)1 : (byte)0 ).ToArray( );
					yBuffer.SetBytes( buffer, startIndex );
					return new byte[0];
				}
				else if (typeCode == MelsecMcDataType.D.AsciiCode)
				{
					dBuffer.SetBytes( MelsecHelper.TransAsciiByteArrayToByteArray( command.RemoveBegin( 20 ) ), startIndex * 2 );
					return new byte[0];
				}
				else if (typeCode == MelsecMcDataType.W.AsciiCode)
				{
					wBuffer.SetBytes( MelsecHelper.TransAsciiByteArrayToByteArray( command.RemoveBegin( 20 ) ), startIndex * 2 );
					return new byte[0];
				}
				else
				{
					throw new Exception( StringResources.Language.NotSupportedDataType );
				}
			}
		}

		#endregion

		#region Data Save Load Override

		/// <inheritdoc/>
		protected override void LoadFromBytes( byte[] content )
		{
			if (content.Length < DataPoolLength * 7) throw new Exception( "File is not correct" );

			mBuffer.SetBytes( content, DataPoolLength * 0, 0, DataPoolLength );
			xBuffer.SetBytes( content, DataPoolLength * 1, 0, DataPoolLength );
			yBuffer.SetBytes( content, DataPoolLength * 2, 0, DataPoolLength );
			dBuffer.SetBytes( content, DataPoolLength * 3, 0, DataPoolLength * 2 );
			wBuffer.SetBytes( content, DataPoolLength * 5, 0, DataPoolLength * 2 );
		}

		/// <inheritdoc/>
		[HslMqttApi]
		protected override byte[] SaveToBytes( )
		{
			byte[] buffer = new byte[DataPoolLength * 7];
			Array.Copy( mBuffer.GetBytes( ), 0, buffer, DataPoolLength * 0, DataPoolLength );
			Array.Copy( xBuffer.GetBytes( ), 0, buffer, DataPoolLength * 1, DataPoolLength );
			Array.Copy( yBuffer.GetBytes( ), 0, buffer, DataPoolLength * 2, DataPoolLength );
			Array.Copy( dBuffer.GetBytes( ), 0, buffer, DataPoolLength * 3, DataPoolLength * 2 );
			Array.Copy( wBuffer.GetBytes( ), 0, buffer, DataPoolLength * 5, DataPoolLength * 2 );
			return buffer;
		}

		#endregion

		#region IDisposable Support

		/// <summary>
		/// 释放当前的对象
		/// </summary>
		/// <param name="disposing">是否托管对象</param>
		protected override void Dispose( bool disposing )
		{
			if (disposing)
			{
				xBuffer?.Dispose( );
				yBuffer?.Dispose( );
				mBuffer?.Dispose( );
				dBuffer?.Dispose( );
				wBuffer?.Dispose( );
			}
			base.Dispose( disposing );
		}

		#endregion

		#region Public Properties

		/// <summary>
		/// 获取或设置当前的通信格式是否是二进制<br />
		/// Get or set whether the current communication format is binary
		/// </summary>
		public bool IsBinary
		{
			get => isBinary;
			set => isBinary = value;
		}

		#endregion

		#region Private Member

		private SoftBuffer xBuffer;                    // x寄存器的数据池
		private SoftBuffer yBuffer;                    // y寄存器的数据池
		private SoftBuffer mBuffer;                    // m寄存器的数据池
		private SoftBuffer dBuffer;                    // d寄存器的数据池
		private SoftBuffer wBuffer;                    // w寄存器的数据池

		private const int DataPoolLength = 65536;      // 数据的长度
		private bool isBinary = true;                  // 当前的服务器是否是二进制服务器

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString( ) => $"MelsecMcServer[{Port}]";

		#endregion
	}
}
