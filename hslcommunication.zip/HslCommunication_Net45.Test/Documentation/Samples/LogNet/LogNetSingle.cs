﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.LogNet;

namespace HslCommunication_Net45.Test.Documentation.Samples.LogNet
{
	class LogNetSingleTest
	{
		public void Example1( )
		{
			#region Example1

			// 实例化一个日志后，就可以使用了
			ILogNet logNet = new LogNetSingle( "D:\\123.txt" );

			#endregion
		}
		public void Example2( )
		{
			#region Example2

			// 实例化一个日志后，路径是D的一个文件夹，大小为2M
			ILogNet logNet = new LogNetFileSize( "D:\\Logs", 2 * 1024 * 1024 );

			#endregion
		}
		public void Example3( )
		{
			#region Example3

			// 实例化一个日志后，路径是D的一个文件夹，按照每天的规律来存储
			ILogNet logNet = new LogNetDateTime( "D:\\Logs", GenerateMode.ByEveryDay );

			#endregion
		}


		public void Example4( )
		{
			// 实例化一个日志后，就可以使用了
			ILogNet logNet = new LogNetSingle( "D:\\123.txt" );

			#region Example4

			// 然后我们的代码就可以调用下面的方法来存储日志了，支持下面的5个等级的
			logNet.WriteDebug( "Debug log test" );
			logNet.WriteInfo( "Info log test" );
			logNet.WriteWarn( "Warn log test" );
			logNet.WriteError( "Error log test" );
			logNet.WriteFatal( "Fatal log test" );

			// 还有下面的几种额外的情况
			logNet.WriteNewLine( );                       // 追加一行空行
			logNet.WriteDescrition( "test" );             // 写入额外的注释的信息
			logNet.WriteAnyString( "any string" );        // 写任意的数据，不受格式化影响

			// 此处的5个等级有高低之分 debug < info < warn < error < fatal < all
			// 如果我们需要屏蔽debug等级的话
			logNet.SetMessageDegree( HslMessageDegree.INFO );

			// 如果我们需要屏蔽debug及info等级的
			logNet.SetMessageDegree( HslMessageDegree.WARN );

			// 如果所有的日志在记录之前需要在控制台显示出来
			logNet.BeforeSaveToFile += (object sender, HslEventArgs e) =>
			{
				Console.WriteLine( e.HslMessage.ToString( ) );
			};

			// 带关键字的功能
			logNet.WriteDebug( "A","Debug log test" );
			logNet.WriteInfo( "B", "Info log test" );
			logNet.WriteWarn( "C", "Warn log test" );
			logNet.WriteError( "A", "Error log test" );
			logNet.WriteFatal( "B", "Fatal log test" );

			// 有了关键字之后，我们就可以根据关键字过滤了
			logNet.FiltrateKeyword( "B" ); // 我们不需要B的关键字的日志
			logNet.RemoveFiltrate( "B" );  // 重新需要B的关键字的日志

			#endregion

			#region Example5

			// 如果所有的日志在记录之前需要在控制台显示出来
			logNet.BeforeSaveToFile += ( object sender, HslEventArgs e ) =>
			{
				Console.WriteLine( e.HslMessage.ToString( ) );

				// 我们接下来举个例子，所有的日志都不存储文件
				e.HslMessage.Cancel = true;
			};

			#endregion

			#region Example6

			// 如果所有的日志在记录之前需要在控制台显示出来
			logNet.BeforeSaveToFile += ( object sender, HslEventArgs e ) =>
			{
				Console.WriteLine( e.HslMessage.ToString( ) );

				// 我们接下来举个例子，只有错误(ERROR)的等级才存储文件
				if (e.HslMessage.Degree != HslMessageDegree.ERROR)
				{
					// 这样的操作就导致，不是ERROR等级，全部不存储。但是不影响触发控制台输出
					e.HslMessage.Cancel = true;
				}
			};

			#endregion


		}

		public void Example7( )
		{
			#region Example7

			// 实例化一个日志后，如果不指定路径，那就不会存储文件，但仍然会触发BeforeSaveToFile事件
			ILogNet logNet = new LogNetSingle( "" );

			// 所有的日志在控制台显示出来
			logNet.BeforeSaveToFile += ( object sender, HslEventArgs e ) =>
			{
				Console.WriteLine( e.HslMessage.ToString( ) );
			};
			#endregion
		}
	}
}
