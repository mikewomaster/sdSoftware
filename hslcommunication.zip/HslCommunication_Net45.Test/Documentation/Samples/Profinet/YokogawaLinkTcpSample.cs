﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Profinet.Yokogawa;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.Profinet
{
    public class YokogawaLinkTcpSample
    {


        public void ClassTest( )
        {
            #region Sample1

            // 实例化对象，指定PLC的ip地址
            YokogawaLinkTcp yokogawa = new YokogawaLinkTcp( " 192.168.0.2", 12289 );
            OperateResult connect = yokogawa.ConnectServer( );
            if (connect.IsSuccess)
            {
                Console.WriteLine( "Connect plc success!" );
            }
            else
            {
                Console.WriteLine( "Connect plc failed, reason:" + connect.Message );
                return;
            }

            // 举例读取D100的值
            OperateResult<short> read = yokogawa.ReadInt16( "D100" );
            if (read.IsSuccess)
            {
                Console.WriteLine( "Read D100: " + read.Content );
            }
            else
            {
                Console.WriteLine( "Read failed, reason: " + read.Message );
                return;
            }

            // 写入的原理是一样的
            OperateResult write = yokogawa.Write( "D100", (short)100 );
            if (write.IsSuccess)
            {
                Console.WriteLine( "write plc success!" );
            }
            else
            {
                Console.WriteLine( "write failed:" + write.Message );
                return;
            }

            // 关闭连接
            yokogawa.ConnectClose( );

            #endregion
        }

        public void ClassTest2( )
        {
            // 实例化对象，指定PLC的ip地址
            YokogawaLinkTcp yokogawa = new YokogawaLinkTcp( " 192.168.0.2", 12289 );
            #region Sample2

            // 在读取的时候，可以携带CPU信息，例如
            OperateResult<short> read = yokogawa.ReadInt16( "cpu=2;D100" );
            if (read.IsSuccess)
            {
                Console.WriteLine( "Read D100: " + read.Content );
            }
            else
            {
                Console.WriteLine( "Read failed, reason: " + read.Message );
                return;
            }

            #endregion
        }



        public void ClassTest3( )
        {
            // 实例化对象，指定PLC的ip地址
            YokogawaLinkTcp yokogawa = new YokogawaLinkTcp( " 192.168.0.2", 12289 );

            #region Sample3

            // 使用随机读取的方式读取不同地址的数据信息
            OperateResult<bool[]> read = yokogawa.ReadRandomBool( new string[] { "X0", "Y100", "M200", "M1000" } );
            if (read.IsSuccess)
            {
                bool x_0 = read.Content[0];
                bool y_100 = read.Content[1];
                bool m_200 = read.Content[2];
                bool m_1000 = read.Content[3];
            }
            else
            {
                Console.WriteLine( "Read failed, reason: " + read.Message );
            }


            // 写入也是类似的
            OperateResult write = yokogawa.WriteRandomBool( new string[] { "X0", "Y100", "M200", "M1000" },
                new bool[] { true, false, false, true } );
            if (write.IsSuccess)
            {
                Console.WriteLine( "write plc success!" );
            }
            else
            {
                Console.WriteLine( "write failed:" + write.Message );
                return;
            }

            #endregion

            // 关闭连接
            yokogawa.ConnectClose( );

        }

        public void ClassTest4( )
        {
            // 实例化对象，指定PLC的ip地址
            YokogawaLinkTcp yokogawa = new YokogawaLinkTcp( " 192.168.0.2", 12289 );

            #region Sample4

            // 读取PLC的特殊模块的地址数据
            OperateResult<byte[]> read = yokogawa.ReadSpecialModule( 1, 2, 100, 2 );
            if (read.IsSuccess)
            {
                // 我们读取到了原始的数据内容
                byte[] content = read.Content;
            }
            else
            {
                Console.WriteLine( "Read failed, reason: " + read.Message );
            }


            // 我们想要读取特殊模块的short数据，上面的读取方式我们还要转换，比较麻烦，所以用下面的方式，必须 Special:开头
            OperateResult<short> readInt16 = yokogawa.ReadInt16( "Special:unit=1;slot=2;100" );
            if (readInt16.IsSuccess)
            {
                Console.WriteLine( "Read D100: " + readInt16.Content );
            }
            else
            {
                Console.WriteLine( "Read failed, reason: " + readInt16.Message );
                return;
            }

            // 写入都是类似的

            #endregion

            // 关闭连接
            yokogawa.ConnectClose( );

        }
    }
}
