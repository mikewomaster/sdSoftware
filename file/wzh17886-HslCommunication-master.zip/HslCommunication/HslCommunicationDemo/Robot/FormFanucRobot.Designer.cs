﻿namespace HslCommunicationDemo.Robot
{
    partial class FormFanucRobot
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose( bool disposing )
        {
            if (disposing && (components != null))
            {
                components.Dispose( );
            }
            base.Dispose( disposing );
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent( )
        {
			this.panel1 = new System.Windows.Forms.Panel();
			this.label2 = new System.Windows.Forms.Label();
			this.button2 = new System.Windows.Forms.Button();
			this.button1 = new System.Windows.Forms.Button();
			this.textBox2 = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.panel2 = new System.Windows.Forms.Panel();
			this.tabControl1 = new System.Windows.Forms.TabControl();
			this.tabPage1 = new System.Windows.Forms.TabPage();
			this.label4 = new System.Windows.Forms.Label();
			this.comboBox1 = new System.Windows.Forms.ComboBox();
			this.button31 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button_read_short = new System.Windows.Forms.Button();
			this.textBox8 = new System.Windows.Forms.TextBox();
			this.label42 = new System.Windows.Forms.Label();
			this.tabPage2 = new System.Windows.Forms.TabPage();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.button30 = new System.Windows.Forms.Button();
			this.button29 = new System.Windows.Forms.Button();
			this.button28 = new System.Windows.Forms.Button();
			this.button27 = new System.Windows.Forms.Button();
			this.button26 = new System.Windows.Forms.Button();
			this.button25 = new System.Windows.Forms.Button();
			this.button24 = new System.Windows.Forms.Button();
			this.button23 = new System.Windows.Forms.Button();
			this.button22 = new System.Windows.Forms.Button();
			this.button21 = new System.Windows.Forms.Button();
			this.button20 = new System.Windows.Forms.Button();
			this.button19 = new System.Windows.Forms.Button();
			this.button18 = new System.Windows.Forms.Button();
			this.button17 = new System.Windows.Forms.Button();
			this.button16 = new System.Windows.Forms.Button();
			this.button15 = new System.Windows.Forms.Button();
			this.button14 = new System.Windows.Forms.Button();
			this.button13 = new System.Windows.Forms.Button();
			this.button12 = new System.Windows.Forms.Button();
			this.button11 = new System.Windows.Forms.Button();
			this.button10 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button7 = new System.Windows.Forms.Button();
			this.button6 = new System.Windows.Forms.Button();
			this.button5 = new System.Windows.Forms.Button();
			this.textBox3 = new System.Windows.Forms.TextBox();
			this.button3 = new System.Windows.Forms.Button();
			this.userControlReadWriteOp1 = new HslCommunicationDemo.DemoControl.UserControlReadWriteOp();
			this.userControlHead1 = new HslCommunicationDemo.DemoControl.UserControlHead();
			this.textBox4 = new System.Windows.Forms.TextBox();
			this.label5 = new System.Windows.Forms.Label();
			this.textBox5 = new System.Windows.Forms.TextBox();
			this.label6 = new System.Windows.Forms.Label();
			this.textBox6 = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.button32 = new System.Windows.Forms.Button();
			this.panel1.SuspendLayout();
			this.panel2.SuspendLayout();
			this.tabControl1.SuspendLayout();
			this.tabPage1.SuspendLayout();
			this.tabPage2.SuspendLayout();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.button2);
			this.panel1.Controls.Add(this.button1);
			this.panel1.Controls.Add(this.textBox2);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.textBox1);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Location = new System.Drawing.Point(12, 41);
			this.panel1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(978, 43);
			this.panel1.TabIndex = 12;
			// 
			// label2
			// 
			this.label2.ForeColor = System.Drawing.Color.Red;
			this.label2.Location = new System.Drawing.Point(332, 6);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(434, 35);
			this.label2.TabIndex = 6;
			this.label2.Text = "写入的操作需要小心，需要对数据进行检查。";
			// 
			// button2
			// 
			this.button2.Enabled = false;
			this.button2.Location = new System.Drawing.Point(875, 6);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(91, 28);
			this.button2.TabIndex = 5;
			this.button2.Text = "断开连接";
			this.button2.UseVisualStyleBackColor = true;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(772, 6);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(91, 28);
			this.button1.TabIndex = 4;
			this.button1.Text = "连接";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textBox2
			// 
			this.textBox2.Location = new System.Drawing.Point(250, 9);
			this.textBox2.Name = "textBox2";
			this.textBox2.Size = new System.Drawing.Size(76, 23);
			this.textBox2.TabIndex = 3;
			this.textBox2.Text = "60008";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(196, 12);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(56, 17);
			this.label3.TabIndex = 2;
			this.label3.Text = "端口号：";
			// 
			// textBox1
			// 
			this.textBox1.Location = new System.Drawing.Point(62, 9);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(128, 23);
			this.textBox1.TabIndex = 1;
			this.textBox1.Text = "127.0.0.1";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 12);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(56, 17);
			this.label1.TabIndex = 0;
			this.label1.Text = "Ip地址：";
			// 
			// panel2
			// 
			this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
			this.panel2.Controls.Add(this.tabControl1);
			this.panel2.Location = new System.Drawing.Point(12, 91);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(978, 546);
			this.panel2.TabIndex = 13;
			// 
			// tabControl1
			// 
			this.tabControl1.Controls.Add(this.tabPage1);
			this.tabControl1.Controls.Add(this.tabPage2);
			this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tabControl1.Location = new System.Drawing.Point(0, 0);
			this.tabControl1.Name = "tabControl1";
			this.tabControl1.SelectedIndex = 0;
			this.tabControl1.Size = new System.Drawing.Size(976, 544);
			this.tabControl1.TabIndex = 114;
			// 
			// tabPage1
			// 
			this.tabPage1.Controls.Add(this.label4);
			this.tabPage1.Controls.Add(this.comboBox1);
			this.tabPage1.Controls.Add(this.button31);
			this.tabPage1.Controls.Add(this.button4);
			this.tabPage1.Controls.Add(this.button_read_short);
			this.tabPage1.Controls.Add(this.textBox8);
			this.tabPage1.Controls.Add(this.label42);
			this.tabPage1.Location = new System.Drawing.Point(4, 26);
			this.tabPage1.Name = "tabPage1";
			this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage1.Size = new System.Drawing.Size(968, 514);
			this.tabPage1.TabIndex = 0;
			this.tabPage1.Text = "通用读取";
			this.tabPage1.UseVisualStyleBackColor = true;
			// 
			// label4
			// 
			this.label4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(545, 12);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(93, 17);
			this.label4.TabIndex = 117;
			this.label4.Text = "PropertyInfo：";
			// 
			// comboBox1
			// 
			this.comboBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.comboBox1.FormattingEnabled = true;
			this.comboBox1.Location = new System.Drawing.Point(641, 8);
			this.comboBox1.Name = "comboBox1";
			this.comboBox1.Size = new System.Drawing.Size(203, 25);
			this.comboBox1.TabIndex = 116;
			// 
			// button31
			// 
			this.button31.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
			this.button31.Location = new System.Drawing.Point(850, 6);
			this.button31.Name = "button31";
			this.button31.Size = new System.Drawing.Size(112, 28);
			this.button31.TabIndex = 115;
			this.button31.Text = "Single Read";
			this.button31.UseVisualStyleBackColor = true;
			this.button31.Click += new System.EventHandler(this.button31_Click);
			// 
			// button4
			// 
			this.button4.Location = new System.Drawing.Point(178, 6);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(113, 28);
			this.button4.TabIndex = 113;
			this.button4.Text = "String Read";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button_read_short
			// 
			this.button_read_short.Location = new System.Drawing.Point(60, 6);
			this.button_read_short.Name = "button_read_short";
			this.button_read_short.Size = new System.Drawing.Size(112, 28);
			this.button_read_short.TabIndex = 9;
			this.button_read_short.Text = "JSON Read";
			this.button_read_short.UseVisualStyleBackColor = true;
			this.button_read_short.Click += new System.EventHandler(this.button_read_short_Click);
			// 
			// textBox8
			// 
			this.textBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.textBox8.Location = new System.Drawing.Point(61, 39);
			this.textBox8.Multiline = true;
			this.textBox8.Name = "textBox8";
			this.textBox8.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox8.Size = new System.Drawing.Size(901, 469);
			this.textBox8.TabIndex = 110;
			// 
			// label42
			// 
			this.label42.AutoSize = true;
			this.label42.Location = new System.Drawing.Point(3, 37);
			this.label42.Name = "label42";
			this.label42.Size = new System.Drawing.Size(55, 17);
			this.label42.TabIndex = 109;
			this.label42.Text = "Result：";
			// 
			// tabPage2
			// 
			this.tabPage2.Controls.Add(this.groupBox1);
			this.tabPage2.Controls.Add(this.userControlReadWriteOp1);
			this.tabPage2.Location = new System.Drawing.Point(4, 26);
			this.tabPage2.Name = "tabPage2";
			this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
			this.tabPage2.Size = new System.Drawing.Size(968, 514);
			this.tabPage2.TabIndex = 1;
			this.tabPage2.Text = "专业读写";
			this.tabPage2.UseVisualStyleBackColor = true;
			// 
			// groupBox1
			// 
			this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.groupBox1.Controls.Add(this.button32);
			this.groupBox1.Controls.Add(this.textBox6);
			this.groupBox1.Controls.Add(this.label7);
			this.groupBox1.Controls.Add(this.textBox5);
			this.groupBox1.Controls.Add(this.label6);
			this.groupBox1.Controls.Add(this.textBox4);
			this.groupBox1.Controls.Add(this.label5);
			this.groupBox1.Controls.Add(this.button30);
			this.groupBox1.Controls.Add(this.button29);
			this.groupBox1.Controls.Add(this.button28);
			this.groupBox1.Controls.Add(this.button27);
			this.groupBox1.Controls.Add(this.button26);
			this.groupBox1.Controls.Add(this.button25);
			this.groupBox1.Controls.Add(this.button24);
			this.groupBox1.Controls.Add(this.button23);
			this.groupBox1.Controls.Add(this.button22);
			this.groupBox1.Controls.Add(this.button21);
			this.groupBox1.Controls.Add(this.button20);
			this.groupBox1.Controls.Add(this.button19);
			this.groupBox1.Controls.Add(this.button18);
			this.groupBox1.Controls.Add(this.button17);
			this.groupBox1.Controls.Add(this.button16);
			this.groupBox1.Controls.Add(this.button15);
			this.groupBox1.Controls.Add(this.button14);
			this.groupBox1.Controls.Add(this.button13);
			this.groupBox1.Controls.Add(this.button12);
			this.groupBox1.Controls.Add(this.button11);
			this.groupBox1.Controls.Add(this.button10);
			this.groupBox1.Controls.Add(this.button9);
			this.groupBox1.Controls.Add(this.button8);
			this.groupBox1.Controls.Add(this.button7);
			this.groupBox1.Controls.Add(this.button6);
			this.groupBox1.Controls.Add(this.button5);
			this.groupBox1.Controls.Add(this.textBox3);
			this.groupBox1.Controls.Add(this.button3);
			this.groupBox1.Location = new System.Drawing.Point(7, 252);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(954, 256);
			this.groupBox1.TabIndex = 1;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "特殊功能测试";
			// 
			// button30
			// 
			this.button30.Location = new System.Drawing.Point(681, 96);
			this.button30.Name = "button30";
			this.button30.Size = new System.Drawing.Size(69, 31);
			this.button30.TabIndex = 27;
			this.button30.Text = "w-GI";
			this.button30.UseVisualStyleBackColor = true;
			this.button30.Click += new System.EventHandler(this.button30_Click);
			// 
			// button29
			// 
			this.button29.Location = new System.Drawing.Point(681, 59);
			this.button29.Name = "button29";
			this.button29.Size = new System.Drawing.Size(69, 31);
			this.button29.TabIndex = 26;
			this.button29.Text = "w-GO2";
			this.button29.UseVisualStyleBackColor = true;
			this.button29.Click += new System.EventHandler(this.button28_Click);
			// 
			// button28
			// 
			this.button28.Location = new System.Drawing.Point(681, 22);
			this.button28.Name = "button28";
			this.button28.Size = new System.Drawing.Size(69, 31);
			this.button28.TabIndex = 25;
			this.button28.Text = "w-GO";
			this.button28.UseVisualStyleBackColor = true;
			this.button28.Click += new System.EventHandler(this.button28_Click);
			// 
			// button27
			// 
			this.button27.Location = new System.Drawing.Point(606, 96);
			this.button27.Name = "button27";
			this.button27.Size = new System.Drawing.Size(69, 31);
			this.button27.TabIndex = 24;
			this.button27.Text = "w-RDI";
			this.button27.UseVisualStyleBackColor = true;
			this.button27.Click += new System.EventHandler(this.button27_Click);
			// 
			// button26
			// 
			this.button26.Location = new System.Drawing.Point(606, 59);
			this.button26.Name = "button26";
			this.button26.Size = new System.Drawing.Size(69, 31);
			this.button26.TabIndex = 23;
			this.button26.Text = "w-RDO";
			this.button26.UseVisualStyleBackColor = true;
			this.button26.Click += new System.EventHandler(this.button26_Click);
			// 
			// button25
			// 
			this.button25.Location = new System.Drawing.Point(606, 22);
			this.button25.Name = "button25";
			this.button25.Size = new System.Drawing.Size(69, 31);
			this.button25.TabIndex = 22;
			this.button25.Text = "w-SDI";
			this.button25.UseVisualStyleBackColor = true;
			this.button25.Click += new System.EventHandler(this.button25_Click);
			// 
			// button24
			// 
			this.button24.Location = new System.Drawing.Point(492, 96);
			this.button24.Name = "button24";
			this.button24.Size = new System.Drawing.Size(108, 31);
			this.button24.TabIndex = 21;
			this.button24.Text = "w-SDO[1100x]";
			this.button24.UseVisualStyleBackColor = true;
			this.button24.Click += new System.EventHandler(this.button22_Click);
			// 
			// button23
			// 
			this.button23.Location = new System.Drawing.Point(492, 59);
			this.button23.Name = "button23";
			this.button23.Size = new System.Drawing.Size(108, 31);
			this.button23.TabIndex = 20;
			this.button23.Text = "w-SDO[1000x]";
			this.button23.UseVisualStyleBackColor = true;
			this.button23.Click += new System.EventHandler(this.button22_Click);
			// 
			// button22
			// 
			this.button22.Location = new System.Drawing.Point(492, 22);
			this.button22.Name = "button22";
			this.button22.Size = new System.Drawing.Size(108, 31);
			this.button22.TabIndex = 19;
			this.button22.Text = "w-SDO";
			this.button22.UseVisualStyleBackColor = true;
			this.button22.Click += new System.EventHandler(this.button22_Click);
			// 
			// button21
			// 
			this.button21.Location = new System.Drawing.Point(414, 96);
			this.button21.Name = "button21";
			this.button21.Size = new System.Drawing.Size(72, 31);
			this.button21.TabIndex = 18;
			this.button21.Text = "r-WSI";
			this.button21.UseVisualStyleBackColor = true;
			this.button21.Click += new System.EventHandler(this.button21_Click);
			// 
			// button20
			// 
			this.button20.Location = new System.Drawing.Point(414, 59);
			this.button20.Name = "button20";
			this.button20.Size = new System.Drawing.Size(72, 31);
			this.button20.TabIndex = 17;
			this.button20.Text = "r-WI";
			this.button20.UseVisualStyleBackColor = true;
			this.button20.Click += new System.EventHandler(this.button20_Click);
			// 
			// button19
			// 
			this.button19.Location = new System.Drawing.Point(414, 22);
			this.button19.Name = "button19";
			this.button19.Size = new System.Drawing.Size(72, 31);
			this.button19.TabIndex = 16;
			this.button19.Text = "r-WO";
			this.button19.UseVisualStyleBackColor = true;
			this.button19.Click += new System.EventHandler(this.button19_Click);
			// 
			// button18
			// 
			this.button18.Location = new System.Drawing.Point(336, 96);
			this.button18.Name = "button18";
			this.button18.Size = new System.Drawing.Size(72, 31);
			this.button18.TabIndex = 15;
			this.button18.Text = "r-AI";
			this.button18.UseVisualStyleBackColor = true;
			this.button18.Click += new System.EventHandler(this.button18_Click);
			// 
			// button17
			// 
			this.button17.Location = new System.Drawing.Point(336, 59);
			this.button17.Name = "button17";
			this.button17.Size = new System.Drawing.Size(72, 31);
			this.button17.TabIndex = 14;
			this.button17.Text = "r-AO";
			this.button17.UseVisualStyleBackColor = true;
			this.button17.Click += new System.EventHandler(this.button17_Click);
			// 
			// button16
			// 
			this.button16.Location = new System.Drawing.Point(336, 22);
			this.button16.Name = "button16";
			this.button16.Size = new System.Drawing.Size(72, 31);
			this.button16.TabIndex = 13;
			this.button16.Text = "r-GI";
			this.button16.UseVisualStyleBackColor = true;
			this.button16.Click += new System.EventHandler(this.button16_Click);
			// 
			// button15
			// 
			this.button15.Location = new System.Drawing.Point(262, 96);
			this.button15.Name = "button15";
			this.button15.Size = new System.Drawing.Size(68, 31);
			this.button15.TabIndex = 12;
			this.button15.Text = "r-GO2";
			this.button15.UseVisualStyleBackColor = true;
			this.button15.Click += new System.EventHandler(this.button15_Click);
			// 
			// button14
			// 
			this.button14.Location = new System.Drawing.Point(262, 59);
			this.button14.Name = "button14";
			this.button14.Size = new System.Drawing.Size(68, 31);
			this.button14.TabIndex = 11;
			this.button14.Text = "r-GO";
			this.button14.UseVisualStyleBackColor = true;
			this.button14.Click += new System.EventHandler(this.button14_Click);
			// 
			// button13
			// 
			this.button13.Location = new System.Drawing.Point(262, 22);
			this.button13.Name = "button13";
			this.button13.Size = new System.Drawing.Size(68, 31);
			this.button13.TabIndex = 10;
			this.button13.Text = "r-UI";
			this.button13.UseVisualStyleBackColor = true;
			this.button13.Click += new System.EventHandler(this.button13_Click);
			// 
			// button12
			// 
			this.button12.Location = new System.Drawing.Point(185, 96);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(71, 31);
			this.button12.TabIndex = 9;
			this.button12.Text = "r-UO";
			this.button12.UseVisualStyleBackColor = true;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// button11
			// 
			this.button11.Location = new System.Drawing.Point(185, 59);
			this.button11.Name = "button11";
			this.button11.Size = new System.Drawing.Size(71, 31);
			this.button11.TabIndex = 8;
			this.button11.Text = "r-SI";
			this.button11.UseVisualStyleBackColor = true;
			this.button11.Click += new System.EventHandler(this.button11_Click);
			// 
			// button10
			// 
			this.button10.Location = new System.Drawing.Point(185, 22);
			this.button10.Name = "button10";
			this.button10.Size = new System.Drawing.Size(71, 31);
			this.button10.TabIndex = 7;
			this.button10.Text = "r-SO";
			this.button10.UseVisualStyleBackColor = true;
			this.button10.Click += new System.EventHandler(this.button10_Click);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(108, 96);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(71, 31);
			this.button9.TabIndex = 6;
			this.button9.Text = "r-RDI";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(108, 59);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(71, 31);
			this.button8.TabIndex = 5;
			this.button8.Text = "r-RDO";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button7
			// 
			this.button7.Location = new System.Drawing.Point(108, 22);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(71, 31);
			this.button7.TabIndex = 4;
			this.button7.Text = "r-SDI";
			this.button7.UseVisualStyleBackColor = true;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(6, 96);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(96, 31);
			this.button6.TabIndex = 3;
			this.button6.Text = "r-SDO[1100x]";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button5
			// 
			this.button5.Location = new System.Drawing.Point(6, 59);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(96, 31);
			this.button5.TabIndex = 2;
			this.button5.Text = "r-SDO[1000x]";
			this.button5.UseVisualStyleBackColor = true;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// textBox3
			// 
			this.textBox3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
			this.textBox3.Location = new System.Drawing.Point(6, 133);
			this.textBox3.Multiline = true;
			this.textBox3.Name = "textBox3";
			this.textBox3.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
			this.textBox3.Size = new System.Drawing.Size(942, 117);
			this.textBox3.TabIndex = 1;
			// 
			// button3
			// 
			this.button3.Location = new System.Drawing.Point(6, 22);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(96, 31);
			this.button3.TabIndex = 0;
			this.button3.Text = "r-SDO";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// userControlReadWriteOp1
			// 
			this.userControlReadWriteOp1.Location = new System.Drawing.Point(7, 6);
			this.userControlReadWriteOp1.Name = "userControlReadWriteOp1";
			this.userControlReadWriteOp1.Size = new System.Drawing.Size(954, 240);
			this.userControlReadWriteOp1.TabIndex = 0;
			// 
			// userControlHead1
			// 
			this.userControlHead1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
			this.userControlHead1.Dock = System.Windows.Forms.DockStyle.Top;
			this.userControlHead1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.userControlHead1.Location = new System.Drawing.Point(0, 0);
			this.userControlHead1.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.userControlHead1.MinimumSize = new System.Drawing.Size(800, 32);
			this.userControlHead1.Name = "userControlHead1";
			this.userControlHead1.ProtocolInfo = "Robot";
			this.userControlHead1.Size = new System.Drawing.Size(1004, 32);
			this.userControlHead1.TabIndex = 14;
			this.userControlHead1.SaveConnectEvent += new System.EventHandler<System.EventArgs>(this.userControlHead1_SaveConnectEvent_1);
			// 
			// textBox4
			// 
			this.textBox4.Location = new System.Drawing.Point(841, 20);
			this.textBox4.Name = "textBox4";
			this.textBox4.Size = new System.Drawing.Size(92, 23);
			this.textBox4.TabIndex = 29;
			this.textBox4.Text = "70";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Location = new System.Drawing.Point(770, 23);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(56, 17);
			this.label5.TabIndex = 28;
			this.label5.Text = "数据块：";
			// 
			// textBox5
			// 
			this.textBox5.Location = new System.Drawing.Point(841, 49);
			this.textBox5.Name = "textBox5";
			this.textBox5.Size = new System.Drawing.Size(92, 23);
			this.textBox5.TabIndex = 31;
			this.textBox5.Text = "1";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Location = new System.Drawing.Point(770, 52);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(68, 17);
			this.label6.TabIndex = 30;
			this.label6.Text = "偏移地址：";
			// 
			// textBox6
			// 
			this.textBox6.Location = new System.Drawing.Point(841, 77);
			this.textBox6.Name = "textBox6";
			this.textBox6.Size = new System.Drawing.Size(92, 23);
			this.textBox6.TabIndex = 33;
			this.textBox6.Text = "4";
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Location = new System.Drawing.Point(770, 80);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(44, 17);
			this.label7.TabIndex = 32;
			this.label7.Text = "长度：";
			// 
			// button32
			// 
			this.button32.Location = new System.Drawing.Point(773, 103);
			this.button32.Name = "button32";
			this.button32.Size = new System.Drawing.Size(77, 25);
			this.button32.TabIndex = 34;
			this.button32.Text = "Read";
			this.button32.UseVisualStyleBackColor = true;
			this.button32.Click += new System.EventHandler(this.button32_Click);
			// 
			// FormFanucRobot
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 17F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.AutoScroll = true;
			this.ClientSize = new System.Drawing.Size(1004, 645);
			this.Controls.Add(this.userControlHead1);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
			this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
			this.Name = "FormFanucRobot";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
			this.Text = "发那科机器人";
			this.Load += new System.EventHandler(this.FormEfort_Load);
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			this.panel2.ResumeLayout(false);
			this.tabControl1.ResumeLayout(false);
			this.tabPage1.ResumeLayout(false);
			this.tabPage1.PerformLayout();
			this.tabPage2.ResumeLayout(false);
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Button button_read_short;
        private DemoControl.UserControlHead userControlHead1;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Label label42;
		private System.Windows.Forms.TabControl tabControl1;
		private System.Windows.Forms.TabPage tabPage1;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.TabPage tabPage2;
        private DemoControl.UserControlReadWriteOp userControlReadWriteOp1;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox textBox3;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Button button10;
		private System.Windows.Forms.Button button11;
		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button13;
		private System.Windows.Forms.Button button14;
		private System.Windows.Forms.Button button15;
		private System.Windows.Forms.Button button16;
		private System.Windows.Forms.Button button17;
		private System.Windows.Forms.Button button18;
		private System.Windows.Forms.Button button19;
		private System.Windows.Forms.Button button21;
		private System.Windows.Forms.Button button20;
		private System.Windows.Forms.Button button22;
		private System.Windows.Forms.Button button24;
		private System.Windows.Forms.Button button23;
		private System.Windows.Forms.Button button25;
		private System.Windows.Forms.Button button26;
		private System.Windows.Forms.Button button27;
		private System.Windows.Forms.Button button28;
		private System.Windows.Forms.Button button29;
		private System.Windows.Forms.Button button30;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.ComboBox comboBox1;
		private System.Windows.Forms.Button button31;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox textBox6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.TextBox textBox5;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.TextBox textBox4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button button32;
	}
}