﻿using HslCommunication.Algorithms.ConnectPool;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HslCommunication.MQTT
{
	/// <summary>
	/// 关于MqttSyncClient实现的接口<see cref="IConnector"/>，从而实现了数据连接池的操作信息
	/// </summary>
	public class IMqttSyncConnector : IConnector
	{
		/// <inheritdoc cref="IConnector.IsConnectUsing"/>
		public bool IsConnectUsing { get; set; }

		/// <inheritdoc cref="IConnector.GuidToken"/>
		public string GuidToken { get; set; }

		/// <inheritdoc cref="IConnector.LastUseTime"/>
		public DateTime LastUseTime { get; set; }

		/// <summary>
		/// MQTT的连接对象
		/// </summary>
		public MqttSyncClient SyncClient { get; set; }

		/// <inheritdoc cref="IConnector.Close"/>
		public void Close( )
		{
			SyncClient?.ConnectClose( );
		}

		/// <inheritdoc cref="IConnector.Open"/>
		public void Open( )
		{
			SyncClient?.SetPersistentConnection( );
		}
	}
}
