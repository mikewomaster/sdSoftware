﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HslCommunication;
using HslCommunication.Core.IMessage;
using HslCommunication.Core;
using HslCommunication.Core.Net;
using HslCommunication.ModBus;

namespace HslCppExtension
{
	/// <summary>
	/// NetworkDeviceBase的写入数据的方法扩展，方便CPP项目的调用，解决方法重载的问题。
	/// </summary>
	public static class NetworkDeviceBaseExtension
	{
		/// <inheritdoc cref="IReadWriteNet.Write(string, short)"/>
		public static OperateResult WriteInt16( this NetworkDeviceBase device, string address, short value )
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, short[])"/>
		public static OperateResult WriteInt16Array( this NetworkDeviceBase device, string address, short[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ushort)"/>
		public static OperateResult WriteUInt16( this NetworkDeviceBase device, string address, ushort value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ushort[])"/>
		public static OperateResult WriteUInt16Array( this NetworkDeviceBase device, string address, ushort[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, int)"/>
		public static OperateResult WriteInt32( this NetworkDeviceBase device, string address, int value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, int[])"/>
		public static OperateResult WriteInt32Array( this NetworkDeviceBase device, string address, int[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, uint)"/>
		public static OperateResult WriteUInt32( this NetworkDeviceBase device, string address, uint value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, uint[])"/>
		public static OperateResult WriteUInt32Array( this NetworkDeviceBase device, string address, uint[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, long)"/>
		public static OperateResult WriteInt64( this NetworkDeviceBase device, string address, long value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, long[])"/>
		public static OperateResult WriteInt64Array( this NetworkDeviceBase device, string address, long[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ulong)"/>
		public static OperateResult WriteUInt64( this NetworkDeviceBase device, string address, ulong value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, ulong[])"/>
		public static OperateResult WriteUInt64Array( this NetworkDeviceBase device, string address, ulong[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, float)"/>
		public static OperateResult WriteSingle( this NetworkDeviceBase device, string address, float value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, float[])"/>
		public static OperateResult WriteSingleArray( this NetworkDeviceBase device, string address, float[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, double)"/>
		public static OperateResult WriteDouble( this NetworkDeviceBase device, string address, double value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, double[])"/>
		public static OperateResult WriteDoubleArray( this NetworkDeviceBase device, string address, double[] value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Write(string, string)"/>
		public static OperateResult WriteString( this NetworkDeviceBase device, string address, string value ) 
		{
			return device.Write( address, value );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, bool, int, int)"/>
		public static OperateResult WaitBool( this NetworkDeviceBase device, string address, bool waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, short, int, int)"/>
		public static OperateResult WaitInt16( this NetworkDeviceBase device, string address, short waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, ushort, int, int)"/>
		public static OperateResult WaitUInt16( this NetworkDeviceBase device, string address, ushort waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, int, int, int)"/>
		public static OperateResult WaitInt32( this NetworkDeviceBase device, string address, int waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, uint, int, int)"/>
		public static OperateResult WaitUInt32( this NetworkDeviceBase device, string address, uint waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, long, int, int)"/>
		public static OperateResult WaitInt64( this NetworkDeviceBase device, string address, long waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}

		/// <inheritdoc cref="IReadWriteNet.Wait(string, ulong, int, int)"/>
		public static OperateResult WaitUInt64( this NetworkDeviceBase device, string address, ulong waitValue, int readInterval = 100, int waitTimeout = -1 )
		{
			return device.Wait( address, waitValue, readInterval, waitTimeout );
		}
	}
}
