﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using HslCommunication.Core;
using HslCommunication.Core.Net;
using HslCommunication.Enthernet;

namespace FileNetServer
{
    public partial class FormFileServer : Form
    {
        public FormFileServer( )
        {
            InitializeComponent( );
        }

        private void FormFileServer_Load( object sender, EventArgs e )
        {
            textBox2.Text = Guid.Empty.ToString( );
            textBox9.Text = Guid.Empty.ToString( );

            textBox3.Text = Application.StartupPath + "\\AdvancedFiles";
            textBox4.Text = Application.StartupPath + "\\FileTemp";

            textBox8.Text = Application.StartupPath + "\\UltimateFiles";


            cur = Process.GetCurrentProcess( );
            curpcp = new PerformanceCounter( "Process", "Working Set - Private", cur.ProcessName );

            timer = new Timer( );
            timer.Interval = 1000;
            timer.Tick += Timer_Tick;
            timer.Start( );
        }

        private void Timer_Tick( object sender, EventArgs e )
        {
            string RamInfo = (curpcp.NextValue( ) / MB_DIV).ToString( "F1" ) + "MB";
            toolStripStatusLabel1.Text = "Ram:" + RamInfo;
            toolStripStatusLabel2.Text = $"Thread:{NetworkBase.ThreadPoolTimeoutCheckCount}  Lock:{SimpleHybirdLock.SimpleHybirdLockCount}  Wait:{SimpleHybirdLock.SimpleHybirdLockWaitCount}";
        }

        private void linkLabel1_LinkClicked( object sender, LinkLabelLinkClickedEventArgs e )
        {
            try
            {
                System.Diagnostics.Process.Start( linkLabel1.Text );
            }
            catch (Exception ex)
            {
                MessageBox.Show( ex.Message );
            }
        }

        private void linkLabel2_LinkClicked( object sender, LinkLabelLinkClickedEventArgs e )
        {
            HslCommunication.BasicFramework.FormSupport form = new HslCommunication.BasicFramework.FormSupport( );
            form.ShowDialog( );
        }

        #region Advanced Server

        private AdvancedFileServer advancedFileServer;
        private System.Windows.Forms.Timer timer;
        private Process cur = null;
        private PerformanceCounter curpcp = null;
        private const int MB_DIV = 1024 * 1024;

        private void AdvancedFileServerStart( )
        {
            // textBox1.Text为端口号信息
            if (!int.TryParse( textBox1.Text, out int port ))
            {
                MessageBox.Show( "Advanced文件服务器引擎的端口号输入异常" );
            }

            advancedFileServer = new AdvancedFileServer( );
            advancedFileServer.FilesDirectoryPath = textBox3.Text;                                    // 所有文件存储的路径
            advancedFileServer.FilesDirectoryPathTemp = textBox4.Text;                                // 临时文件的目录
            advancedFileServer.Token = new Guid( textBox2.Text );                                     // 令牌
            advancedFileServer.LogNet = new HslCommunication.LogNet.LogNetSingle( "" );               // 设置日志
            advancedFileServer.LogNet.BeforeSaveToFile += LogNet1_BeforeSaveToFile;
            advancedFileServer.OnFileUploadEvent += AdvancedFileServer_OnFileUploadEvent;             // 当收到文件的时候触发
            advancedFileServer.ServerStart( port );
            advancedFileServer.FileCacheSize = 1024 * 1024 * 2;
        }

        private void AdvancedFileServer_OnFileUploadEvent( FileServerInfo fileInfo )
        {
            Invoke( new Action( ( ) =>
             {
                 textBox5.AppendText( Newtonsoft.Json.Linq.JObject.FromObject( fileInfo ).ToString( ) + Environment.NewLine );
             } ) );
        }

        private void LogNet1_BeforeSaveToFile( object sender, HslCommunication.LogNet.HslEventArgs e )
        {
            if(InvokeRequired)
            {
                Invoke( new Action<object, HslCommunication.LogNet.HslEventArgs>( LogNet1_BeforeSaveToFile ), sender, e );
                return;
            }

            textBox5.AppendText( e.HslMessage.ToString( ) + Environment.NewLine );
        }
        private void button1_Click( object sender, EventArgs e )
        {
            try
            {
                // 启动文件服务器
                AdvancedFileServerStart( );
                button1.Enabled = false;
            }
            catch(Exception ex)
            {
                HslCommunication.BasicFramework.SoftBasic.ShowExceptionMessage( ex );
            }
        }

        #endregion

        #region Ultimate Server



        private UltimateFileServer ultimateFileServer;

        private void UltimateFileServerStart( )
        {
            if (!int.TryParse( textBox10.Text, out int port ))
            {
                MessageBox.Show( "Advanced文件服务器引擎的端口号输入异常" );
            }

            ultimateFileServer = new UltimateFileServer( );
            ultimateFileServer.FilesDirectoryPath = textBox8.Text;                   // 设置文件的存储路径
            ultimateFileServer.Token = new Guid( textBox9.Text );                    // 令牌
            ultimateFileServer.LogNet = new HslCommunication.LogNet.LogNetSingle( Application.StartupPath + "\\Logs\\UltimateLog.txt" );  // 日志
            ultimateFileServer.LogNet.BeforeSaveToFile += LogNet2_BeforeSaveToFile;
            ultimateFileServer.OnFileUploadEvent += UltimateFileServer_OnFileUploadEvent;   // 当收到文件的时候触发
            ultimateFileServer.ServerStart( port );
            ultimateFileServer.FileCacheSize = 1024 * 1024 * 2;
        }

        private void UltimateFileServer_OnFileUploadEvent( FileServerInfo fileInfo )
        {
            if (checkBox1.Checked)
            {
                Invoke( new Action( ( ) =>
                {
                    textBox6.AppendText( Newtonsoft.Json.Linq.JObject.FromObject( fileInfo ).ToString( ) + Environment.NewLine );
                } ) );
            }
        }

        private void LogNet2_BeforeSaveToFile( object sender, HslCommunication.LogNet.HslEventArgs e )
        {
            if (checkBox1.Checked)
            {
                if (InvokeRequired)
                {
                    Invoke( new Action<object, HslCommunication.LogNet.HslEventArgs>( LogNet2_BeforeSaveToFile ), sender, e );
                    return;
                }

                textBox6.AppendText( e.HslMessage.ToString( ) + Environment.NewLine );
            }
        }
        private void button2_Click( object sender, EventArgs e )
        {
            try
            {
                // 启动服务器
                UltimateFileServerStart( );
                button2.Enabled = false;
            }
            catch (Exception ex)
            {
                HslCommunication.BasicFramework.SoftBasic.ShowExceptionMessage( ex );
            }
        }




        #endregion

        int index = 0;
        private void button3_Click( object sender, EventArgs e )
        {
            index = textBox6.Text.IndexOf( textBox7.Text, index );
            if(index >= 0)
            {
                textBox6.Select( index, textBox7.Text.Length );
                index++;
            }
            else
            {
                MessageBox.Show( "找不到数据！" );
                index = 0;
            }
        }
    }
}
