﻿using HslCommunication;
using HslCommunication.Enthernet.Redis;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HslCommunication_Net45.Test.Documentation.Samples.Enthernet
{
	public class RedisSample
	{
		public void SampleBasic( )
		{
			#region SampleBasic

			RedisClient redis = new RedisClient( "127.0.0.1", 6379, string.Empty );
			// 如果连接服务器
			OperateResult connect = redis.ConnectServer( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "connect success" );
			}
			else
			{
				Console.WriteLine( "connect failed" );
				return;
			}

			// 连接服务器之后，默认选择的是db0，如果需要选择db1
			redis.SelectDB( 1 );

			// 好了，接下来是基本的读写操作
			redis.WriteKey( "A", "test1" );
			OperateResult<string> readA = redis.ReadKey( "A" );

			// 支持批量读写操作
			redis.WriteKey( new string[] { "A", "B", "C" }, new string[] { "test1", "test2", "test3" } );
			OperateResult<string[]> readB = redis.ReadKey( new string[] { "A", "B", "C" } );

			// 支持写入有效期的关键字，过两秒后读就不见了
			redis.WriteExpireKey( "A", "test1", 2 );

			// 自增自减操作
			redis.WriteKey( "A", "1" );
			OperateResult<long> result = redis.IncrementKey( "A" ); // A就变成2了，并且返回2
			result = redis.DecrementKey( "A" ); // A就变成1了，并且返回1

			// 列表的操作
			redis.ListLeftPush( "List", "3" );
			redis.ListLeftPush( "List", "2" );
			redis.ListLeftPush( "List", "1" );  // 这样就生成了一个List的列表 [1,2,3]
			var lists = redis.ListRange( "List", 0, -1 ); // 读取到了List的所有数据
			var listIndex1 = redis.ReadListByIndex( "List", 1 ); // 读取某一个元素
			var listLength = redis.GetListLength( "List" ).Content;  // 获取数组的长度
			redis.ListTrim( "List", 0, 1 );   // 只保留2个元素

			// 哈希键的操作
			redis.WriteHashKey( "Hash", "A", "test1" );
			redis.WriteHashKey( "Hash", "B", "test2" );
			redis.WriteHashKey( "Hash", "C", "test3" );
			redis.ReadHashKey( "Hash", "A" );   // 读取单个的值，返回test1
			redis.ReadHashKeys( "Hash" );   // 读取所有域，["A","B","C"]
			redis.ReadHashValues( "Hash" );  // 读取所有的值，["test1", "test2", "text3"]

			// 其他的操作详细参考类的api文档信息

			// 关闭
			redis.ConnectClose( );

			#endregion
		}

		public void Sample1( )
		{
			#region Sample1
			RedisClient redis = new RedisClient( "127.0.0.1", 6379, string.Empty );
			redis.ConnectServer( );

			// 上面是连接，此处不关心，只关心读数情况
			// The above is the connection, here does not care, only care about the reading
			OperateResult<string> readA = redis.ReadKey( "A" );
			OperateResult<string> readB = redis.ReadKey( "B" );
			OperateResult<string> readC = redis.ReadKey( "C" );
			OperateResult<string> readD = redis.ReadKey( "D" );

			if (readA.IsSuccess && readB.IsSuccess && readC.IsSuccess && readD.IsSuccess)
			{
				// do somethong
			}


			// 当然你也可以这么干，加快读取的速度，并且代码更加简洁
			// Of course, you can also do this, speed up the reading speed, and the code is more concise
			OperateResult<string[]> readAD = redis.ReadKey( new string[] { "A", "B", "C", "D" } );
			if (readAD.IsSuccess)
			{
				// do something
				// A = readAD.Content[0]
				// B = readAD.Content[0]
				// C = readAD.Content[0]
				// D = readAD.Content[0]
			}

			// 当你需要读取加转换代码的时候，就没有那么方便了
			// When you need to read plus conversion code, it is not so convenient
			OperateResult<string[]> readAD2 = redis.ReadKey( new string[] { "A", "B", "C", "D" } );
			if (readAD.IsSuccess)
			{
				// 我们假设读取的所有数据需要转换int类型数据
				// We assume that all data read needs to be converted to int data
				int[] buffer = readAD2.Content.Select( m => int.Parse( m ) ).ToArray( );

				// do something
			}

			// 当你还要读取其他的信息的时候，就不得不多写点代码了
			// When you need to read other information, you have to write more code
			OperateResult<string> readListA = redis.ReadListByIndex( "List", 0 );
			OperateResult<string> readHashA1 = redis.ReadHashKey( "HashA", "A1" );
			OperateResult<string> readHashA2 = redis.ReadHashKey( "HashA", "A2" );
			// ...
			// and so on

			redis.ConnectClose( );
			#endregion
		}


		public void Sample2( )
		{
			#region Sample2
			RedisClient redis = new RedisClient( "127.0.0.1", 6379, string.Empty );
			redis.ConnectServer( );

			// 上面是连接，此处不关心，只关心读数情况
			// The above is the connection, here does not care, only care about the reading

			// 我们来看看下面的两种等效写法，就可以发现此处的新写法是多么的便捷
			// Let's take a look at the two equivalents below to see how convenient the new writing is here

			// 假设下面是我们需要读取的，并且转化数据的，读取的数据在redis是真实存在的
			// Suppose the following is what we need to read and transform the data. The read data is real in redis
			OperateResult<string> readA = redis.ReadKey( "A" );
			OperateResult<string> readB = redis.ReadKey( "B" );
			OperateResult<string> readC = redis.ReadKey( "C" );
			OperateResult<string> readD = redis.ReadKey( "D" );
			OperateResult<string> readE = redis.ReadListByIndex( "E", 0 );
			OperateResult<string[]> readF = redis.ListRange( "F", 0, -1 );
			OperateResult<string[]> readG = redis.ReadHashKey( "G", new string[] { "G1", "G2", "G4" } );
			OperateResult<string> readH = redis.ReadHashKey( "H", "H1" );

			if (readA.IsSuccess && readB.IsSuccess && readC.IsSuccess && readD.IsSuccess &&
				readE.IsSuccess && readF.IsSuccess && readG.IsSuccess && readH.IsSuccess)
			{
				// 进行相关的数据转换
				// Perform related data conversion
				string A = readA.Content;
				int B = int.Parse( readB.Content );
				ushort C = ushort.Parse( readC.Content );
				double D = double.Parse( readD.Content );
				float E = float.Parse( readE.Content );
				float[] F = readF.Content.Select( m => float.Parse( m ) ).ToArray( );
				int G1 = int.Parse( readG.Content[0] );
				int G2 = int.Parse( readG.Content[1] );
				int G3 = int.Parse( readG.Content[2] );
				string H = readH.Content;

				// do something
			}

			// 现在我们紧紧只需要一行代码即可完成任务，前提定义一个数据对象，还可以形成数据复用
			// Now we need only one line of code to complete the task, provided that a data object is defined and data reuse can be formed
			OperateResult<MyClass> read = redis.Read<MyClass>( );
			if (read.IsSuccess)
			{
				// do something
			}

			redis.ConnectClose( );
#endregion
		}

		public async Task Sample3( )
		{
			#region Sample3
			RedisClient redis = new RedisClient( "127.0.0.1", 6379, string.Empty );
			await redis.ConnectServerAsync( );

			// 上面是连接，此处不关心，只关心读数情况
			// The above is the connection, here does not care, only care about the reading

			// 我们来看看下面的两种等效写法，就可以发现此处的新写法是多么的便捷
			// Let's take a look at the two equivalents below to see how convenient the new writing is here

			// 假设下面是我们需要读取的，并且转化数据的，读取的数据在redis是真实存在的
			// Suppose the following is what we need to read and transform the data. The read data is real in redis
			OperateResult<string> readA = await redis.ReadKeyAsync( "A" );
			OperateResult<string> readB = await redis.ReadKeyAsync( "B" );
			OperateResult<string> readC = await redis.ReadKeyAsync( "C" );
			OperateResult<string> readD = await redis.ReadKeyAsync( "D" );
			OperateResult<string> readE = await redis.ReadListByIndexAsync( "E", 0 );
			OperateResult<string[]> readF = await redis.ListRangeAsync( "F", 0, -1 );
			OperateResult<string[]> readG = await redis.ReadHashKeyAsync( "G", new string[] { "G1", "G2", "G4" } );
			OperateResult<string> readH = await redis.ReadHashKeyAsync( "H", "H1" );

			if (readA.IsSuccess && readB.IsSuccess && readC.IsSuccess && readD.IsSuccess &&
				readE.IsSuccess && readF.IsSuccess && readG.IsSuccess && readH.IsSuccess)
			{
				// 进行相关的数据转换
				// Perform related data conversion
				string A = readA.Content;
				int B = int.Parse( readB.Content );
				ushort C = ushort.Parse( readC.Content );
				double D = double.Parse( readD.Content );
				float E = float.Parse( readE.Content );
				float[] F = readF.Content.Select( m => float.Parse( m ) ).ToArray( );
				int G1 = int.Parse( readG.Content[0] );
				int G2 = int.Parse( readG.Content[1] );
				int G3 = int.Parse( readG.Content[2] );
				string H = readH.Content;

				// do something
			}

			// 现在我们紧紧只需要一行代码即可完成任务，前提定义一个数据对象，还可以形成数据复用
			// Now we need only one line of code to complete the task, provided that a data object is defined and data reuse can be formed
			OperateResult<MyClass> read = await redis.ReadAsync<MyClass>( );
			if (read.IsSuccess)
			{
				// do something
			}

			await redis.ConnectCloseAsync( );
			#endregion
		}

		#region SampleClass
		public class MyClass
		{
			[HslCommunication.Reflection.HslRedisKey( "A" )]
			public string A { get; set; }

			[HslCommunication.Reflection.HslRedisKey( "B" )]
			public int B { get; set; }

			[HslCommunication.Reflection.HslRedisKey( "C" )]
			public ushort C { get; set; }

			[HslCommunication.Reflection.HslRedisKey( "D" )]
			public double D { get; set; }

			[HslCommunication.Reflection.HslRedisListItem( "E", 0 )]
			public float E { get; set; }

			[HslCommunication.Reflection.HslRedisList( "F", 0, -1 )]
			public float[] F { get; set; }

			[HslCommunication.Reflection.HslRedisHashField( "G", "G1" )]
			public int G1 { get; set; }

			[HslCommunication.Reflection.HslRedisHashField( "G", "G2" )]
			public int G2 { get; set; }

			[HslCommunication.Reflection.HslRedisHashField( "G", "G3" )]
			public int G3 { get; set; }

			[HslCommunication.Reflection.HslRedisHashField( "H", "H1" )]
			public string H { get; set; }
		}
#endregion
	}
}
