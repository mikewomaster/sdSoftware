﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.MQTT;
using HslCommunication;

namespace HslCommunication_Net45.Test.MQTT
{
    [TestClass]
    public class MqttTest
    {
        [TestMethod]
        public void TestMethod1( )
        {
            OperateResult<byte[]> length = MqttHelper.CalculateLengthToMqttLength( 56 );
            Assert.IsTrue( length.IsSuccess );
            Assert.IsTrue( length.Content.Length == 1 );
            Assert.IsTrue( length.Content[0] == 56 );
        }

        [TestMethod]
        public void TestMethod2( )
        {
            OperateResult<byte[]> length = MqttHelper.CalculateLengthToMqttLength( 1738 );
            Assert.IsTrue( length.IsSuccess );
            Assert.IsTrue( length.Content.Length == 2 );
            Assert.IsTrue( length.Content[0] == 0xCA );
            Assert.IsTrue( length.Content[1] == 0x0D );
        }

        [TestMethod]
        public void TestMethod3( )
        {
            OperateResult<byte[]> length = MqttHelper.CalculateLengthToMqttLength( 2097151 );
            Assert.IsTrue( length.IsSuccess );
            Assert.IsTrue( length.Content.Length == 3 );
            Assert.IsTrue( length.Content[0] == 0xFF );
            Assert.IsTrue( length.Content[1] == 0xFF );
            Assert.IsTrue( length.Content[2] == 0x7F );
        }

        [TestMethod]
        public void TestMethod4( )
        {
            OperateResult<byte[]> length = MqttHelper.CalculateLengthToMqttLength( 268435455 );
            Assert.IsTrue( length.IsSuccess );
            Assert.IsTrue( length.Content.Length == 4 );
            Assert.IsTrue( length.Content[0] == 0xFF );
            Assert.IsTrue( length.Content[1] == 0xFF );
            Assert.IsTrue( length.Content[2] == 0xFF );
            Assert.IsTrue( length.Content[3] == 0x7F );
        }
    }
}
