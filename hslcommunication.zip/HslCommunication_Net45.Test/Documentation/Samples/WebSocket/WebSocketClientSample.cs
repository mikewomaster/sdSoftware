﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.WebSocket;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.WebSocket
{
	class WebSocketClientSample1
	{
		#region Sample1

		private WebSocketClient webSocketClient;

		public void Start( )
		{
			webSocketClient = new WebSocketClient( "127.0.0.1", 1883 );
			webSocketClient.OnClientApplicationMessageReceive += WebSocketClient_OnClientApplicationMessageReceive;
			OperateResult connect = webSocketClient.ConnectServer( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "connect successful" );
			}
			else
			{
				// 连接失败。需要等会重新连接，需要注意的是，对同一个实例来说，OnClientApplicationMessageReceive不能重复绑定事件
				// Connection failed. Need to wait for reconnection, it should be noted that, for the same instance, OnClientApplicationMessageReceive can not repeatedly bind events
				Console.WriteLine( "connect failed" );
			}

			// 当连接成功后，网络发生了异常。客户端会自动重新连接的。
			// When the connection was successful, an exception occurred on the network. The client will automatically reconnect.
		}

		private void WebSocketClient_OnClientApplicationMessageReceive( WebSocketMessage message )
		{
			Console.WriteLine( message.ToString( ) );
		}

		#endregion

		#region Sample2

		public void button_Click(object sender, EventArgs e )
		{
			webSocketClient.SendServer( "This is a message from hslcommunication" );
		}

		#endregion
	}

	class WebSocketClientSample2
	{
		#region Sample3

		private WebSocketClient webSocketClient;

		public void Start( )
		{
			webSocketClient = new WebSocketClient( "127.0.0.1", 1883 );
			// 连接上服务器的时候触发，在断线重连的时候也会触发，如果使用发送服务器实现订阅的方式，在下面的事件里订阅是合理的
			// Triggered when connected to the server, it will also trigger when disconnected and reconnected. 
			// If the sending server is used to implement the subscription, the subscription is reasonable in the following events
			webSocketClient.OnClientConnected += ( ) => 
			{
				// 订阅的内容添加在这里
				// Subscribed content added here
				webSocketClient.SendServer( "A" );
			};
			webSocketClient.OnClientApplicationMessageReceive += WebSocketClient_OnClientApplicationMessageReceive;
			OperateResult connect = webSocketClient.ConnectServer( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "connect successful" );
			}
			else
			{
				// 连接失败。需要等会重新连接，需要注意的是，对同一个实例来说，OnClientApplicationMessageReceive不能重复绑定事件
				// Connection failed. Need to wait for reconnection, it should be noted that, for the same instance, OnClientApplicationMessageReceive can not repeatedly bind events
				Console.WriteLine( "connect failed" );
			}

			// 当连接成功后，网络发生了异常。客户端会自动重新连接的。
			// When the connection was successful, an exception occurred on the network. The client will automatically reconnect.

		}

		private void WebSocketClient_OnClientApplicationMessageReceive( WebSocketMessage message )
		{
			// 一般来说，一个客户端订阅一个topic，如果要订阅多个的话，message就要区分主题，需要采用json格式的数据
			// Generally, a client subscribes to a topic. If you want to subscribe to multiple topics, 
			// the message must distinguish between topics, and payload in json format is required.
			Console.WriteLine( message.ToString( ) );
		}

		#endregion

	}

	class WebSocketClientSample3
	{
		#region Sample4

		private WebSocketClient webSocketClient;

		public void Start( )
		{
			webSocketClient = new WebSocketClient( "127.0.0.1", 1883 );
			// 连接上服务器的时候触发，在断线重连的时候也会触发，如果使用发送服务器实现订阅的方式，在下面的事件里订阅是合理的
			// Triggered when connected to the server, it will also trigger when disconnected and reconnected. 
			// If the sending server is used to implement the subscription, the subscription is reasonable in the following events
			webSocketClient.OnClientConnected += ( ) =>
			{
				// 订阅的内容添加在这里
				// Subscribed content added here
				webSocketClient.SendServer( "A" );
			};
			webSocketClient.OnNetworkError += ( object sender, EventArgs e ) =>
			{
				// 当网络异常的时候触发，可以在此处重连服务器
				if (sender is WebSocketClient client)
				{
					// 开始重连服务器，直到连接成功为止
					client.LogNet?.WriteInfo( "网络异常，准备10秒后重新连接。" );
					while (true)
					{
						// 每隔10秒重连
						System.Threading.Thread.Sleep( 10_000 );
						client.LogNet?.WriteInfo( "准备重新连接服务器..." );
						OperateResult connectResult = client.ConnectServer( );
						if (connectResult.IsSuccess)
						{
							client.LogNet?.WriteInfo( "连接服务器成功！" );
							break;
						}
						client.LogNet?.WriteInfo( "连接失败，准备10秒后重新连接。" );
					}
				}
			};
			webSocketClient.OnClientApplicationMessageReceive += WebSocketClient_OnClientApplicationMessageReceive;
			OperateResult connect = webSocketClient.ConnectServer( );
			if (connect.IsSuccess)
			{
				Console.WriteLine( "connect successful" );
			}
			else
			{
				// 连接失败。需要等会重新连接，需要注意的是，对同一个实例来说，OnClientApplicationMessageReceive不能重复绑定事件
				// Connection failed. Need to wait for reconnection, it should be noted that, for the same instance, OnClientApplicationMessageReceive can not repeatedly bind events
				Console.WriteLine( "connect failed" );
			}

			// 当连接成功后，网络发生了异常。客户端会自动重新连接的。
			// When the connection was successful, an exception occurred on the network. The client will automatically reconnect.

		}

		private void WebSocketClient_OnClientApplicationMessageReceive( WebSocketMessage message )
		{
			// 一般来说，一个客户端订阅一个topic，如果要订阅多个的话，message就要区分主题，需要采用json格式的数据
			// Generally, a client subscribes to a topic. If you want to subscribe to multiple topics, 
			// the message must distinguish between topics, and payload in json format is required.
			Console.WriteLine( message.ToString( ) );
		}

		#endregion

	}
}
