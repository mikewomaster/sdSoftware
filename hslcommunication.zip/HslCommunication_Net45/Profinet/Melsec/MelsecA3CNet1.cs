﻿using HslCommunication.Core;
using HslCommunication.Core.Address;
using HslCommunication.Serial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HslCommunication.BasicFramework;
using HslCommunication.Reflection;

namespace HslCommunication.Profinet.Melsec
{
	/// <summary>
	/// 基于Qna 兼容3C帧的格式一的通讯，具体的地址需要参照三菱的基本地址<br />
	/// Based on Qna-compatible 3C frame format one communication, the specific address needs to refer to the basic address of Mitsubishi.
	/// </summary>
	/// <remarks>
	/// <inheritdoc cref="MelsecA3CNet1OverTcp" path="remarks"/>
	/// </remarks>
	public class MelsecA3CNet1 : SerialDeviceBase
	{
		#region Constructor

		/// <inheritdoc cref="MelsecA3CNet1OverTcp()"/>
		public MelsecA3CNet1( )
		{
			ByteTransform = new RegularByteTransform( );
			WordLength    = 1;
		}

		#endregion

		#region Public Member

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.Station"/>
		public byte Station { get => station; set => station = value; }

		#endregion

		#region Private Method

		private OperateResult<byte[]> ReadWithPackCommand( byte[] command )
		{
			return ReadBase( MelsecA3CNet1OverTcp.PackCommand( command, this.station ) );
		}

		#endregion

		#region Read Write Support

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.Read(string, ushort)"/>
		[HslMqttApi( "ReadByteArray", "" )]
		public override OperateResult<byte[]> Read( string address, ushort length ) => MelsecA3CNet1OverTcp.ReadHelper( address, length, ReadWithPackCommand );

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.Write(string, byte[])"/>
		[HslMqttApi( "WriteByteArray", "" )]
		public override OperateResult Write( string address, byte[] value ) => MelsecA3CNet1OverTcp.WriteHelper( address, value, ReadWithPackCommand );

		#endregion

		#region Bool Read Write

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.ReadBool(string, ushort)"/>
		[HslMqttApi( "ReadBoolArray", "" )]
		public override OperateResult<bool[]> ReadBool( string address, ushort length ) => MelsecA3CNet1OverTcp.ReadBoolHelper( address, length, ReadWithPackCommand );

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.Write(string, bool[])"/>
		[HslMqttApi( "WriteBoolArray", "" )]
		public override OperateResult Write( string address, bool[] value ) => MelsecA3CNet1OverTcp.WriteHelper( address, value, ReadWithPackCommand );

		#endregion

		#region Remote Operate

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.RemoteRun"/>
		[HslMqttApi]
		public OperateResult RemoteRun( ) => MelsecA3CNet1OverTcp.RemoteRunHelper( ReadWithPackCommand );

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.RemoteStop"/>
		[HslMqttApi]
		public OperateResult RemoteStop( ) => MelsecA3CNet1OverTcp.RemoteStopHelper( ReadWithPackCommand );

		/// <inheritdoc cref="MelsecA3CNet1OverTcp.ReadPlcType"/>
		[HslMqttApi]
		public OperateResult<string> ReadPlcType( ) => MelsecA3CNet1OverTcp.ReadPlcTypeHelper( ReadWithPackCommand );

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString() => $"MelsecA3CNet1[{PortName}:{BaudRate}]";

		#endregion

		#region Private Member

		private byte station = 0x00;                 // PLC的站号信息

		#endregion

	}
}
