﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.App;
using System.Net.Sockets;

namespace HslAppDemo
{
    [Activity( Label = "DebugTcp [Tcp调试]" )]
    public class ActivityDebugTcp : AppCompatActivity
    {
        protected override void OnCreate( Bundle savedInstanceState )
        {
            base.OnCreate( savedInstanceState );

            // Create your application here
            SetContentView( Resource.Layout.layout_debug_tcp );
            
            
            ipAddressText   = FindViewById<EditText>( Resource.Id.editText_ip_address );
            portText        = FindViewById<EditText>( Resource.Id.editText_ip_port );
            btnConnect      = FindViewById<Button>( Resource.Id.button_connect );
            btnDisconnect   = FindViewById<Button>( Resource.Id.button_disconnect );
            checkBox1       = FindViewById<CheckBox>( Resource.Id.checkBox1 );
            checkBox2       = FindViewById<CheckBox>( Resource.Id.checkBox2 );
            checkBox3       = FindViewById<CheckBox>( Resource.Id.checkBox3 );
            textBox5        = FindViewById<EditText>( Resource.Id.textBox5 );
            textBox6        = FindViewById<EditText>( Resource.Id.textBox6 );
            button3         = FindViewById<Button>( Resource.Id.button3 );
            button5         = FindViewById<Button>( Resource.Id.button5 );

            checkBox1.Checked = true;
            checkBox3.Checked = true;
            ipAddressText.Text = AppDemoUtils.GetAppConfigue( "debug_tcp_ip", "192.168.0.100" );
            portText.Text      = AppDemoUtils.GetAppConfigue( "debug_tcp_port", "6000" );

            btnConnect.Click += BtnConnect_Click;
            btnDisconnect.Click += BtnDisconnect_Click;


            button3.Click += Button3_Click;
            button5.Click += Button5_Click;
        }

        private void Button5_Click( object sender, EventArgs e )
        {
            textBox6.Text = "";

        }

        private void Button3_Click( object sender, EventArgs e )
        {
            // 发送数据
            if (socketCore == null) return;

            byte[] send = null;
            if (checkBox1.Checked)
            {
                send = HslCommunication.BasicFramework.SoftBasic.HexStringToBytes( textBox5.Text );
            }
            else
            {
                send = Encoding.ASCII.GetBytes( textBox5.Text.Replace( "\\n", "\r\n" ) );
            }

            if (checkBox2.Checked)
            {
                send = HslCommunication.BasicFramework.SoftBasic.SpliceTwoByteArray( send, new byte[] { 0x0A } );
            }

            if (checkBox3.Checked)
            {
                // 显示发送信息
                    textBox6.Append( "[" + DateTime.Now.ToString( "HH:mm:ss.fff" ) +  "][发]  " + HslCommunication.BasicFramework.SoftBasic.ByteToHexString( send, ' ' ) + System.Environment.NewLine );

            }
            try
            {
                socketCore?.Send( send, 0, send.Length, SocketFlags.None );
            }
            catch (Exception ex)
            {
                AppDemoUtils.ToastMessage( this, ex.Message );
            }
        }

        private void BtnDisconnect_Click( object sender, EventArgs e )
        {
            socketCore?.Close( );
            btnConnect.Enabled = true;
            btnDisconnect.Enabled = false;
        }

        private void BtnConnect_Click( object sender, EventArgs e )
        {
            // 连接服务器
            try
            {
                socketCore?.Close( );
                socketCore = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp );
                connectSuccess = false;
                new System.Threading.Thread( ( ) =>
                {
                    System.Threading.Thread.Sleep( 2000 );
                    if (!connectSuccess) socketCore?.Close( );
                } ).Start( );
                socketCore.Connect( System.Net.IPAddress.Parse( ipAddressText.Text ), int.Parse( portText.Text ) );
                connectSuccess = true;

                socketCore.BeginReceive( buffer, 0, 2048, SocketFlags.None, new AsyncCallback( ReceiveCallBack ), socketCore );
                btnConnect.Enabled = false;
                btnDisconnect.Enabled = true;

                AppDemoUtils.SetAppConfigue( "debug_tcp_ip", ipAddressText.Text );
                AppDemoUtils.SetAppConfigue( "debug_tcp_port", portText.Text );
                AppDemoUtils.ToastMessage( this, HslCommunication.StringResources.Language.ConnectServerSuccess );
            }
            catch (Exception ex)
            {
                AppDemoUtils.ToastMessage( this, HslCommunication.StringResources.Language.ConnectedFailed + System.Environment.NewLine + ex.Message );
            }
        }

        private void ReceiveCallBack( IAsyncResult ar )
        {
            try
            {
                int length = socketCore.EndReceive( ar );
                socketCore.BeginReceive( buffer, 0, 2048, SocketFlags.None, new AsyncCallback( ReceiveCallBack ), socketCore );

                if (length == 0) return;

                byte[] data = new byte[length];
                Array.Copy( buffer, 0, data, 0, length );
                RunOnUiThread( new Action( ( ) =>
                {
                    string msg = string.Empty;
                    if (checkBox1.Checked)
                    {
                        msg = HslCommunication.BasicFramework.SoftBasic.ByteToHexString( data, ' ' );
                    }
                    else
                    {
                        msg = Encoding.ASCII.GetString( data );
                    }


                    textBox6.Append( "[" + DateTime.Now.ToString( "HH:mm:ss.fff" ) + "][收]  " + msg + System.Environment.NewLine );

                } ) );
            }
            catch (ObjectDisposedException)
            {

            }
            catch (Exception ex)
            {
                RunOnUiThread( new Action( ( ) =>
                {
                    AppDemoUtils.ToastMessage( this, "服务器断开连接。");
                    btnConnect.Enabled = true;
                    btnDisconnect.Enabled = false;
                } ) );
            }
        }


        private CheckBox checkBox1 = null;
        private CheckBox checkBox2 = null;
        private CheckBox checkBox3 = null;
        private EditText textBox5 = null;
        private EditText textBox6 = null;
        private Button button3 = null;
        private Button button5 = null;
        private Button btnConnect = null;
        private Button btnDisconnect = null;
        private EditText ipAddressText = null;
        private EditText portText = null;
        private Socket socketCore = null;
        private bool connectSuccess = false;
        private byte[] buffer = new byte[2048];

    }
}