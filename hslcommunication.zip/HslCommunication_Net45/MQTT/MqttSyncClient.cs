﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HslCommunication.Core.Net;
using HslCommunication.Core.IMessage;
using HslCommunication.Core;
using System.Net.Sockets;
using HslCommunication.BasicFramework;
using System.Net;
using HslCommunication.Profinet.Panasonic;
using HslCommunication.Reflection;
using Newtonsoft.Json.Linq;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.MQTT
{
	/// <summary>
	/// 基于MQTT协议的同步访问的客户端程序，支持以同步的方式访问服务器的数据信息，并及时的反馈结果<br />
	/// The client program based on MQTT protocol for synchronous access supports synchronous access to the server's data information and timely feedback of results
	/// </summary>
	/// <example>
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttSyncClientSample.cs" region="Test" title="简单的实例化" />
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttSyncClientSample.cs" region="Test2" title="带用户名密码的实例化" />
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttSyncClientSample.cs" region="Test3" title="连接示例" />
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttSyncClientSample.cs" region="Test4" title="读取数据示例" />
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\MQTT\MqttSyncClientSample.cs" region="Test5" title="带进度报告示例" />
	/// </example>
	public class MqttSyncClient : NetworkDoubleBase
	{
		#region Constructor

		/// <summary>
		/// 实例化一个MQTT的同步客户端<br />
		/// Instantiate an MQTT synchronization client
		/// </summary>
		public MqttSyncClient( MqttConnectionOptions options )
		{
			this.ByteTransform     = new RegularByteTransform( );
			this.connectionOptions = options;
			this.IpAddress         = options.IpAddress;
			this.Port              = options.Port;
			this.incrementCount    = new SoftIncrementCount( ushort.MaxValue, 1 );
			this.ConnectTimeOut    = options.ConnectTimeout;
			this.receiveTimeOut    = 60_000;
		}

		/// <summary>
		/// 通过指定的ip地址及端口来实例化一个同步的MQTT客户端<br />
		/// Instantiate a synchronized MQTT client with the specified IP address and port
		/// </summary>
		/// <param name="ipAddress">IP地址信息</param>
		/// <param name="port">端口号信息</param>
		public MqttSyncClient(string ipAddress, int port )
		{
			this.connectionOptions = new MqttConnectionOptions( ) { 
				IpAddress = ipAddress,
				Port = port
			};
			this.ByteTransform     = new RegularByteTransform( );
			this.IpAddress         = ipAddress;
			this.Port              = port;
			this.incrementCount    = new SoftIncrementCount( ushort.MaxValue, 1 );
			this.receiveTimeOut    = 60_000;
		}

		/// <summary>
		/// 通过指定的ip地址及端口来实例化一个同步的MQTT客户端<br />
		/// Instantiate a synchronized MQTT client with the specified IP address and port
		/// </summary>
		/// <param name="ipAddress">IP地址信息</param>
		/// <param name="port">端口号信息</param>
		public MqttSyncClient( IPAddress ipAddress, int port )
		{
			this.connectionOptions = new MqttConnectionOptions( )
			{
				IpAddress = ipAddress.ToString( ),
				Port = port
			};
			this.ByteTransform = new RegularByteTransform( );
			this.IpAddress = ipAddress.ToString( );
			this.Port = port;
			this.incrementCount = new SoftIncrementCount( ushort.MaxValue, 1 );
		}

		#endregion

		#region InitializationOnConnect

		/// <inheritdoc/>
		protected override OperateResult InitializationOnConnect( Socket socket )
		{
			OperateResult<byte[]> command = MqttHelper.BuildConnectMqttCommand( this.connectionOptions, "HUSL" );
			if (!command.IsSuccess) return command;

			// 发送连接的报文信息
			OperateResult send = Send( socket, command.Content );
			if (!send.IsSuccess) return send;

			// 接收服务器端注册返回的报文信息
			OperateResult<byte, byte[]> receive = ReceiveMqttMessage( socket, ReceiveTimeOut );
			if (!receive.IsSuccess) return receive;

			// 检查连接的返回状态是否正确
			OperateResult check = MqttHelper.CheckConnectBack( receive.Content1, receive.Content2 );
			if (!check.IsSuccess) { socket?.Close( ); return check; }

			this.incrementCount.ResetCurrentValue( );          // 重置消息计数
			return OperateResult.CreateSuccessResult( );
		}

		#endregion

		#region InitializationOnConnect Async
#if !NET35 && !NET20
		/// <inheritdoc/>
		protected async override Task<OperateResult> InitializationOnConnectAsync( Socket socket )
		{
			OperateResult<byte[]> command = MqttHelper.BuildConnectMqttCommand( this.connectionOptions, "HUSL" );
			if (!command.IsSuccess) return command;

			// 发送连接的报文信息
			OperateResult send = await SendAsync( socket, command.Content );
			if (!send.IsSuccess) return send;

			// 接收服务器端注册返回的报文信息
			OperateResult<byte, byte[]> receive = await ReceiveMqttMessageAsync( socket, ReceiveTimeOut );
			if (!receive.IsSuccess) return receive;

			// 检查连接的返回状态是否正确
			OperateResult check = MqttHelper.CheckConnectBack( receive.Content1, receive.Content2 );
			if (!check.IsSuccess) { socket?.Close( ); return check; }

			this.incrementCount.ResetCurrentValue( );          // 重置消息计数
			return OperateResult.CreateSuccessResult( );
		}
#endif
		#endregion

		#region NetworkDoubleBase Override

		/// <inheritdoc/>
		public override OperateResult<byte[]> ReadFromCoreServer( Socket socket, byte[] send, bool hasResponseData = true )
		{
			var read = ReadMqttFromCoreServer( socket, send, null, null, null );
			if (read.IsSuccess) return OperateResult.CreateSuccessResult( read.Content2 );

			return OperateResult.CreateFailedResult<byte[]>( read );
		}

		private OperateResult<byte, byte[]> ReadMqttFromCoreServer( Socket socket, byte[] send, Action<long, long> sendProgress, Action<string, string> handleProgress, Action<long, long> receiveProgress )
		{
			OperateResult sendResult = Send( socket, send );
			if (!sendResult.IsSuccess) return OperateResult.CreateFailedResult<byte, byte[]>( sendResult );

			// 先确认对方是否接收完数据
			while (true)
			{
				OperateResult<byte, byte[]> server_receive = ReceiveMqttMessage( socket, ReceiveTimeOut );
				if (!server_receive.IsSuccess) return server_receive;

				OperateResult<string, byte[]> server_back = MqttHelper.ExtraMqttReceiveData( server_receive.Content1, server_receive.Content2 );
				if (!server_back.IsSuccess) return OperateResult.CreateFailedResult<byte, byte[]>( server_back );

				if (server_back.Content2.Length != 16) return new OperateResult<byte, byte[]>( StringResources.Language.ReceiveDataLengthTooShort );
				long already = BitConverter.ToInt64( server_back.Content2, 0 );
				long total = BitConverter.ToInt64( server_back.Content2, 8 );
				sendProgress?.Invoke( already, total );
				if (already == total) break;
			}

			// 如果接收到进度报告，就继续接收，直到不是进度报告的数据为止
			while (true)
			{
				OperateResult<byte, byte[]> receive = ReceiveMqttMessage( socket, ReceiveTimeOut, receiveProgress );
				if (!receive.IsSuccess) return receive;

				if (receive.Content1 >> 4 == MqttControlMessage.REPORTPROGRESS)
				{
					OperateResult<string, byte[]> extra = MqttHelper.ExtraMqttReceiveData( receive.Content1, receive.Content2 );
					handleProgress?.Invoke( extra.Content1, Encoding.UTF8.GetString( extra.Content2 ) );
				}
				else
				{
					return OperateResult.CreateSuccessResult( receive.Content1, receive.Content2 );
				}
			}
		}

		private OperateResult<byte[]> ReadMqttFromCoreServer( byte[] send, Action<long, long> sendProgress, Action<string, string> handleProgress, Action<long, long> receiveProgress )
		{
			var result = new OperateResult<byte[]>( );
			OperateResult<Socket> resultSocket = null;
			InteractiveLock.Enter( );

			try
			{
				// 获取有用的网络通道，如果没有，就建立新的连接
				resultSocket = GetAvailableSocket( );
				if (!resultSocket.IsSuccess)
				{
					IsSocketError = true;
					AlienSession?.Offline( );
					InteractiveLock.Leave( );
					result.CopyErrorFromOther( resultSocket );
					return result;
				}

				OperateResult<byte, byte[]> read = ReadMqttFromCoreServer( resultSocket.Content, send, sendProgress, handleProgress, receiveProgress );
				if (read.IsSuccess)
				{
					IsSocketError = false;
					if (read.Content1 >> 4 == MqttControlMessage.FAILED)
					{
						OperateResult<string, byte[]> extra = MqttHelper.ExtraMqttReceiveData( read.Content1, read.Content2 );
						result.IsSuccess = false;
						result.ErrorCode = int.Parse( extra.Content1 );
						result.Message = Encoding.UTF8.GetString( extra.Content2 );
					}
					else
					{
						result.IsSuccess = read.IsSuccess;
						result.Content = read.Content2;
						result.Message = StringResources.Language.SuccessText;
					}
				}
				else
				{
					IsSocketError = true;
					AlienSession?.Offline( );
					result.CopyErrorFromOther( read );
				}

				ExtraAfterReadFromCoreServer( read );
				InteractiveLock.Leave( );
			}
			catch
			{
				InteractiveLock.Leave( );
				throw;
			}

			if (!isPersistentConn) resultSocket?.Content?.Close( );
			return result;
		}

#if !NET35 && !NET20
		/// <inheritdoc/>
		public async override Task<OperateResult<byte[]>> ReadFromCoreServerAsync( Socket socket, byte[] send, bool hasResponseData = true )
		{
			var read = await ReadMqttFromCoreServerAsync( socket, send, null, null, null );
			if (read.IsSuccess) return OperateResult.CreateSuccessResult( read.Content2 );

			return OperateResult.CreateFailedResult<byte[]>( read );
		}

		private async Task<OperateResult<byte, byte[]>> ReadMqttFromCoreServerAsync( Socket socket, byte[] send, Action<long, long> sendProgress, Action<string, string> handleProgress, Action<long, long> receiveProgress )
		{
			OperateResult sendResult = await SendAsync( socket, send );
			if (!sendResult.IsSuccess) return OperateResult.CreateFailedResult<byte, byte[]>( sendResult );

			// 先确认对方是否接收完数据
			while (true)
			{
				OperateResult<byte, byte[]> server_receive = await ReceiveMqttMessageAsync( socket, ReceiveTimeOut );
				if (!server_receive.IsSuccess) return server_receive;

				OperateResult<string, byte[]> server_back = MqttHelper.ExtraMqttReceiveData( server_receive.Content1, server_receive.Content2 );
				if (!server_back.IsSuccess) return OperateResult.CreateFailedResult<byte, byte[]>( server_back );

				if (server_back.Content2.Length != 16) return new OperateResult<byte, byte[]>( StringResources.Language.ReceiveDataLengthTooShort );
				long already = BitConverter.ToInt64( server_back.Content2, 0 );
				long total = BitConverter.ToInt64( server_back.Content2, 8 );
				sendProgress?.Invoke( already, total );
				if (already == total) break;
			}

			// 如果接收到进度报告，就继续接收，直到不是进度报告的数据为止
			while (true)
			{
				OperateResult<byte, byte[]> receive = await ReceiveMqttMessageAsync( socket, ReceiveTimeOut, receiveProgress );
				if (!receive.IsSuccess) return receive;

				if (receive.Content1 >> 4 == MqttControlMessage.REPORTPROGRESS)
				{
					OperateResult<string, byte[]> extra = MqttHelper.ExtraMqttReceiveData( receive.Content1, receive.Content2 );
					handleProgress?.Invoke( extra.Content1, Encoding.UTF8.GetString( extra.Content2 ) );
				}
				else
				{
					return OperateResult.CreateSuccessResult( receive.Content1, receive.Content2 );
				}
			}
		}

		private async Task<OperateResult<byte[]>> ReadMqttFromCoreServerAsync( byte[] send, Action<long, long> sendProgress, Action<string, string> handleProgress, Action<long, long> receiveProgress )
		{
			var result = new OperateResult<byte[]>( );
			OperateResult<Socket> resultSocket = null;
			InteractiveLock.Enter( );

			try
			{
				// 获取有用的网络通道，如果没有，就建立新的连接
				resultSocket = await GetAvailableSocketAsync( );
				if (!resultSocket.IsSuccess)
				{
					IsSocketError = true;
					AlienSession?.Offline( );
					InteractiveLock.Leave( );
					result.CopyErrorFromOther( resultSocket );
					return result;
				}

				OperateResult<byte, byte[]> read = await ReadMqttFromCoreServerAsync( resultSocket.Content, send, sendProgress, handleProgress, receiveProgress );
				if (read.IsSuccess)
				{
					IsSocketError = false;
					if (read.Content1 >> 4 == MqttControlMessage.FAILED)
					{
						OperateResult<string, byte[]> extra = MqttHelper.ExtraMqttReceiveData( read.Content1, read.Content2 );
						result.IsSuccess = false;
						result.ErrorCode = int.Parse( extra.Content1 );
						result.Message = Encoding.UTF8.GetString( extra.Content2 );
					}
					else
					{
						result.IsSuccess = read.IsSuccess;
						result.Content = read.Content2;
						result.Message = StringResources.Language.SuccessText;
					}
				}
				else
				{
					IsSocketError = true;
					AlienSession?.Offline( );
					result.CopyErrorFromOther( read );
				}

				ExtraAfterReadFromCoreServer( read );
				InteractiveLock.Leave( );
			}
			catch
			{
				InteractiveLock.Leave( );
				throw;
			}
			if (!isPersistentConn) resultSocket?.Content?.Close( );
			return result;
		}
#endif
		#endregion

		#region Public Method

		/// <summary>
		/// 从MQTT服务器同步读取数据，将payload发送到服务器，然后从服务器返回相关的数据，支持数据发送进度报告，服务器执行进度报告，接收数据进度报告操作<br />
		/// Synchronously read data from the MQTT server, send the payload to the server, and then return relevant data from the server, 
		/// support data transmission progress report, the server executes the progress report, and receives the data progress report
		/// </summary>
		/// <remarks>
		/// 进度报告可以实现一个比较有意思的功能，可以用来数据的上传和下载，提供一个友好的进度条，因为网络的好坏通常是不确定的。
		/// </remarks>
		/// <param name="topic">主题信息</param>
		/// <param name="payload">负载数据</param>
		/// <param name="sendProgress">发送数据给服务器时的进度报告，第一个参数为已发送数据，第二个参数为总发送数据</param>
		/// <param name="handleProgress">服务器处理数据的进度报告，第一个参数Topic自定义，通常用来传送操作百分比，第二个参数自定义，通常用来表示服务器消息</param>
		/// <param name="receiveProgress">从服务器接收数据的进度报告，第一个参数为已接收数据，第二个参数为总接收数据</param>
		/// <returns>服务器返回的数据信息</returns>
		public OperateResult<string, byte[]> Read(string topic, byte[] payload, 
			Action<long, long> sendProgress = null, 
			Action<string, string> handleProgress = null, 
			Action<long, long> receiveProgress = null )
		{
			OperateResult<byte[]> command = MqttHelper.BuildPublishMqttCommand( topic, payload );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<string, byte[]>( command );

			OperateResult<byte[]> read = ReadMqttFromCoreServer( command.Content, sendProgress, handleProgress, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string, byte[]>( read );

			return MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
		}

		/// <summary>
		/// 从MQTT服务器同步读取数据，将指定编码的字符串payload发送到服务器，然后从服务器返回相关的数据，并转换为指定编码的字符串，支持数据发送进度报告，服务器执行进度报告，接收数据进度报告操作<br />
		/// Synchronously read data from the MQTT server, send the specified encoded string payload to the server, 
		/// and then return the data from the server, and convert it to the specified encoded string,
		/// support data transmission progress report, the server executes the progress report, and receives the data progress report
		/// </summary>
		/// <param name="topic">主题信息</param>
		/// <param name="payload">负载数据</param>
		/// <param name="sendProgress">发送数据给服务器时的进度报告，第一个参数为已发送数据，第二个参数为总发送数据</param>
		/// <param name="handleProgress">服务器处理数据的进度报告，第一个参数Topic自定义，通常用来传送操作百分比，第二个参数自定义，通常用来表示服务器消息</param>
		/// <param name="receiveProgress">从服务器接收数据的进度报告，第一个参数为已接收数据，第二个参数为总接收数据</param>
		/// <returns>服务器返回的数据信息</returns>
		public OperateResult<string, string> ReadString( string topic, string payload,
			Action<long, long> sendProgress = null,
			Action<string, string> handleProgress = null,
			Action<long, long> receiveProgress = null )
		{
			OperateResult<string, byte[]> read = Read( topic, string.IsNullOrEmpty( payload ) ? null : stringEncoding.GetBytes( payload ),
				sendProgress, handleProgress, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string, string>( read );

			return OperateResult.CreateSuccessResult( read.Content1, stringEncoding.GetString( read.Content2 ) );
		}

		/// <summary>
		/// 读取服务器的已经注册的API信息列表，将返回API的主题路径，注释信息，示例的传入的数据信息。<br />
		/// Read the registered API information list of the server, and return the API subject path, annotation information, and sample incoming data information.
		/// </summary>
		/// <returns>包含是否成功的api信息的列表</returns>
		public OperateResult<MqttRpcApiInfo[]> ReadRpcApis( )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.SUBSCRIBE, 0x00, MqttHelper.BuildSegCommandByString( "" ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( command );

			OperateResult<byte[]> read = ReadMqttFromCoreServer( command.Content, null, null, null );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if(!mqtt.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( mqtt );

			return OperateResult.CreateSuccessResult( JArray.Parse( Encoding.UTF8.GetString( mqtt.Content2 ) ).ToObject<MqttRpcApiInfo[]>( ) );
		}

		/// <summary>
		/// 读取服务器的已经驻留的所有消息的主题列表<br />
		/// Read the topic list of all messages that have resided on the server
		/// </summary>
		/// <returns>消息列表对象</returns>
		public OperateResult<string[]> ReadRetainTopics( )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.PUBACK, 0x00, MqttHelper.BuildSegCommandByString( "" ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<string[]>( command );

			OperateResult<byte[]> read = ReadMqttFromCoreServer( command.Content, null, null, null );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string[]>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if (!mqtt.IsSuccess) return OperateResult.CreateFailedResult<string[]>( mqtt );

			return OperateResult.CreateSuccessResult( HslProtocol.UnPackStringArrayFromByte( mqtt.Content2 ) );
		}

		/// <summary>
		/// 读取服务器的已经驻留的指定主题的消息内容<br />
		/// Read the topic list of all messages that have resided on the server
		/// </summary>
		/// <param name="topic">指定的主题消息</param>
		/// <param name="receiveProgress">结果进度报告</param>
		/// <returns>消息列表对象</returns>
		public OperateResult<MqttClientApplicationMessage> ReadTopicPayload( string topic, Action<long, long> receiveProgress = null )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.PUBREC, 0x00, MqttHelper.BuildSegCommandByString( topic ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( command );

			OperateResult<byte[]> read = ReadMqttFromCoreServer( command.Content, null, null, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if (!mqtt.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( mqtt );

			return OperateResult.CreateSuccessResult( JObject.Parse( Encoding.UTF8.GetString( mqtt.Content2 ) ).ToObject<MqttClientApplicationMessage>( ) );
		}

		#endregion

		#region Public Method Async
#if !NET35 && !NET20
		/// <inheritdoc cref="Read(string, byte[], Action{long, long}, Action{string, string}, Action{long, long})"/>
		public async Task<OperateResult<string, byte[]>> ReadAsync( string topic, byte[] payload,
			Action<long, long> sendProgress = null,
			Action<string, string> handleProgress = null,
			Action<long, long> receiveProgress = null )
		{
			OperateResult<byte[]> command = MqttHelper.BuildPublishMqttCommand( topic, payload );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<string, byte[]>( command );

			OperateResult<byte[]> read = await ReadMqttFromCoreServerAsync( command.Content, sendProgress, handleProgress, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string, byte[]>( read );

			return MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
		}

		/// <inheritdoc cref="ReadString(string, string, Action{long, long}, Action{string, string}, Action{long, long})"/>
		public async Task<OperateResult<string, string>> ReadStringAsync( string topic, string payload,
			Action<long, long> sendProgress = null,
			Action<string, string> handleProgress = null,
			Action<long, long> receiveProgress = null )
		{
			OperateResult<string, byte[]> read = await ReadAsync( topic, string.IsNullOrEmpty( payload ) ? null : stringEncoding.GetBytes( payload ),
				sendProgress, handleProgress, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string, string>( read );

			return OperateResult.CreateSuccessResult( read.Content1, stringEncoding.GetString( read.Content2 ) );
		}

		/// <inheritdoc cref="ReadRpcApis"/>
		public async Task<OperateResult<MqttRpcApiInfo[]>> ReadRpcApisAsync( )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.SUBSCRIBE, 0x00, MqttHelper.BuildSegCommandByString( "" ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( command );

			OperateResult<byte[]> read = await ReadMqttFromCoreServerAsync( command.Content, null, null, null );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if (!mqtt.IsSuccess) return OperateResult.CreateFailedResult<MqttRpcApiInfo[]>( mqtt );

			return OperateResult.CreateSuccessResult( JArray.Parse( Encoding.UTF8.GetString( mqtt.Content2 ) ).ToObject<MqttRpcApiInfo[]>( ) );
		}

		/// <inheritdoc cref="ReadRetainTopics"/>
		public async Task<OperateResult<string[]>> ReadRetainTopicsAsync( )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.PUBACK, 0x00, MqttHelper.BuildSegCommandByString( "" ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<string[]>( command );

			OperateResult<byte[]> read = await ReadMqttFromCoreServerAsync( command.Content, null, null, null );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string[]>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if (!mqtt.IsSuccess) return OperateResult.CreateFailedResult<string[]>( mqtt );

			return OperateResult.CreateSuccessResult( HslProtocol.UnPackStringArrayFromByte( mqtt.Content2 ) );
		}

		/// <inheritdoc cref="ReadTopicPayload(string, Action{long, long})"/>
		public async Task<OperateResult<MqttClientApplicationMessage>> ReadTopicPayloadAsync( string topic, Action<long, long> receiveProgress = null )
		{
			OperateResult<byte[]> command = MqttHelper.BuildMqttCommand( MqttControlMessage.PUBREC, 0x00, MqttHelper.BuildSegCommandByString( topic ), null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( command );

			OperateResult<byte[]> read = await ReadMqttFromCoreServerAsync( command.Content, null, null, receiveProgress );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( read );

			OperateResult<string, byte[]> mqtt = MqttHelper.ExtraMqttReceiveData( MqttControlMessage.PUBLISH, read.Content );
			if (!mqtt.IsSuccess) return OperateResult.CreateFailedResult<MqttClientApplicationMessage>( mqtt );

			return OperateResult.CreateSuccessResult( JObject.Parse( Encoding.UTF8.GetString( mqtt.Content2 ) ).ToObject<MqttClientApplicationMessage>( ) );
		}

#endif
		#endregion

		#region Public Properties

		/// <summary>
		/// 获取或设置当前的连接信息，客户端将根据这个连接配置进行连接服务器，在连接之前需要设置相关的信息才有效。<br />
		/// To obtain or set the current connection information, the client will connect to the server according to this connection configuration. 
		/// Before connecting, the relevant information needs to be set to be effective.
		/// </summary>
		public MqttConnectionOptions ConnectionOptions
		{
			get => connectionOptions;
			set => connectionOptions = value;
		}

		/// <summary>
		/// 获取或设置使用字符串访问的时候，使用的编码信息，默认为UT8编码<br />
		/// Get or set the encoding information used when accessing with a string, the default is UT8 encoding
		/// </summary>
		public Encoding StringEncoding
		{
			get => stringEncoding;
			set => stringEncoding = value;
		}

		#endregion

		#region Private Member

		private SoftIncrementCount incrementCount;                            // 自增的数据id对象
		private MqttConnectionOptions connectionOptions;                      // 连接服务器时的配置信息
		private Encoding stringEncoding = Encoding.UTF8;                      // 使用字符串通信时的编码

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString( ) => $"MqttSyncClient[{this.connectionOptions.IpAddress}:{this.connectionOptions.Port}]";

		#endregion
	}
}
