﻿using HslCommunication.Reflection;
using HslCommunication.Serial;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace HslCommunication.Profinet.Keyence
{
	/// <inheritdoc cref="KeyenceSR2000SeriesTcp"/>
	public class KeyenceSR2000Serial : SerialBase, IKeyenceSR2000Series
	{
		/// <inheritdoc cref="KeyenceSR2000SeriesTcp()"/>
		public KeyenceSR2000Serial( ) : base( ) { ReceiveTimeout = 10_000; SleepTime = 20; }

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadBarcode(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<string> ReadBarcode( ) => KeyenceSR2000Helper.ReadBarcode( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.Reset(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult Reset( ) => KeyenceSR2000Helper.Reset( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.OpenIndicator(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult OpenIndicator( ) => KeyenceSR2000Helper.OpenIndicator( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.CloseIndicator(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult CloseIndicator( ) => KeyenceSR2000Helper.CloseIndicator( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadVersion(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<string> ReadVersion( ) => KeyenceSR2000Helper.ReadVersion( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadCommandState(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<string> ReadCommandState( ) => KeyenceSR2000Helper.ReadCommandState( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadErrorState(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<string> ReadErrorState( ) => KeyenceSR2000Helper.ReadErrorState( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.CheckInput(int, Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<bool> CheckInput( int number ) => KeyenceSR2000Helper.CheckInput( number, ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.SetOutput(int, bool, Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult SetOutput( int number, bool value ) => KeyenceSR2000Helper.SetOutput( number, value, ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadRecord(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<int[]> ReadRecord( ) => KeyenceSR2000Helper.ReadRecord( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.Lock(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult Lock( ) => KeyenceSR2000Helper.Lock( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.UnLock(Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult UnLock( ) => KeyenceSR2000Helper.UnLock( ReadBase );

		/// <inheritdoc cref="KeyenceSR2000Helper.ReadCustomer(string, Func{byte[], OperateResult{byte[]}})"/>
		[HslMqttApi]
		public OperateResult<string> ReadCustomer( string command ) => KeyenceSR2000Helper.ReadCustomer( command, ReadBase );

		/// <inheritdoc/>
		public override string ToString( ) => $"KeyenceSR2000Serial[{PortName}:{BaudRate}]";
	}
}
