﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using HslCommunication.LogNet;
using HslCommunication.BasicFramework;
using Newtonsoft.Json.Linq;
using System.Reflection;
using HslCommunication.Core.Net;
using HslCommunication.Reflection;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.Enthernet
{
	/// <summary>
	/// 一个支持完全自定义的Http服务器，支持返回任意的数据信息，方便调试信息，详细的案例请查看API文档信息<br />
	/// A Http server that supports fully customized, supports returning arbitrary data information, which is convenient for debugging information. For detailed cases, please refer to the API documentation information
	/// </summary>
	/// <example>
	/// 我们先来看看一个最简单的例子，如何进行实例化的操作。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\Enthernet\HttpServerSample.cs" region="Sample1" title="基本的实例化" />
	/// 通常来说，基本的实例化，返回固定的数据并不能满足我们的需求，我们需要返回自定义的数据，有一个委托，我们需要自己指定方法.
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\Enthernet\HttpServerSample.cs" region="Sample2" title="自定义返回" />
	/// 我们实际的需求可能会更加的复杂，不同的网址会返回不同的数据，所以接下来我们需要对网址信息进行判断。
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\Enthernet\HttpServerSample.cs" region="Sample3" title="区分网址" />
	/// 如果我们想增加安全性的验证功能，比如我们的api接口需要增加用户名和密码的功能，那么我们也可以实现
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\Enthernet\HttpServerSample.cs" region="Sample4" title="安全实现" />
	/// 当然了，如果我们想反回一个完整的html网页，也是可以实现的，甚至添加一些js的脚本，下面的例子就简单的说明了如何操作
	/// <code lang="cs" source="HslCommunication_Net45.Test\Documentation\Samples\Enthernet\HttpServerSample.cs" region="Sample5" title="返回html" />
	/// 如果需要实现跨域的操作，可以将属性<see cref="IsCrossDomain"/> 设置为<c>True</c>
	/// </example>
	public class HttpServer
	{
		#region Constrcutor

		/// <summary>
		/// 实例化一个默认的对象，当前的运行，需要使用管理员的模式运行<br />
		/// Instantiate a default object, the current operation, you need to use the administrator mode to run
		/// </summary>
		public HttpServer( )
		{

		}

		#endregion

		/// <summary>
		/// 启动服务器，正常调用该方法时，应该使用try...catch...来捕获错误信息<br />
		/// Start the server and use try...catch... to capture the error message when calling this method normally
		/// </summary>
		/// <param name="port">端口号信息</param>
		/// <exception cref="HttpListenerException"></exception>
		/// <exception cref="ObjectDisposedException"></exception>
		public void Start( int port )
		{
			this.port = port;
			this.listener = new HttpListener( );
			this.listener.Prefixes.Add( $"http://+:{port}/" );
			this.listener.Start( );
			this.listener.BeginGetContext( GetConnectCallBack, this.listener );
			this.logNet?.WriteDebug( $"{ToString( )} Server Started, wait for connections" );
		}

		/// <summary>
		/// 关闭服务器<br />
		/// Shut down the server
		/// </summary>
		public void Close( )
		{
			this.listener?.Close( );
		}
#if NET35 || NET20
		private void GetConnectCallBack( IAsyncResult ar )
		{
			if (ar.AsyncState is HttpListener listener)
			{
				HttpListenerContext context = null;
				try
				{
					context = listener.EndGetContext( ar );
				}
				catch (Exception ex)
				{
					logNet?.WriteException( ToString( ), ex );
				}

				int restartcount = 0;
				while (true)
				{
					try
					{
						listener.BeginGetContext( GetConnectCallBack, listener );
						break;
					}
					catch (Exception ex)
					{
						logNet?.WriteException( ToString( ), ex );
						restartcount++;
						if(restartcount >= 3)
						{
							logNet?.WriteError( ToString( ) + " ReGet Content Failed!" );
							return;
						}
						System.Threading.Thread.Sleep( 1000 );
					}
				}

				if (context == null) return;
				var request = context.Request;
				var response = context.Response;

				if (response != null)
				{
					try
					{
						if (IsCrossDomain)
						{
							// 如果是js的ajax请求，还可以设置跨域的ip地址与参数
							context.Response.AppendHeader( "Access-Control-Allow-Origin", request.Headers["Origin"] );           //后台跨域请求，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Headers", "*" );                                //后台跨域参数设置，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Method", "POST,GET,PUT,OPTIONS,DELETE" );       //后台跨域请求设置，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Credentials", "true" );
							context.Response.AppendHeader( "Access-Control-Max-Age", "3600" );
						}
						context.Response.AddHeader( "Content-type", "Content-Type: text/html; charset=utf-8" ); // 添加响应头信息
						//context.Response.ContentType = "Content-Type: text/html; charset=utf-8";
						//context.Response.ContentEncoding = encoding;
					}
					catch(Exception ex)
					{
						logNet?.WriteError( ToString( ), ex.Message );
					}
				}

				string data = GetDataFromRequest( request );
				response.StatusCode = 200;
				try
				{
					string ret = HandleRequest( request, response, data );
					using (var stream = response.OutputStream)
					{
						// 把处理信息返回到客户端
						if (string.IsNullOrEmpty( ret ))
						{
							stream.Write( new byte[0], 0, 0 );
						}
						else
						{
							byte[] buffer = encoding.GetBytes( ret );
							stream.Write( buffer, 0, buffer.Length );
						}
					}
		
					this.logNet?.WriteDebug( $"{ToString( )} New Request [{request.HttpMethod}], {request.RawUrl}" );
				}
				catch (Exception ex)
				{
					logNet?.WriteException( $"{ToString( )} Handle Request[{request.HttpMethod}], {request.RawUrl}", ex );
				}
			}
		}
#else
		private async void GetConnectCallBack( IAsyncResult ar )
		{
			if (ar.AsyncState is HttpListener listener)
			{
				HttpListenerContext context = null;
				try
				{
					context = listener.EndGetContext( ar );
				}
				catch (Exception ex)
				{
					logNet?.WriteException( ToString( ), ex );
				}

				int restartcount = 0;
				while (true)
				{
					try
					{
						listener.BeginGetContext( GetConnectCallBack, listener );
						break;
					}
					catch (Exception ex)
					{
						logNet?.WriteException( ToString( ), ex );
						restartcount++;
						if (restartcount >= 3)
						{
							logNet?.WriteError( ToString( ) + " ReGet Content Failed!" );
							return;
						}
						System.Threading.Thread.Sleep( 1000 );
					}
				}

				if (context == null) return;
				var request = context.Request;
				var response = context.Response;

				if (response != null)
				{
					try
					{
						if (IsCrossDomain)
						{
							// 如果是js的ajax请求，还可以设置跨域的ip地址与参数
							context.Response.AppendHeader( "Access-Control-Allow-Origin", request.Headers["Origin"] );           //后台跨域请求，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Headers", "*" );                                //后台跨域参数设置，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Method", "POST,GET,PUT,OPTIONS,DELETE" );       //后台跨域请求设置，通常设置为配置文件
							context.Response.AppendHeader( "Access-Control-Allow-Credentials", "true" );
							context.Response.AppendHeader( "Access-Control-Max-Age", "3600" );
						}
						context.Response.AddHeader( "Content-type", "Content-Type: text/html; charset=utf-8" ); // 添加响应头信息
						//context.Response.ContentType = "Content-Type: text/html; charset=utf-8";
						//context.Response.ContentEncoding = encoding;
					}
					catch (Exception ex)
					{
						logNet?.WriteError( ToString( ), ex.Message );
					}
				}

				string data = await GetDataFromRequestAsync( request );
				response.StatusCode = 200;
				try
				{
					string ret = HandleRequest( request, response, data );
					using (var stream = response.OutputStream)
					{
						// 把处理信息返回到客户端
						if (string.IsNullOrEmpty( ret ))
						{
							await stream.WriteAsync( new byte[0], 0, 0 );
						}
						else
						{
							byte[] buffer = encoding.GetBytes( ret );
							await stream.WriteAsync( buffer, 0, buffer.Length );
						}
					}

					this.logNet?.WriteDebug( $"{ToString( )} New Request [{request.HttpMethod}], {request.RawUrl}" );
				}
				catch (Exception ex)
				{
					logNet?.WriteException( $"{ToString( )} Handle Request[{request.HttpMethod}], {request.RawUrl}", ex );
				}
			}
		}
#endif
		private string GetDataFromRequest( HttpListenerRequest request )
		{
			try
			{
				var byteList = new List<byte>( );
				var byteArr = new byte[receiveBufferSize];
				int readLen = 0;
				int len = 0;
				// 接收客户端传过来的数据并转成字符串类型
				do
				{
					readLen = request.InputStream.Read( byteArr, 0, byteArr.Length );
					len += readLen;
					byteList.AddRange( SoftBasic.ArraySelectBegin( byteArr, readLen ) );
				} 
				while (readLen != 0);
				return encoding.GetString( byteList.ToArray( ), 0, len );
			}
			catch
			{
				return string.Empty;
			}
		}

#if !NET35 && !NET20
		private async Task<string> GetDataFromRequestAsync( HttpListenerRequest request )
		{
			try
			{
				var byteList = new List<byte>( );
				var byteArr = new byte[receiveBufferSize];
				int readLen = 0;
				int len = 0;
				// 接收客户端传过来的数据并转成字符串类型
				do
				{
					readLen = await request.InputStream.ReadAsync( byteArr, 0, byteArr.Length );
					len += readLen;
					byteList.AddRange( SoftBasic.ArraySelectBegin( byteArr, readLen ) );
				} 
				while (readLen != 0);
				return encoding.GetString( byteList.ToArray( ), 0, len );
			}
			catch
			{
				return string.Empty;
			}
		}
#endif

		/// <summary>
		/// 根据客户端的请求进行处理的核心方法，可以返回自定义的数据内容，只需要集成重写即可。<br />
		/// The core method of processing according to the client's request can return custom data content, and only needs to be integrated and rewritten.
		/// </summary>
		/// <param name="request">请求</param>
		/// <param name="response">回应</param>
		/// <param name="data">Body数据</param>
		/// <returns>返回的内容</returns>
		protected virtual string HandleRequest( HttpListenerRequest request, HttpListenerResponse response, string data )
		{
			if (HandleRequestFunc != null) return HandleRequestFunc.Invoke( request, response, data );
			return "This is HslWebServer, Thank you for use!";
		}

		#region Public Properties

		/// <inheritdoc cref="NetworkBase.LogNet"/>
		public ILogNet LogNet
		{
			get => logNet;
			set => logNet = value;
		}

		/// <summary>
		/// 获取或设置当前服务器的编码信息，默认为UTF8编码<br />
		/// Get or set the encoding information of the current server, the default is UTF8 encoding
		/// </summary>
		public Encoding ServerEncoding
		{
			get => encoding;
			set => encoding = value;
		}

		/// <summary>
		/// 获取或设置是否支持跨域操作<br />
		/// Get or set whether to support cross-domain operations
		/// </summary>
		public bool IsCrossDomain
		{
			get;
			set;
		}

		/// <summary>
		/// 获取或设置当前的自定义的处理信息，如果不想继承实现方法，可以使用本属性来关联你自定义的方法。<br />
		/// Get or set the current custom processing information. If you don't want to inherit the implementation method, you can use this attribute to associate your custom method.
		/// </summary>
		public Func<HttpListenerRequest, HttpListenerResponse, string, string> HandleRequestFunc
		{
			get => handleRequestFunc;
			set => handleRequestFunc = value;
		}

		/// <summary>
		/// 获取当前的端口号信息<br />
		/// Get current port number information
		/// </summary>
		public int Port => port;

		#endregion

		#region Private Member

		private int receiveBufferSize = 2048;                                                          // 接收的缓存大小
		private int port = 80;                                                                         // 当前服务器的端口号
		private HttpListener listener;                                                                 // 侦听的服务器信息
		private ILogNet logNet;                                                                        // 日志信息
		private Encoding encoding = Encoding.UTF8;                                                     // 当前系统的编码
		private Func<HttpListenerRequest, HttpListenerResponse, string, string> handleRequestFunc;

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString( ) => $"HttpServer[{port}]";

		#endregion

		#region Static Helper

		/// <summary>
		/// 使用指定的对象来返回网络的API接口，前提是传入的数据为json参数，返回的数据为json数据，详细参照说明<br />
		/// Use the specified object to return the API interface of the network, 
		/// provided that the incoming data is json parameters and the returned data is json data, 
		/// please refer to the description for details
		/// </summary>
		/// <param name="request">当前的请求信息</param>
		/// <param name="json">json格式的参数信息</param>
		/// <param name="obj">等待解析的api解析的对象</param>
		/// <returns>等待返回客户的结果</returns>
		public static string HandleObjectMethod( HttpListenerRequest request, string json, object obj )
		{
			MethodInfo methodInfo;
			object[] paras;
			try
			{
				string method;
				string url = request.RawUrl;
				if (url.LastIndexOf( '/' ) < 0)   method = url;
				else method = url.Substring( url.LastIndexOf( '/' ) + 1 );

				methodInfo = obj.GetType( ).GetMethod( method );
				if(methodInfo == null) return new OperateResult( $"Current Api ：{url} not exsist" ).ToJsonString( );

				if (request.HttpMethod == "POST")
				{
					object[] attrs = methodInfo.GetCustomAttributes( typeof( HttpPost ), false );
					if(attrs == null || attrs.Length == 0) return new OperateResult( $"Current Api ：{url} not support POST" ).ToJsonString( );
				}
				else if (request.HttpMethod == "GET")
				{
					object[] attrs = methodInfo.GetCustomAttributes( typeof( HttpGet ), false );
					if (attrs == null || attrs.Length == 0) return new OperateResult( $"Current Api ：{url} not support GET" ).ToJsonString( );
				}
				
				paras = HslReflectionHelper.GetParametersFromJson( methodInfo.GetParameters( ), json );
			}
			catch (Exception ex)
			{
				return new OperateResult( $"Current Api ：{request.RawUrl} Wrong，Reason：" + ex.Message ).ToJsonString( );
			}

			return methodInfo.Invoke( obj, paras ).ToJsonString( );
		}


		#endregion
	}
}
