﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication.Profinet.Omron;
using System.Threading.Tasks;
using HslCommunication;


namespace HslCommunication_Net45.Test.Profinet.Omron
{
	[TestClass]
	public class OmronHostLinkCModeTest
	{
		[TestMethod]
		public void BuildReadCommandTest( )
		{

			OperateResult<byte[]> build = OmronHostLinkCMode.BuildReadCommand( "C100", 1, false );
			Assert.IsTrue( build.IsSuccess, build.Message );
			string cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "RR01000001", cmd );

			build = OmronHostLinkCMode.BuildReadCommand( "H100", 10, false );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "RH01000010", cmd );

			build = OmronHostLinkCMode.BuildReadCommand( "D200", 10, false );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "RD02000010", cmd );

			build = OmronHostLinkCMode.BuildReadCommand( "A0", 2, false );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "RJ00000002", cmd );

			build = OmronHostLinkCMode.BuildReadCommand( "E2.0", 2, false );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "RE0200000002", cmd );
		}

		[TestMethod]
		public void BuildWriteWordCommandTest( )
		{
			OperateResult<byte[]> build = OmronHostLinkCMode.BuildWriteWordCommand( "C100", new byte[] { 0x01, 0x00 } );
			Assert.IsTrue( build.IsSuccess, build.Message );
			string cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "WR01000001", cmd );

			build = OmronHostLinkCMode.BuildWriteWordCommand( "H100", new byte[] { 0x01, 0x00, 0x64, 0x00 } );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "WH010000010064", cmd );

			build = OmronHostLinkCMode.BuildWriteWordCommand( "D200", new byte[] { 0x01, 0x02, 0x64, 0x00 } );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "WD020002010064", cmd );

			build = OmronHostLinkCMode.BuildWriteWordCommand( "A0", new byte[] { 0x01, 0x00 } );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "WJ00000001", cmd );

			build = OmronHostLinkCMode.BuildWriteWordCommand( "EC.0", new byte[] { 0x01, 0x00 } );
			Assert.IsTrue( build.IsSuccess, build.Message );
			cmd = Encoding.ASCII.GetString( build.Content );
			Assert.AreEqual( "WE0C00000001", cmd );
		}
	}
}
