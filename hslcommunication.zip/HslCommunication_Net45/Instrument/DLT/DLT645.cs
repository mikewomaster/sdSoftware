﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using HslCommunication.Serial;
using HslCommunication.Core;
using System.Text.RegularExpressions;
using HslCommunication.BasicFramework;
#if !NET35 && !NET20
using System.Threading.Tasks;
#endif

namespace HslCommunication.Instrument.DLT
{
	/// <summary>
	/// 基于多功能电能表通信协议实现的通讯类，参考的文档是DLT645-2007
	/// </summary>
	public class DLT645 : SerialDeviceBase
	{
		#region Constructor

		/// <summary>
		/// 指定地址域来实例化一个对象
		/// </summary>
		/// <param name="station">设备的站号信息</param>
		/// <param name="password">密码，写入的时候进行验证的信息</param>
		/// <param name="opCode">操作者代码</param>
		public DLT645( string station, string password = "", string opCode = "" )
		{
			this.ByteTransform = new RegularByteTransform( );
			this.station       = station;
			this.password      = string.IsNullOrEmpty( password ) ? "00000000" : password;
			this.opCode        = string.IsNullOrEmpty( opCode ) ? "00000000" : opCode;
		}

		#endregion

		#region Public Method

		/// <summary>
		/// 激活设备的命令，在设备
		/// </summary>
		/// <returns>是否发送成功</returns>
		public OperateResult ActiveDeveice( )
		{
			return ReadBase( new byte[] { 0xFE, 0xFE, 0xFE, 0xFE }, true );
		}

		/// <summary>
		/// 地址为数据标识
		/// </summary>
		/// <param name="address">地址信息</param>
		/// <param name="length">数据长度信息</param>
		/// <returns>结果信息</returns>
		public override OperateResult<byte[]> Read( string address, ushort length )
		{
			OperateResult<string, byte[]> analysis = AnalysisBytesAddress( address, this.station );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( analysis );

			OperateResult<byte[]> command = BuildEntireCommand( analysis.Content1, DLTControl.ReadData, analysis.Content2 );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return read;

			OperateResult check = CheckResponse( read.Content );
			if (!check.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( check );

			if (read.Content.Length < 16) return OperateResult.CreateSuccessResult( new byte[0] );
			return OperateResult.CreateSuccessResult( read.Content.SelectMiddle( 14, read.Content.Length - 16 ) );
		}

		/// <inheritdoc/>
		public override OperateResult<double[]> ReadDouble( string address, ushort length )
		{
			OperateResult<byte[]> read = Read( address, length );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<double[]>( read );

			return TransDoubleFromDLt( read.Content, length );
		}
#if !NET35 && !NET20
		/// <inheritdoc cref="ReadDouble(string, ushort)"/>
		public async override Task<OperateResult<double[]>> ReadDoubleAsync( string address, ushort length )
		{
			return await Task.Run( ( ) => ReadDouble( address, length ) );
		}
#endif
		/// <summary>
		/// 写入数据信息
		/// </summary>
		/// <param name="address">地址信息</param>
		/// <param name="value">写入的数据值</param>
		/// <returns>是否写入成功</returns>
		public override OperateResult Write( string address, byte[] value )
		{
			OperateResult<string, byte[]> analysis = AnalysisBytesAddress( address, this.station );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( analysis );

			byte[] content = SoftBasic.SpliceByteArray( analysis.Content2, password.ToHexBytes( ), opCode.ToHexBytes( ), value );

			OperateResult<byte[]> command = BuildEntireCommand( analysis.Content1, DLTControl.WriteAddress, content );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return read;

			return CheckResponse( read.Content );
		}

		/// <summary>
		/// 读取设备的通信地址，仅支持点对点通讯的情况
		/// </summary>
		/// <returns>设备的通信地址</returns>
		public OperateResult<string> ReadAddress( )
		{
			OperateResult<byte[]> command = BuildEntireCommand( "AAAAAAAAAAAA", DLTControl.ReadAddress, null );
			if (!command.IsSuccess) return OperateResult.CreateFailedResult<string>( command );

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return OperateResult.CreateFailedResult<string>( read );

			OperateResult check = CheckResponse( read.Content );
			if (!check.IsSuccess) return OperateResult.CreateFailedResult<string>( check );

			return OperateResult.CreateSuccessResult( read.Content.SelectMiddle( 1, 6 ).ToHexString( ) );
		}

		/// <summary>
		/// 写入设备的通信地址，仅支持点对点通讯的情况
		/// </summary>
		/// <param name="address">等待写入的地址域</param>
		/// <returns>是否写入成功</returns>
		public OperateResult WriteAddress( string address )
		{
			OperateResult<byte[]> add = GetAddressByteFromString( address );
			if (!add.IsSuccess) return add;

			OperateResult<byte[]> command = BuildEntireCommand( "AAAAAAAAAAAA", DLTControl.WriteAddress, add.Content );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return read;

			OperateResult check = CheckResponse( read.Content );
			if (!check.IsSuccess) return check;

			if (SoftBasic.IsTwoBytesEquel( read.Content.SelectMiddle( 1, 6 ), add.Content ))
				return OperateResult.CreateSuccessResult( );
			else
				return new OperateResult( StringResources.Language.DLTErrorWriteReadCheckFailed );
		}

		/// <summary>
		/// 广播指定的时间，强制从站与主站时间同步
		/// </summary>
		/// <param name="dateTime">时间</param>
		/// <returns>是否成功</returns>
		public OperateResult BroadcastTime( DateTime dateTime )
		{
			string hex = $"{dateTime.Second:D2}{dateTime.Minute:D2}{dateTime.Hour:D2}{dateTime.Day:D2}{dateTime.Month:D2}{dateTime.Year % 100:D2}";

			OperateResult<byte[]> command = BuildEntireCommand( "999999999999", DLTControl.WriteAddress, hex.ToHexBytes( ) );
			if (!command.IsSuccess) return command;

			return ReadBase( command.Content, true );
		}

		/// <summary>
		/// 对设备发送冻结命令，默认点对点操作，地址域为99999999999999时为广播，数据域格式说明：MMDDhhmm(月日时分)，
		/// 99DDhhmm表示月为周期定时冻结，9999hhmm表示日为周期定时冻结，999999mm表示以小时为周期定时冻结，99999999表示瞬时冻结
		/// </summary>
		/// <param name="dataArea">数据域信息</param>
		/// <returns>是否成功冻结</returns>
		public OperateResult FreezeCommand( string dataArea )
		{
			OperateResult<string, byte[]> analysis = AnalysisBytesAddress( dataArea, this.station );
			if (!analysis.IsSuccess) return OperateResult.CreateFailedResult<byte[]>( analysis );

			OperateResult<byte[]> command = BuildEntireCommand( analysis.Content1, DLTControl.FreezeCommand, analysis.Content2 );
			if (!command.IsSuccess) return command;

			if (analysis.Content1 == "999999999999")
			{
				// 广播操作
				return ReadBase( command.Content, true );
			}
			else
			{
				// 点对点操作
				OperateResult<byte[]> read = ReadBase( command.Content );
				if (!read.IsSuccess) return read;

				return CheckResponse( read.Content );
			}
		}

		/// <summary>
		/// 更改通信速率，波特率可选600,1200,2400,4800,9600,19200，其他值无效，可以携带地址域信息，s=1;9600
		/// </summary>
		/// <param name="baudRate">波特率的信息</param>
		/// <returns>是否更改成功</returns>
		public OperateResult ChangeBaudRate( string baudRate )
		{
			OperateResult<string, int> analysis = AnalysisIntegerAddress( baudRate, this.station );
			if (!analysis.IsSuccess) return analysis;

			byte code = 0x00;
			switch (analysis.Content2)
			{
				case 600:   code = 0x02; break;
				case 1200:  code = 0x04; break;
				case 2400:  code = 0x08; break;
				case 4800:  code = 0x10; break;
				case 9600:  code = 0x20; break;
				case 19200: code = 0x40; break;
				default: return new OperateResult( StringResources.Language.NotSupportedFunction );
			}

			OperateResult<byte[]> command = BuildEntireCommand( analysis.Content1, DLTControl.ChangeBaudRate, new byte[] { code } );
			if (!command.IsSuccess) return command;

			OperateResult<byte[]> read = ReadBase( command.Content );
			if (!read.IsSuccess) return read;

			OperateResult check = CheckResponse( read.Content );
			if (!check.IsSuccess) return check;

			if (read.Content[10] == code)
				return OperateResult.CreateSuccessResult( );
			else
				return new OperateResult( StringResources.Language.DLTErrorWriteReadCheckFailed );
		}

		#endregion

		#region Private Method

		private OperateResult<double[]> TransDoubleFromDLt( byte[] content, ushort length )
		{
			try
			{
				double[] values = new double[length];
				for (int i = 0; i < values.Length; i++)
				{
					byte[] buffer = content.SelectMiddle( i * 4, 4 ).Reverse( ).ToArray( );
					for (int j = 0; j < buffer.Length; j++)
					{
						buffer[i] = (byte)(buffer[i] - 0x33);
					}

					values[i] = Convert.ToDouble( buffer.ToHexString( ) ) / 100d;
				}
				return OperateResult.CreateSuccessResult( values );
			}
			catch (Exception ex)
			{
				return new OperateResult<double[]>( ex.Message );
			}
		}

		#endregion

		#region Private Member

		private string station = "1";                  // 地址域信息
		private string password = "00000000";          // 密码
		private string opCode = "00000000";            // 操作者代码

		#endregion

		#region Object Override

		/// <inheritdoc/>
		public override string ToString( ) => $"DLT645[{PortName}:{BaudRate}]";

		#endregion

		#region Static Helper

		/// <summary>
		/// 将地址解析成BCD码的地址，并且扩充到12位，不够的补0操作
		/// </summary>
		/// <param name="address">地址域信息</param>
		/// <returns>实际的结果</returns>
		public static OperateResult<byte[]> GetAddressByteFromString( string address )
		{
			if (address == null || address.Length == 0) return new OperateResult<byte[]>( StringResources.Language.DLTAddressCannotNull );
			if (address.Length > 12) return new OperateResult<byte[]>( StringResources.Language.DLTAddressCannotMoreThan12 );
			if (!Regex.IsMatch( address, "^[0-9A-A]+$" )) return new OperateResult<byte[]>( StringResources.Language.DLTAddressMatchFailed );
			if (address.Length < 12) address = address.PadLeft( 12, '0' );
			return OperateResult.CreateSuccessResult( address.ToHexBytes( ) );
		}

		/// <summary>
		/// 将指定的地址信息，控制码信息，数据域信息打包成完整的报文命令
		/// </summary>
		/// <param name="address">地址域信息，地址域由6个字节构成，每字节2位BCD码，地址长度可达12位十进制数。地址域支持锁位寻址，即从若干低位起，剩余高位补AAH作为通配符进行读表操作</param>
		/// <param name="control">控制码信息</param>
		/// <param name="dataArea">数据域的内容</param>
		/// <returns>返回是否报文创建成功</returns>
		public OperateResult<byte[]> BuildEntireCommand(string address, byte control, byte[] dataArea )
		{
			if (dataArea == null) dataArea = new byte[0];
			OperateResult<byte[]> add = GetAddressByteFromString( address );
			if (!add.IsSuccess) return add;

			byte[] buffer = new byte[12 + dataArea.Length];
			buffer[0] = 0x68;                                  // 帧起始符
			add.Content.CopyTo( buffer, 1 );                   // BCD码的地址信息
			buffer[7] = 0x68;                                  // 帧起始符
			buffer[8] = control;                               // 控制码
			buffer[9] = (byte)dataArea.Length;                 // 数据域长度，读的时候小于等于200，写的时候，小于等于50
			if (dataArea.Length > 0)
			{
				for (int i = 0; i < dataArea.Length; i++)
				{
					dataArea[i] += 0x33;
				}
				dataArea.CopyTo( buffer, 10 );                 // 数据域，发送之前增加0x33
			}

			// 求校验码
			int count = 0;
			for (int i = 0; i < buffer.Length - 2; i++)
			{
				count += buffer[i];
			}
			buffer[buffer.Length - 2] = (byte)count;           // 校验码
			buffer[buffer.Length - 1] = 0x16;                  // 结束符
			return OperateResult.CreateSuccessResult( buffer );
		}

		/// <summary>
		/// 从用户输入的地址信息中解析出真实的地址及数据标识
		/// </summary>
		/// <param name="address">用户输入的地址信息</param>
		/// <param name="defalut">默认的地址域</param>
		/// <returns>解析结果信息</returns>
		public static OperateResult<string, byte[]> AnalysisBytesAddress(string address, string defalut )
		{
			string region = defalut;
			byte[] dataId = new byte[4];
			if (address.IndexOf( ';' ) > 0)
			{
				string[] splits = address.Split( new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries );
				for (int i = 0; i < splits.Length; i++)
				{
					if (splits[i].StartsWith( "s=" ))
					{
						region = splits[i].Substring( 2 );
					}
					else
					{
						dataId = splits[i].ToHexBytes( ).Reverse( ).ToArray( );
					}
				}
			}
			else
			{
				dataId = address.ToHexBytes( ).Reverse( ).ToArray( );
			}
			return OperateResult.CreateSuccessResult( region, dataId );
		}


		/// <summary>
		/// 从用户输入的地址信息中解析出真实的地址及数据标识
		/// </summary>
		/// <param name="address">用户输入的地址信息</param>
		/// <param name="defalut">默认的地址域</param>
		/// <returns>解析结果信息</returns>
		public static OperateResult<string, int> AnalysisIntegerAddress( string address, string defalut )
		{
			try
			{
				string region = defalut;
				int value = 0;
				if (address.IndexOf( ';' ) > 0)
				{
					string[] splits = address.Split( new char[] { ';' }, StringSplitOptions.RemoveEmptyEntries );
					for (int i = 0; i < splits.Length; i++)
					{
						if (splits[i].StartsWith( "s=" ))
						{
							region = splits[i].Substring( 2 );
						}
						else
						{
							value = Convert.ToInt32( splits[i] );
						}
					}
				}
				else
				{
					value = Convert.ToInt32( address );
				}
				return OperateResult.CreateSuccessResult( region, value );
			}
			catch(Exception ex)
			{
				return new OperateResult<string, int>( ex.Message );
			}
		}

		/// <summary>
		/// 检查当前的反馈数据信息是否正确
		/// </summary>
		/// <param name="response">从仪表反馈的数据信息</param>
		/// <returns>是否校验成功</returns>
		public static OperateResult CheckResponse(byte[] response )
		{
			if (response.Length < 9) return new OperateResult( StringResources.Language.ReceiveDataLengthTooShort );
			if ((response[8] & 0x40) == 0x40)
			{
				// 异常的响应
				byte error = response[10];
				if (error.GetBoolOnIndex( 0 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit0 );
				if (error.GetBoolOnIndex( 1 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit1 );
				if (error.GetBoolOnIndex( 2 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit2 );
				if (error.GetBoolOnIndex( 3 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit3 );
				if (error.GetBoolOnIndex( 4 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit4 );
				if (error.GetBoolOnIndex( 5 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit5 );
				if (error.GetBoolOnIndex( 6 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit6 );
				if (error.GetBoolOnIndex( 7 )) return new OperateResult( StringResources.Language.DLTErrorInfoBit7 );
				return OperateResult.CreateSuccessResult( );
			}
			else
			{
				// 正常的响应
				return OperateResult.CreateSuccessResult( );
			}
		}

		#endregion
	}
}
