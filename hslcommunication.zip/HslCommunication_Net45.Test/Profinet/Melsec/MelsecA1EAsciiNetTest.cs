﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HslCommunication;
using HslCommunication.Profinet.Melsec;
using HslCommunication.BasicFramework;

namespace HslCommunication_Net45.Test.Profinet.Melsec
{
	[TestClass]
	public class MelsecA1EAsciiNetTest
	{
		[TestMethod]
		public void BuildReadCommandTest( )
		{
			OperateResult<byte[]> command = MelsecA1EAsciiNet.BuildReadCommand( "M100", 12, true, 0xFF );
			Assert.IsTrue( command.IsSuccess, command.Message );

			byte[] buffer = "3030 4646 30303041 34443230 3030303030303634 3043 3030".ToHexBytes( );
			Assert.IsTrue( SoftBasic.IsTwoBytesEquel( buffer, command.Content ), command.Content.ToHexString( ' ' ) );


			command = MelsecA1EAsciiNet.BuildReadCommand( "Y40", 2, false, 0xFF );
			Assert.IsTrue( command.IsSuccess, command.Message );

			buffer = "3031 4646 30303041 35393230 3030303030303430 3032 3030".ToHexBytes( );
			Assert.IsTrue( SoftBasic.IsTwoBytesEquel( buffer, command.Content ), command.Content.ToHexString( ' ' ) );
		}

		[TestMethod]
		public void BuildWriteWordCommandTest( )
		{
			OperateResult<byte[]> command = MelsecA1EAsciiNet.BuildWriteWordCommand( "D100", "341276980901".ToHexBytes( ), 0xFF );
			Assert.IsTrue( command.IsSuccess, command.Message );

			byte[] buffer = "3033 4646 30303041 34343230 3030303030303634 3033 3030 313233343938373630313039".ToHexBytes( );
			Assert.IsTrue( SoftBasic.IsTwoBytesEquel( buffer, command.Content ), command.Content.ToHexString( ' ' ) );
		}

		[TestMethod]
		public void BuildWriteBoolCommandTest( )
		{
			OperateResult<byte[]> command = MelsecA1EAsciiNet.BuildWriteBoolCommand( "M50", new bool[] { true, true, false, false, false, false, false, false, false, false, false, true  }, 0xFF );
			Assert.IsTrue( command.IsSuccess, command.Message );

			byte[] buffer = "3032 4646 30303041 34443230 3030303030303332 3043 3030 313130303030303030303031".ToHexBytes( );
			Assert.IsTrue( SoftBasic.IsTwoBytesEquel( buffer, command.Content ), command.Content.ToHexString( ' ' ) );

		}
	}
}
