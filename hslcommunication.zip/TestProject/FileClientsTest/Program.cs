﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Enthernet;
using System.Threading;
using HslCommunication.LogNet;
using HslCommunication.ModBus;
using HslCommunication;

namespace FileClientsTest
{
    class Program
    {
        public static ILogNet logNet;
        // 一个多线程测试的客户端，测试任意个客户端同时下载文件的情况的
        static void Main( string[] args )
        {
            //ModbusTcpNet modbus = new ModbusTcpNet( "127.0.0.1" );
            //modbus.SetPersistentConnection( );
            //while (true)
            //{
            //    Thread.Sleep( 100 );
            //    OperateResult<short> read = modbus.ReadInt16( "100" );
            //    if (read.IsSuccess)
            //    {
            //        Console.WriteLine( $"{DateTime.Now} 读取成功：{read.Content}" );
            //    }
            //    else
            //    {
            //        Console.WriteLine( $"{DateTime.Now} 读取失败：{read.Message}" );
            //    }
            //}


            System.Threading.ThreadPool.SetMaxThreads( 1000, 200 );

            logNet = new LogNetFileSize( System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "logs" ) );
            logNet.BeforeSaveToFile += LogNet_BeforeSaveToFile;
            while (true)
            {
                Thread.Sleep( 1000 );
                logNet.WriteInfo( "Info Log:" + HslCommunication.Core.SimpleHybirdLock.SimpleHybirdLockCount );
            }

            int completeCount = 0;
            if (System.IO.Directory.Exists( System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "Download" ) ))
            {
                string[] files = System.IO.Directory.GetFiles( System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "Download" ) );
                foreach (var item in files)
                {
                    System.IO.File.Delete( item );
                }
            }
            else
            {
                System.IO.Directory.CreateDirectory( System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "Download" ) );
            }

            Console.WriteLine( $"开始下载..." );
            for (int i = 0; i < 30; i++)
            {
                new Thread( new ThreadStart( ( ) =>
                {
                    HslCommunication.OperateResult down = FileDownloadTest1( );
                    if (down.IsSuccess)
                    {
                        int finish = ++completeCount;
                        Console.WriteLine( $"成功，当前是{finish}个" );
                    }
                    else
                    {
                        int finish = ++completeCount;
                        Console.WriteLine( $"失败，当前是{finish}个 {down.Message}" );
                    }
                } ) )
                {
                    IsBackground = true
                }.Start( );
            }


            Console.WriteLine( $"等待下载完成..." );

            Console.ReadLine( );
        }

        private static void LogNet_BeforeSaveToFile( object sender, HslEventArgs e )
        {
            Console.WriteLine( e.HslMessage.ToString( ) );
        }

        private static HslCommunication.OperateResult FileDownloadTest1( )
        {
            IntegrationFileClient fileClient = new IntegrationFileClient( "127.0.0.1", 35001 );
            fileClient.LogNet = logNet;
            string fileName = System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "Download", Guid.NewGuid( ).ToString( ) );

            Console.WriteLine( $"开始下载..." );
            return fileClient.DownloadFile( "trees.jpg", "Files", "Personal", "Admin", null, fileName );
        }

        private static HslCommunication.OperateResult FileDownloadTest2( )
        {
            IntegrationFileClient fileClient = new IntegrationFileClient( "127.0.0.1", 35002 );
            fileClient.LogNet = logNet;

            string fileName = System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "Download", Guid.NewGuid( ).ToString( ) );

            Console.WriteLine( $"开始下载..." );
            return fileClient.DownloadFile( "采集说明.xlsx", "Files", "Personal", "Admin", null, fileName );
        }


        private static HslCommunication.OperateResult FileUpdaloadTest( )
        {
            IntegrationFileClient fileClient = new IntegrationFileClient( "127.0.0.1", 35002 );
            fileClient.LogNet = logNet;
            string fileName = System.IO.Path.Combine( AppDomain.CurrentDomain.BaseDirectory, "HslCommunication.dll" );

            Console.WriteLine( $"开始上传..." );
            return fileClient.UploadFile( fileName, "HslCommunication.dll", "Files", "Personal", "Admin", "", "", null );
        }

        private static HslCommunication.OperateResult NetSimplify( )
        {
            NetSimplifyClient client = new NetSimplifyClient( "127.0.0.1", 12345 );
            return client.ReadCustomerFromServer( 1, "" );
        }
    }
}
