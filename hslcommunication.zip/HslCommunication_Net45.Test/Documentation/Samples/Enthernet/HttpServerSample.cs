﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Enthernet;

namespace HslCommunication_Net45.Test.Documentation.Samples.Enthernet
{
	class HttpServerSample1
	{
		#region Sample1

		private HttpServer httpServer;                                                     // 当前的Web服务器，支持web api来通信的方式

		private void Start( )
		{
			// 启动web的服务器
			try
			{
				this.httpServer = new HttpServer( );
				this.httpServer.Start( 8000 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Web服务器加载失败！" + ex.Message );
			}
		}

		// 调用start方法之后，我们打开浏览器，输入 http://127.0.0.1:8000 就可以看到如下的文本 "This is HslWebServer, Thank you for use!"
		// After calling the start method, we open the browser and enter http://127.0.0.1:8000 to see the following text: "This is HslWebServer, Thank you for use!"

		#endregion
	}
	class HttpServerSample2
	{
		#region Sample2

		private HttpServer httpServer;                                                     // 当前的Web服务器，支持web api来通信的方式

		private void Start( )
		{
			// 启动web的服务器
			try
			{
				this.httpServer = new HttpServer( );
				this.httpServer.HandleRequestFunc = HandleRequest;
				this.httpServer.Start( 8000 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Web服务器加载失败！" + ex.Message );
			}
		}

		private string HandleRequest( HttpListenerRequest request, HttpListenerResponse response, string data )
		{
			if (request.HttpMethod == "GET")
			{
				return "This is Get Method";
			}
			else if (request.HttpMethod == "POST")
			{
				return "This is Post Method";
			}
			else
			{
				return string.Empty;
			}
		}
		#endregion
	}
	class HttpServerSample3
	{
		private HttpServer httpServer;                                                     // 当前的Web服务器，支持web api来通信的方式

		private void Start( )
		{
			// 启动web的服务器
			try
			{
				this.httpServer = new HttpServer( );
				this.httpServer.HandleRequestFunc = HandleRequest;
				this.httpServer.Start( 8000 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Web服务器加载失败！" + ex.Message );
			}
		}

		#region Sample3

		private string HandleRequest( HttpListenerRequest request, HttpListenerResponse response, string data )
		{
			if (request.HttpMethod == "GET")
			{
				if (request.RawUrl == "/GetA")
				{
					return "This is GetA Method";
				}
				else if (request.RawUrl == "/GetB")
				{
					return "This is GetB Method";
				}
				else
				{
					return "This is Notsupported Method";
				}
			}
			else if (request.HttpMethod == "POST")
			{
				if (request.RawUrl == "/PostA")
				{
					Console.WriteLine( data );   // data 就是post上来的数据信息
					return "OK";
				}
				return "This is Post Method";
			}
			else
			{
				return string.Empty;
			}
		}
		#endregion
	}

	class HttpServerSample4
	{
		private HttpServer httpServer;                                                     // 当前的Web服务器，支持web api来通信的方式

		private void Start( )
		{
			// 启动web的服务器
			try
			{
				this.httpServer = new HttpServer( );
				this.httpServer.HandleRequestFunc = HandleRequest;
				this.httpServer.Start( 8000 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Web服务器加载失败！" + ex.Message );
			}
		}

		#region Sample4

		private string HandleRequest( HttpListenerRequest request, HttpListenerResponse response, string data )
		{
			// 下面的对授权验证增加用户名和密码的操作，当使用浏览器登录的时候，会自动弹出输入用户名及密码的窗口
			// The following operation for adding a username and password for authorization verification will automatically pop up a window for 
			// entering the username and password when logging in with a browser.
			string[] values = request.Headers.GetValues( "Authorization" );
			if (values == null || values.Length < 1 || string.IsNullOrEmpty( values[0] ))
			{
				response.StatusCode = 401;
				response.AddHeader( "WWW-Authenticate", "Basic realm=\"Secure Area\"" );
				return "";
			}

			string base64String = values[0].Split( new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries )[1];
			string accountString = Encoding.UTF8.GetString( Convert.FromBase64String( base64String ) );
			string[] account = accountString.Split( new char[] { ':' }, StringSplitOptions.RemoveEmptyEntries );
			if (account.Length < 2)
			{
				response.StatusCode = 401;
				response.AddHeader( "WWW-Authenticate", "Basic realm=\"Secure Area\"" );
				return "";
			}

			// 此处假定用户名和密码限定了 admin 123456
			if (!(account[0] == "admin" && account[1] == "123456"))
			{
				response.StatusCode = 401;
				response.AddHeader( "WWW-Authenticate", "Basic realm=\"Secure Area\"" );
				return "";
			}

			if (request.HttpMethod == "GET")
			{
				if (request.RawUrl == "/GetA")
				{
					return "This is GetA Method";
				}
				else if (request.RawUrl == "/GetB")
				{
					return "This is GetB Method";
				}
				else
				{
					return "This is Notsupported Method";
				}
			}
			else if (request.HttpMethod == "POST")
			{
				if (request.RawUrl == "/PostA")
				{
					Console.WriteLine( data );   // data 就是post上来的数据信息
					return "OK";
				}
				return "This is Post Method";
			}
			else
			{
				return string.Empty;
			}
		}
		#endregion
	}

	class HttpServerSample5
	{
		private HttpServer httpServer;                                                     // 当前的Web服务器，支持web api来通信的方式

		private void Start( )
		{
			// 启动web的服务器
			try
			{
				this.httpServer = new HttpServer( );
				this.httpServer.HandleRequestFunc = HandleRequest;
				this.httpServer.Start( 8000 );
			}
			catch (Exception ex)
			{
				Console.WriteLine( "Web服务器加载失败！" + ex.Message );
			}
		}

		#region Sample5

		private string HandleRequest( HttpListenerRequest request, HttpListenerResponse response, string data )
		{
			if (request.HttpMethod == "GET")
			{
				if (request.RawUrl == "/GetA") // 当浏览器浏览一个网页的时候，输入 http://127.0.0.1:6000/GetA 会显示网络内容
				{
					response.AddHeader( "Content-type", $"Content-Type: text/html; charset=utf-8" );
					return "<html><head><title>HslWebServer</title></head><body><p style=\"color: red\">这是一个测试的消息内容</p></body></html>";
				}
				else
				{
					return "This is Notsupported Method";
				}
			}
			else if (request.HttpMethod == "POST")
			{
				return "This is Post Method";
			}
			else
			{
				return string.Empty;
			}
		}
		#endregion
	}
}
