﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.BasicFramework;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HslCommunication_Net45.Test.BasicFramework
{
	[TestClass]
	public class SoftIncrementCountTest
	{
		[TestMethod]
		public void Test1( )
		{
			SoftIncrementCount softIncrement = new SoftIncrementCount( ushort.MaxValue );
			for (int i = 0; i < ushort.MaxValue + 1; i++)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}

			Assert.IsTrue( softIncrement.GetCurrentValue( ) == 0 );
			Assert.IsTrue( softIncrement.GetCurrentValue( ) == 1 );
			Assert.IsTrue( softIncrement.GetCurrentValue( ) == 2 );


			softIncrement = new SoftIncrementCount( 2000, 1000 );
			for (int i = 1000; i < 2001; i++)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
			for (int i = 1000; i < 2001; i++)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
			for (int i = 1000; i < 2001; i++)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}

			// 1,3,5,7,9....999
			softIncrement = new SoftIncrementCount( 999, 1, 2 );
			for (int i = 1; i < 1000; i+=2)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
			for (int i = 1; i < 1000; i += 2)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}

			// 999, 998, 997.......0
			softIncrement = new SoftIncrementCount( 999, 0, -1 );
			softIncrement.ResetCurrentValue( 999 );
			for (int i = 999; i >= 0; i--)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
			for (int i = 999; i >= 0; i--)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}

			// 999, 997, 995, .......1
			softIncrement = new SoftIncrementCount( 999, 1, -2 );
			softIncrement.ResetCurrentValue( 999 );
			for (int i = 999; i > 0; i-=2)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
			for (int i = 999; i > 0; i-=2)
			{
				Assert.IsTrue( softIncrement.GetCurrentValue( ) == i );
			}
		}
	}
}
