﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication.Profinet.Melsec;
using HslCommunication;

namespace HslCommunication_Net45.Test.Documentation.Samples.Profinet
{
    public class melsecTest
    {
        public void ClassTest( )
        {
            #region Usage

            // 实例化对象，指定PLC的ip地址和端口号
            MelsecMcNet melsecMc = new MelsecMcNet( "192.168.1.110", 6000 );
            // 举例读取D100的值
            short D100 = melsecMc.ReadInt16( "D100" ).Content;

            #endregion
        }

        public void ClassTest2( )
        {
            #region Usage2

            // 实例化对象，指定PLC的ip地址和端口号
            MelsecMcNet melsecMc = new MelsecMcNet( "192.168.1.110", 6000 );

            // 连接对象
            OperateResult connect = melsecMc.ConnectServer( );
            if (!connect.IsSuccess)
            {
                Console.WriteLine( "connect failed:" + connect.Message );
                return;
            }

            // 举例读取D100的值
            short D100 = melsecMc.ReadInt16( "D100" ).Content;

            // 实际上所有的读写都是返回是否成功的标记的，在实际的开发中，需要严格的判定，怎么判定呢？如下的代码
            // In fact, all reads and writes return the flags of success. In actual development, strict judgment is required. How to judge? The following code
            OperateResult<short> readD100 = melsecMc.ReadInt16( "D100" );
            if (readD100.IsSuccess)
            {
                // 读取成功，这时候获取Content才是正确的值
                // The reading is successful, and the Content is the correct value at this time.
                short value = readD100.Content;
            }
            else
            {
                // 读取失败，如果仍然坚持去获取Content的值，就为0
                // Failed to read, if it still persists to get the value of Content, it is 0
            }

            // 读写是否成功的情况，应用于几乎所有的读写代码，只要看清楚返回的数据类型即可
            // Whether the reading and writing is successful is applied to almost all reading and writing codes, as long as the type of data returned is clear

            melsecMc.ConnectClose( );

            #endregion
        }


        public void ReadExample( )
        {
            #region ReadExample1


            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );
            melsec_net.SetPersistentConnection( );                                           // 设置长连接的操作

            // 此处以D寄存器作为示例，此处没有判断是否读写成功，所以是有风险的，如果通讯失败，所有的值都不是正确的
            // The D register is used as an example here. There is no judgment whether the read or write is successful, so it is risky. 
            // If the communication fails, all values are incorrect
            short short_D1000 = melsec_net.ReadInt16( "D1000" ).Content;                     // 读取D1000的short值 
            ushort ushort_D1000 = melsec_net.ReadUInt16( "D1000" ).Content;                  // 读取D1000的ushort值
            int int_D1000 = melsec_net.ReadInt32( "D1000" ).Content;                         // 读取D1000-D1001组成的int数据
            uint uint_D1000 = melsec_net.ReadUInt32( "D1000" ).Content;                      // 读取D1000-D1001组成的uint数据
            float float_D1000 = melsec_net.ReadFloat( "D1000" ).Content;                     // 读取D1000-D1001组成的float数据
            long long_D1000 = melsec_net.ReadInt64( "D1000" ).Content;                       // 读取D1000-D1003组成的long数据
            ulong ulong_D1000 = melsec_net.ReadUInt64( "D1000" ).Content;                    // 读取D1000-D1003组成的long数据
            double double_D1000 = melsec_net.ReadDouble( "D1000" ).Content;                  // 读取D1000-D1003组成的double数据
            string str_D1000 = melsec_net.ReadString( "D1000", 10 ).Content;                 // 读取D1000-D1009组成的条码数据

            // 读取数组
            short[] short_D1000_array = melsec_net.ReadInt16( "D1000", 10 ).Content;         // 读取D1000的short值 
            ushort[] ushort_D1000_array = melsec_net.ReadUInt16( "D1000", 10 ).Content;      // 读取D1000的ushort值
            int[] int_D1000_array = melsec_net.ReadInt32( "D1000", 10 ).Content;             // 读取D1000-D1001组成的int数据
            uint[] uint_D1000_array = melsec_net.ReadUInt32( "D1000", 10 ).Content;          // 读取D1000-D1001组成的uint数据
            float[] float_D1000_array = melsec_net.ReadFloat( "D1000", 10 ).Content;         // 读取D1000-D1001组成的float数据
            long[] long_D1000_array = melsec_net.ReadInt64( "D1000", 10 ).Content;           // 读取D1000-D1003组成的long数据
            ulong[] ulong_D1000_array = melsec_net.ReadUInt64( "D1000", 10 ).Content;        // 读取D1000-D1003组成的long数据
            double[] double_D1000_array = melsec_net.ReadDouble( "D1000", 10 ).Content;      // 读取D1000-D1003组成的double数据

            // 正常的安全的操作如下，每一行都需要转变下面的代码
            // The normal and safe operation is as follows, each line needs to change the following code
            OperateResult<short> resultD1000 = melsec_net.ReadInt16( "D1000" );
            if (resultD1000.IsSuccess)
            {
                Console.WriteLine( resultD1000.Content );
            }

            #endregion
        }

        public void ReadExample2( )
        {
            #region ReadExample2

            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            OperateResult<byte[]> read = melsec_net.Read( "D100", 4 );
            if(read.IsSuccess)
            {
                float temp = melsec_net.ByteTransform.TransInt16( read.Content, 0 ) / 10f;
                float press = melsec_net.ByteTransform.TransInt16( read.Content, 2 ) / 100f;
                int count = melsec_net.ByteTransform.TransInt32( read.Content, 2 );

                // do something
            }
            else
            {
                // failed
            }


            #endregion
        }

        public void ReadExample3( )
        {
            #region ReadExample3

             // 随机读取的示例，所谓的随机读取，就是跨地址读取数据

            // 下面我们举个例子，我们读取D100的值，D200的值，M32的值，W100的值，如何一次就读取出来呢？
            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            OperateResult<byte[]> read = melsec_net.ReadRandom( new string[] { "D100", "D200", "M32", "W100" } );
            if (read.IsSuccess)
            {
                short d100 = melsec_net.ByteTransform.TransInt16( read.Content, 0 );
                short d200 = melsec_net.ByteTransform.TransInt16( read.Content, 2 );
                short w100 = melsec_net.ByteTransform.TransInt16( read.Content, 6 );

                // M是位地址，提取稍微麻烦一点点
                bool[] array = HslCommunication.BasicFramework.SoftBasic.ByteToBoolArray( melsec_net.ByteTransform.TransByte( read.Content, 4, 2 ) );
                bool m32 = array[0];
                bool m33 = array[1];
                bool m34 = array[2];
                bool m35 = array[3];
                // 等等，按照规律操作就可以

                // do something
            }
            else
            {
                // failed
            }


            #endregion
        }

        public void ReadExample4( )
        {
            #region ReadExample4

            // 随机读取的示例，所谓的随机读取，就是跨地址读取数据

            // 下面我们举个例子，我们读取D100-D104的值，D200-D209的值，M32-M47的值，W100-W104的值，如何一次就读取出来呢？
            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            OperateResult<byte[]> read = melsec_net.ReadRandom( new string[] { "D100", "D200", "M32", "W100" }, new ushort[] { 5, 10, 1, 5 } );
            if (read.IsSuccess)
            {
                short d100 = melsec_net.ByteTransform.TransInt16( read.Content, 0 );
                short d101 = melsec_net.ByteTransform.TransInt16( read.Content, 2 );
                short d102 = melsec_net.ByteTransform.TransInt16( read.Content, 4 );
                short d103 = melsec_net.ByteTransform.TransInt16( read.Content, 6 );
                short d104 = melsec_net.ByteTransform.TransInt16( read.Content, 8 );
                short d200 = melsec_net.ByteTransform.TransInt16( read.Content, 10 );
                short d201 = melsec_net.ByteTransform.TransInt16( read.Content, 12 );
                // 等等
                short w100 = melsec_net.ByteTransform.TransInt16( read.Content, 32 );
                short w101 = melsec_net.ByteTransform.TransInt16( read.Content, 34 );
                short w102 = melsec_net.ByteTransform.TransInt16( read.Content, 36 );
                short w103 = melsec_net.ByteTransform.TransInt16( read.Content, 38 );
                short w104 = melsec_net.ByteTransform.TransInt16( read.Content, 40 );

                // M是位地址，提取稍微麻烦一点点
                bool[] array = HslCommunication.BasicFramework.SoftBasic.ByteToBoolArray( melsec_net.ByteTransform.TransByte( read.Content, 30, 2 ) );
                bool m32 = array[0];
                bool m33 = array[1];
                bool m34 = array[2];
                bool m35 = array[3];
                // 等等，按照规律操作就可以

                // do something
            }
            else
            {
                // failed
            }


            #endregion
        }

        public void WriteExample( )
        {
            #region WriteExample1

            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            // 此处以D寄存器作为示例
            melsec_net.Write( "D1000", (short)1234 );                // 写入D1000  short值  ,W3C0,R3C0 效果是一样的
            melsec_net.Write( "D1000", (ushort)45678 );              // 写入D1000  ushort值
            melsec_net.Write( "D1000", 1234566 );                    // 写入D1000  int值
            melsec_net.Write( "D1000", (uint)1234566 );               // 写入D1000  uint值
            melsec_net.Write( "D1000", 123.456f );                    // 写入D1000  float值
            melsec_net.Write( "D1000", 123.456d );                    // 写入D1000  double值
            melsec_net.Write( "D1000", 123456661235123534L );          // 写入D1000  long值
            melsec_net.Write( "D1000", 523456661235123534UL );          // 写入D1000  ulong值
            melsec_net.Write( "D1000", "K123456789" );                // 写入D1000  string值

            // 读取数组
            melsec_net.Write( "D1000", new short[] { 123, 3566, -123 } );                // 写入D1000  short值  ,W3C0,R3C0 效果是一样的
            melsec_net.Write( "D1000", new ushort[] { 12242, 42321, 12323 } );              // 写入D1000  ushort值
            melsec_net.Write( "D1000", new int[] { 1234312312, 12312312, -1237213 } );                    // 写入D1000  int值
            melsec_net.Write( "D1000", new uint[] { 523123212, 213,13123 } );               // 写入D1000  uint值
            melsec_net.Write( "D1000", new float[] { 123.456f, 35.3f, -675.2f } );                    // 写入D1000  float值
            melsec_net.Write( "D1000", new double[] { 12343.542312d, 213123.123d, -231232.53432d } );                    // 写入D1000  double值
            melsec_net.Write( "D1000", new long[] { 1231231242312,34312312323214,-1283862312631823 } );          // 写入D1000  long值
            melsec_net.Write( "D1000", new ulong[] { 1231231242312, 34312312323214, 9731283862312631823 } );          // 写入D1000  ulong值

            #endregion
        }

        public void WriteExample2( )
        {
            #region WriteExample2

            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            // 拼凑数据，这样的话，一次通讯就完成数据的全部写入
            byte[] buffer = new byte[8];
            melsec_net.ByteTransform.TransByte( (short)1234 ).CopyTo( buffer, 0 );
            melsec_net.ByteTransform.TransByte( (short)2100 ).CopyTo( buffer, 2 );
            melsec_net.ByteTransform.TransByte( 12353423 ).CopyTo( buffer, 4 );

            OperateResult write = melsec_net.Write( "D100", buffer );
            if (write.IsSuccess)
            {
                // success
            }
            else
            {
                // failed
            }

            // 上面的功能等同于三个数据分别写入，下面的性能更差点，因为进行了三次通讯，而且每次还要判断是否写入成功
            //melsec_net.Write( "D100", (short)1234 );
            //melsec_net.Write( "D100", (short)2100 );
            //melsec_net.Write( "D100", 12353423 );

            #endregion
        }


        public void ReadBool( )
        {
            #region ReadBool

            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            // 以下是简单的读取，没有仔细校验的方式
            bool X1 = melsec_net.ReadBool( "X1" ).Content;
            bool[] X1_10 = melsec_net.ReadBool( "X1", 10 ).Content;

            // 如果需要判断是否读取成功
            OperateResult<bool> R_X1 = melsec_net.ReadBool( "X1" );
            if (R_X1.IsSuccess)
            {
                // success
                bool value = R_X1.Content;
            }
            else
            {
                // failed
            }


            OperateResult<bool[]> R_X1_10 = melsec_net.ReadBool( "X1", 10 );
            if (R_X1_10.IsSuccess)
            {
                // success
                bool x1 = R_X1_10.Content[0];
                bool x2 = R_X1_10.Content[1];
                bool x3 = R_X1_10.Content[2];
                bool x4 = R_X1_10.Content[3];
                bool x5 = R_X1_10.Content[4];
                bool x6 = R_X1_10.Content[5];
                bool x7 = R_X1_10.Content[6];
                bool x8 = R_X1_10.Content[7];
                bool x9 = R_X1_10.Content[8];
                bool xa = R_X1_10.Content[9];
            }
            else
            {
                // failed
            }


            #endregion
        }

        public void WriteBool( )
        {
            #region WriteBool

            MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );

            // 以下是简单的写入，没有仔细校验的方式
            melsec_net.Write( "M100", true );
            melsec_net.Write( "M100", new bool[] { true, false, true, false } );

            // 如果需要判断是否读取成功
            OperateResult write1 = melsec_net.Write( "M100", true );
            if (write1.IsSuccess)
            {
                // success
            }
            else
            {
                // failed
            }


            OperateResult write2 = melsec_net.Write( "M100", new bool[] { true, false, true, false } );
            if (write2.IsSuccess)
            {
                // success
            }
            else
            {
                // failed
            }


            #endregion
        }

        #region Check Netstatus

        // 定义在外面的
        MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );
        System.Threading.Timer timer;                                          // 定时器

        /// <summary>
        /// 启动定时器，我们一般会在窗体打开的时候调用，或是系统启动的时候调用，此处示例5秒检测一次
        /// </summary>
        public void StartTimer( )
        {
            timer = new System.Threading.Timer( ThreadCheck, null, 1000, 5000 );
        }

        public void ThreadCheck(object obj )
        {
            OperateResult connect = melsec_net.ConnectServer( );
            if (connect.IsSuccess)
            {
                // 进行相关的操作，显示绿灯啥的
            }
            else
            {
                // 进行相关的操作，显示红灯啥的
            }
        }

        #endregion
    }
    public class Sample2
    {

        #region Check Netstatus2

        // 定义在外面的
        MelsecMcNet melsec_net = new MelsecMcNet( "192.168.0.100", 6000 );
        System.Threading.Timer timer;                                          // 定时器

        /// <summary>
        /// 启动定时器，我们一般会在窗体打开的时候调用，或是系统启动的时候调用，此处示例5秒检测一次
        /// </summary>
        public void StartTimer( )
        {
            melsec_net.SetPersistentConnection( ); // 设置长连接的操作，这样就不需要调用connectserver方法了。什么时候调用方法呢？实例化之后，或是读写之前就可以调用了
            timer = new System.Threading.Timer( ThreadCheck, null, 1000, 5000 );
        }

        public void ThreadCheck( object obj )
        {
            OperateResult<short> connect = melsec_net.ReadInt16( "D100" );
            if (connect.IsSuccess)
            {
                // 进行相关的操作，显示绿灯啥的
            }
            else
            {
                // 进行相关的操作，显示红灯啥的
            }
        }

        #endregion

    }
}
