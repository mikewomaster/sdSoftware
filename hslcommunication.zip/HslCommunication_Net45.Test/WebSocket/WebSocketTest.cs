﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HslCommunication;
using HslCommunication.BasicFramework;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace HslCommunication_Net45.Test.WebSocket
{

	[TestClass]
	public class WebSocketTest
	{
		[TestMethod]
		public void TestMethod1( )
		{
			string result = HslCommunication.WebSocket.WebSocketHelper.CalculateWebscoketSha1( "dGhlIHNhbXBsZSBub25jZQ==" );
			Assert.IsTrue( result == "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=" );
		}

		[TestMethod]
		public void TestMethod2( )
		{
			string result = HslCommunication.WebSocket.WebSocketHelper.GetSecKeyAccetp( @"GET / HTTP/1.1
Connection:Upgrade
Host:127.0.0.1:8088
Origin:null
Sec-WebSocket-Extensions:x-webkit-deflate-frame
Sec-WebSocket-Key:dGhlIHNhbXBsZSBub25jZQ==
Sec-WebSocket-Version:13
Upgrade:websocket
" );
			Assert.IsTrue( result == "s3pPLMBiTxaQ9kYGzzhZRbK+xOo=" );

		}

		[TestMethod]
		public void TestMethod3( )
		{
			string[] topics = HslCommunication.WebSocket.WebSocketHelper.GetWebSocketSubscribes( @"GET / HTTP/1.1
Connection:Upgrade
Host:127.0.0.1:8088
Origin:null
Sec-WebSocket-Extensions:x-webkit-deflate-frame
Sec-WebSocket-Key:dGhlIHNhbXBsZSBub25jZQ==
Sec-WebSocket-Version:13
HslSubscribes: A,B,topic,A\B
Upgrade:websocket" );
			Assert.IsTrue( topics.Length == 4 );
			Assert.IsTrue( topics[0] == "A" );
			Assert.IsTrue( topics[1] == "B" );
			Assert.IsTrue( topics[2] == "topic" );
			Assert.IsTrue( topics[3] == @"A\B" );
		}

		[TestMethod]
		public void TestMethod4( )
		{
			string http = @"Origin: http://www.hslcommunication.cn
Sec-WebSocket-Key: 4NcgERzmITfvQLC8YSVaBA==
Connection: Upgrade
Upgrade: websocket
Sec-WebSocket-Version: 13
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko
Host: www.hiddenmap.cn:1883
Cache-Control: no-cache
Cookie: Hm_lvt_91cb6da60635b7d5706be374d15ae51d=1582020655,1582021158,1582027164,1582083728; shiroCookie=a6631eb3-3f41-4deb-8396-bd926e933a78; Hm_lpvt_91cb6da60635b7d5706be374d15ae51d=1582083733
";
			Assert.IsTrue( HslCommunication.WebSocket.WebSocketHelper.CheckWebSocketLegality( http ).IsSuccess );

			http = @"Origin: http://www.hslcommunication.cn
Sec-WebSocket-Key: 4NcgERzmITfvQLC8YSVaBA==
Connection:Upgrade
Upgrade:websocket
Sec-WebSocket-Version: 13
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko
Host: www.hiddenmap.cn:1883
Cache-Control: no-cache
Cookie: Hm_lvt_91cb6da60635b7d5706be374d15ae51d=1582020655,1582021158,1582027164,1582083728; shiroCookie=a6631eb3-3f41-4deb-8396-bd926e933a78; Hm_lpvt_91cb6da60635b7d5706be374d15ae51d=1582083733
";
			Assert.IsTrue( HslCommunication.WebSocket.WebSocketHelper.CheckWebSocketLegality( http ).IsSuccess );

			http = @"Origin: http://www.hslcommunication.cn
Sec-WebSocket-Key: 4NcgERzmITfvQLC8YSVaBA==
Connection: upgrade
Upgrade: Websocket
Sec-WebSocket-Version: 13
User-Agent: Mozilla/5.0 (Windows NT 6.1; WOW64; Trident/7.0; rv:11.0) like Gecko
Host: www.hiddenmap.cn:1883
Cache-Control: no-cache
Cookie: Hm_lvt_91cb6da60635b7d5706be374d15ae51d=1582020655,1582021158,1582027164,1582083728; shiroCookie=a6631eb3-3f41-4deb-8396-bd926e933a78; Hm_lpvt_91cb6da60635b7d5706be374d15ae51d=1582083733
";
			Assert.IsTrue( HslCommunication.WebSocket.WebSocketHelper.CheckWebSocketLegality( http ).IsSuccess );
		}
	}
}
